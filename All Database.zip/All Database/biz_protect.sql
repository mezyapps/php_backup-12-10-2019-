-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 30, 2019 at 01:39 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biz_protect`
--

-- --------------------------------------------------------

--
-- Table structure for table `mst_client_information`
--

CREATE TABLE `mst_client_information` (
  `client_id` int(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `address` varchar(150) NOT NULL,
  `gst_no` varchar(50) NOT NULL,
  `aadhar_no` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL COMMENT '1=>Active 0=>Inactive',
  `inserted_date_time` varchar(100) NOT NULL,
  `updated_date_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_client_information`
--

INSERT INTO `mst_client_information` (`client_id`, `company_name`, `client_name`, `address`, `gst_no`, `aadhar_no`, `pan_no`, `mobile_no`, `email`, `password`, `status`, `inserted_date_time`, `updated_date_time`) VALUES
(1, 'shree balaji creation', 'Rajesh Tejwani', 'shop no 100 opp bank of baraoda ulhasnagar 421005', '27ADWPT1226C1ZE', '343311855774', 'ADWPT1226C', '9881880070', 'sbcbeingman@gmail.com', 'MDA3MHJhamVzaA==', '1', '2019-07-29 02:26:26pm', '2019-07-29 02:26:26pm'),
(2, 'Nehal Jathar', 'Nehal Jathar', 'Natepute', 'gat9503873045', '950387304545', 'pan9503873045', '9503873045', 'jatharnihalp@gmail.com', 'QWtzaGF5QDEy', '1', '2019-07-29 02:28:38pm', '2019-07-29 02:28:38pm'),
(3, 'Jmd Infotech', 'Naresh Gwalani', '505', '27ALUPG2392L1ZG', '888812352565', '', '9890322940', 'nareshgwalani.g@gmail.com', 'OTg5MDMyMjk0MA==', '1', '2019-07-29 02:32:27pm', '2019-07-29 02:32:27pm'),
(4, 'Mehul Enterprises', 'Mehul Surendra Shah', 'shop no 10, blue Pearl Building, s.b.marg, Dadar West, Mumbai - 400028', '27BCPPS1136R1ZR', '896665556688', 'BCPPS1136R', '9833637031', 'mehulent@yahoo.com', 'TXVrYSoyODAz', '1', '2019-07-30 09:52:45am', '2019-07-30 09:52:45am'),
(5, 'Ashirwad Garments', 'Gurmukh Sundrani', 'Darshan Market Ulhasnagar-2', '27APPPS1295H1ZA', '860226596138', 'APPPS1295H', '9822283160', 'gurmukh.k.sundrani@gmail.com', 'SmFpa2FyYTE=', '1', '2019-07-30 10:00:46am', '2019-07-30 10:00:46am'),
(6, 'Sanwaria trading Co', 'ANUJ CHOUDHARY', '331/A Badamwadi room no 65 1st floor Kalbadevi road Mumbai 2', '27AABPC7400K1Z1', '440232026183', 'AABPC7400K', '9833131614', 'sanwariatradingcompany@gmail.com', 'bWFoaW1haGk=', '1', '2019-07-30 10:04:27am', '2019-07-30 10:04:27am'),
(7, 'Ganesh dresses', 'santosh', 'kalyan', '27BQBPS1097K1ZE', '595743595990', 'BQBPS1097K', '9594242866', 'ganeshdresses2014@gmail.com', 'ODAxNTA1', '1', '2019-07-30 10:21:48am', '2019-07-30 10:21:48am'),
(8, 'Maya Fashions', 'ANIL GUPTA', 'Ulhasnagar', '27AJRPG5112H1Z8', '884562940766', 'AJRPG5112H', '7021544945', 'mayafashions@gmail.com', 'Z3VwdGExMjM0', '1', '2019-07-30 10:24:03am', '2019-07-30 10:24:03am'),
(9, 'SHRI BHAIRAVNATH', 'krushna', 'shantinagar', '27ACLPL8738P1ZL', '867279106590', 'ACLPL8738P', '7276642936', 'krushnakyl@gmail.com', 'UnVkcmFANjY4OA==', '1', '2019-07-30 10:43:47am', '2019-07-30 10:43:47am'),
(10, 'gurusharan traders', 'pankaj makhija', '101 elco market first floor ULHASNAGAR 2', '27ABQPM4589D1Z5', '774520319522', 'ABQPM4589D', '9322490447', 'gurusharantraders@gmail.com', 'c3NkbnNzZG4=', '1', '2019-07-30 10:48:41am', '2019-07-30 10:48:41am'),
(11, 'HARI OM ENTERPRISE', 'RAJU BATHIJA', 'Ambenath', '27AGDPB2373C1ZZ', '639560716647', 'AGDPB2373C', '8080030300', 'rlbathija@gmail.com', 'ODA4MDAzMDMwMA==', '1', '2019-07-30 10:53:41am', '2019-07-30 10:53:41am'),
(12, 'HARDEV DRESSES', 'pradeep mansukhani', 'shop no.2,opp bkno1861,near Ashok pickle,39 section,ulhasnagar 421005', '27Bawpm1093c1zh', '641918368380', 'BAWPM1093C', '9921343420', 'hardevdressesunr@yahoo.com', 'YWFydTEwMDUxMA==', '1', '2019-07-30 10:56:28am', '2019-07-30 10:56:28am'),
(13, 'Newyork Fashion', 'Dinesh Valecha', 'Newyork Fashion shop no 5 Brk no.2015 near svs market doodh naka', '27apypk5356g1z9', '686333683104', 'APYPK5356G', '8975143000', 'newyorkfashion99@gmail.com', 'ZGluaTEwMDg=', '1', '2019-07-30 11:00:05am', '2019-07-30 11:00:05am'),
(14, 'Neeti fashion', 'kanji chamriya', 'room no 2 rajkumar pande chawl khotwadi Mumbai 400054', '27AIJPC7615E1ZG', '307347592508', 'aijpc7615e', '9930594979', 'patelkanji187@gmail.com', 'NTk0OTc5OTkzMA==', '1', '2019-07-30 11:16:59am', '2019-07-30 11:16:59am'),
(15, 'MAA ENTERPRISES', 'MAHESH', 'SHIV GANGA NAGAR,SHIV DHARA COMPLEX PLOT39,40,41. Ambernath east', '27BBCPR0476H2ZI', '496140313000', 'BBCPR0476H', '8888752068', 'maheshrohra11@gmail.com', 'QUJDMTIz', '1', '2019-07-30 11:19:35am', '2019-07-30 11:19:35am'),
(16, 'SHRI GANESH DYEING', 'MADAN', 'BALANI CAMPOUND SHANTI NAGAR UNR 3', '27BPQPK3786P1ZR', '768684639776', 'BPQPK3786P ', '9822636000', 'madankhatri915@gmail.com', 'MTQzMTQz', '1', '2019-07-30 11:20:30am', '2019-07-30 11:20:30am'),
(17, 'R S AGRO TECH FOODS', 'Sanjay hotwani', 'bhiwandi', '27AATFR6731N1ZB', '814929294199', 'AATFR6731N', '9420920000', 'sanjaytradersoil@gmail.com', 'UnNAMTMxMw==', '1', '2019-07-30 11:29:01am', '2019-07-30 11:29:01am'),
(18, 'MAHALAXMI JEANS WORLD', 'bharat', 'near chirag hotel', '27BAYPS7385B1ZW', '899084740133', 'BAYPS7385B', '9022222083', 'sabhandasanibharat@gmail.com', 'YmhhcmF0Mjc=', '1', '2019-07-30 11:31:23am', '2019-07-30 11:31:23am'),
(19, 'HEMANDAS AND SONS', 'MANISH', '27AAJCR0655A1ZN', '27CCBPR5673M1ZX', '700507767367', 'CCBPR5673M', '9921858686', 'manishrohra086@gmail.com', 'Q0NCUFI1NjczTQ==', '1', '2019-07-30 11:34:03am', '2019-07-30 11:34:03am'),
(20, 'mahaveer garment', 'Ravi ahuja', 'new Gajanand Market shop no 9 Ulhasnagar', '', '464621937108', 'azmpa9567b', '9324725873', 'mahaveer.gmt@gmail.com', 'bWFoYSM2NjMw', '1', '2019-07-30 12:22:42pm', '2019-07-30 12:22:42pm'),
(21, 'PAHILAJRAI THANWARDAS', 'PAHILAJRAI AHUJA', 'SHOP NO 103NEAR MATH MANDIR MAIN ROAD ULASHNAGER 421005', '27AAQPA3911L1ZM', '292301376040', 'AAQPA3911LA', '9960632949', 'ashishahuja1090@gmail.com', 'MDIwMjIx', '1', '2019-07-30 01:52:14pm', '2019-07-30 01:52:14pm');

-- --------------------------------------------------------

--
-- Table structure for table `mst_customer`
--

CREATE TABLE `mst_customer` (
  `customer_id` int(100) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `gst_no` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `aadhar_no` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL COMMENT '1=>good,4=>blacklisted',
  `description` varchar(100) NOT NULL,
  `inserted_date_time` date NOT NULL,
  `updated_date_time` date NOT NULL,
  `client_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_customer`
--

INSERT INTO `mst_customer` (`customer_id`, `customer_name`, `contact_person`, `gst_no`, `address`, `email`, `mobile_no`, `aadhar_no`, `pan_no`, `status`, `description`, `inserted_date_time`, `updated_date_time`, `client_id`) VALUES
(1, 'naresh bhai', 'naresh', '27ALUPG2392L1ZG', 'ulhasnagar', 'naresh@gmail.com', '9890322940', '123456789012', '', '1', 'null', '2019-07-29', '2019-07-29', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mst_client_information`
--
ALTER TABLE `mst_client_information`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `mobile_no` (`mobile_no`,`email`);

--
-- Indexes for table `mst_customer`
--
ALTER TABLE `mst_customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `client_id` (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mst_client_information`
--
ALTER TABLE `mst_client_information`
  MODIFY `client_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `mst_customer`
--
ALTER TABLE `mst_customer`
  MODIFY `customer_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mst_customer`
--
ALTER TABLE `mst_customer`
  ADD CONSTRAINT `client_customer` FOREIGN KEY (`client_id`) REFERENCES `mst_client_information` (`client_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

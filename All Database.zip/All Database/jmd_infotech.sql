-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 01, 2019 at 11:51 PM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jmd_infotech`
--

-- --------------------------------------------------------

--
-- Table structure for table `abcd`
--
-- Error reading structure for table jmd_infotech.abcd: #1356 - View 'jmd_infotech.abcd' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them
-- Error reading data for table jmd_infotech.abcd: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM `jmd_infotech`.`abcd`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `ast_data`
--

CREATE TABLE `ast_data` (
  `id` int(11) NOT NULL,
  `buy` double NOT NULL,
  `stoploss` double NOT NULL,
  `first_targets` double NOT NULL,
  `second_targets` double NOT NULL,
  `third_targets` double NOT NULL,
  `ten` double NOT NULL,
  `hundread` double NOT NULL,
  `type` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ast_data`
--

INSERT INTO `ast_data` (`id`, `buy`, `stoploss`, `first_targets`, `second_targets`, `third_targets`, `ten`, `hundread`, `type`) VALUES
(1, 0.625, 3.1, 0.09, 0.31, 0.89, 10, 100, 'cash_market');

-- --------------------------------------------------------

--
-- Table structure for table `ast_user`
--

CREATE TABLE `ast_user` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ast_user`
--

INSERT INTO `ast_user` (`id`, `username`, `password`, `email`) VALUES
(1, '', '', ''),
(2, 'earafil', '12345', 'ansari@gmail.com'),
(3, 'nareshgwalani', 'vNG230113v', 'nareshgwalani.g@gmail.com'),
(4, 'sonu.mas007@gmail.com', '123456', 'sonu.mas007@gmail.com'),
(5, 'vivekisss', '222222Sv#', 'jockey.hbds@gmail.com'),
(6, 'a', 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `atask`
--

CREATE TABLE `atask` (
  `id` int(11) NOT NULL,
  `userid` varchar(11) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL,
  `tag` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `atask`
--

INSERT INTO `atask` (`id`, `userid`, `login_date`, `login_time`, `tag`) VALUES
(1, '1', '2019-06-09', '07:20:00', 'Half Day'),
(2, '1', '2019-06-09', '07:22:00', 'Half Day'),
(3, '1', '2019-06-09', '07:22:00', 'On Time'),
(4, '1', '2019-06-09', '08:05:00', 'On Time'),
(5, '2', '2019-06-09', '09:06:00', 'On Time'),
(6, '2', '2019-06-09', '09:18:00', 'On Time'),
(7, '3', '2019-06-09', '10:01:00', 'Half Day');

-- --------------------------------------------------------

--
-- Table structure for table `bni_chapter`
--

CREATE TABLE `bni_chapter` (
  `id` int(11) NOT NULL,
  `chapter_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bni_chapter`
--

INSERT INTO `bni_chapter` (`id`, `chapter_name`) VALUES
(1, 'BNI UMANG');

-- --------------------------------------------------------

--
-- Table structure for table `bni_give_ask`
--

CREATE TABLE `bni_give_ask` (
  `g_a_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_time` varchar(50) NOT NULL,
  `day` varchar(100) NOT NULL,
  `contact_name` varchar(250) NOT NULL,
  `category` varchar(250) NOT NULL,
  `company_name` text NOT NULL,
  `location` text NOT NULL,
  `strengths` text NOT NULL,
  `business_type` varchar(200) NOT NULL,
  `remark` text NOT NULL,
  `like_count` int(11) NOT NULL,
  `connected_by_user_id` int(11) NOT NULL,
  `tag` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bni_give_ask`
--

INSERT INTO `bni_give_ask` (`g_a_id`, `user_id`, `date_time`, `day`, `contact_name`, `category`, `company_name`, `location`, `strengths`, `business_type`, `remark`, `like_count`, `connected_by_user_id`, `tag`) VALUES
(35, 34, '04-05-2019', 'Sat', 'Bharat Mirchandani', 'Plywoods', 'Deluxe veneers & Plywoods', 'Ulhasnagar 2', 'Chairman of Rosalie CHS', 'Retailer', '', 2, 0, 111),
(34, 1, '2-5-2019', 'Thu', 'Sanju', 'Jeans Manufacturer', 'Devidas Garments', 'Ulhasnagar', 'good', 'Manufacturer', '', 1, 0, 111),
(33, 1, '3-5-2019', 'Fri', 'Rajesh', 'Paints and Hardware', 'Rajesh Hardware', 'Ulhasnagar', 'good', 'Distributor', '', 0, 0, 111),
(32, 1, '03-05-2019', 'Fri', 'Niin', 'Shirts Manufacturers', 'Satnam Garments', 'Bhiwandi', 'Good Company', 'Manufacturer', '', 1, 0, 111),
(31, 12, '03-05-2019', 'Fri', 'sunil gopalani', 'plastic manufactuting', 'plastic', 'ulhasnagar', '2 years', 'Manufacturer', '', 3, 0, 111),
(30, 1, '1-5-2019', 'Wed', 'Balaji Sakhare', 'Women Clothing Retail store', 'Rang Sarees', 'Ulhasnagar', 'good', 'Retailer', '', 2, 0, 111),
(29, 1, '02-05-2019', 'Thu', 'Amar', 'Jeans Manufacturer', 'JB Garments', 'Ulhasnagar - 5', 'Established more than 25 years supply goods all over India', 'Manufacturer', '', 2, 0, 111),
(28, 31, '02-05-2019', 'Thu', 'Any of your friend and relatives who has recently cancelled their flat booking', 'na', 'na', '', '', '', '-', 0, 1, 222),
(27, 31, '02-05-2019', 'Thu', 'Sunita', 'Exports  Trolleys Manufacturer', 'poohomals Exports Pvt Ltd', 'mahalaxmi', 'na', 'Manufacturer', '', 1, 0, 111),
(36, 34, '4-5-2019', 'Sat', 'Rajesh', 'Builder', 'Mid Town Builders', 'Ambernath', 'Pre Construction pest control', 'Manufacturer', '', 4, 0, 111),
(42, 12, '09-05-2019', 'Thu', 'kumar jaisinghani', 'tailor material trader', 'kumar jaisimghani', 'ulhasnagar-1', 'good', 'Retailer', '', 1, 0, 111),
(43, 12, '09-05-2019', 'Thu', 'NRI', 'NRI', 'NRI', '', '', '', '-', 0, 0, 222),
(44, 23, '09-05-2019', 'Thu', 'Bhavesh Bhojvani', 'Home Decor', 'Royal Paints', 'Ulhasnagar', 'Quality Products', 'Manufacturer', '', 1, 0, 111),
(45, 20, '09-05-2019', 'Thu', 'Dr. Sudhir Ghatnekar', 'Scientist', 'BR. resource centre', 'Badlapur East', 'experience in 20 years', 'Manufacturer', '', 4, 0, 111),
(46, 1, '17-05-2019', 'Fri', 'Rajesh', 'Credit society', 'Sai Baba urban Co-op credit society ltd', 'Ulhasnagar -.2', 'established for 8 years', 'Service Provider', '', 1, 0, 111),
(47, 1, '17-05-2019', 'Fri', 'Anyone', 'credit society', 'Any Co - op Credit society', '', '', '', '-', 0, 0, 222),
(48, 17, '17-05-2019', 'Fri', 'KARUNA', 'ENALTECH LAB ...PHARMA COMPANY', 'WORKING AS QUALITY ASSURANCE EXECUTIVE', 'ADDITIONAL AMBERNATH MIDC', 'ALSO GYM OWNER AND HOTEL OWNER AT KHADAK PADA KALYAN', 'Service Provider', '', 3, 0, 111),
(49, 17, '17-05-2019', 'Fri', 'YOUR FRIENDS', 'LOOKING FOR DOMESTIC WATER PURIFIERS', 'OR RELATIVES', '', '', '', '-', 0, 0, 222),
(50, 33, '18-05-2019', 'Sat', 'Akshay', 'School', 'Grand Gurukul school', 'Ambernath', '.', 'Service Provider', '', 2, 0, 111),
(51, 33, '18-05-2019', 'Sat', 'any school', 'school', 'any school', '', '', '', '-', 0, 0, 222),
(52, 17, '30-05-2019', 'Thu', 'KIRAN', 'ARCHITECT', 'KAMBLE', 'INTERNATIONAL ...EXPERIENCE LOCATED AMBERNATH', 'WORKED AT MALDEVES..DUBAI...', 'Service Provider', '', 2, 0, 111),
(53, 1, '06-06-2019', 'Thu', 'Mahesh', 'Electrical manufacturers', 'Alakh Industries', 'Ulhasnagar', 'good', 'Manufacturer', '', 1, 0, 111),
(54, 1, '06-06-2019', 'Thu', 'Any', 'Manufacturers', 'Electricals manufacturers', '', '', '', '-', 0, 0, 222),
(55, 7, '20-06-2019', 'Thu', 'Manish', 'Tours and Travels', 'Riya Holidays', 'Ulhasnagar', 'Travel Agent', 'Service Provider', '', 2, 0, 111),
(56, 13, '20-06-2019', 'Thu', 'Pratik', 'linen Supplier - Bedsheets Napkins etc', 'Pratik Marketing', 'Andheri', 'Strong', 'Distributor', '', 2, 0, 111),
(57, 13, '20-06-2019', 'Thu', 'Corporate Frequent Traveler', 'Banks and Marketing', 'Any Corporate', '', '', '', '-', 0, 0, 222),
(58, 30, '20-06-2019', 'Thu', 'arjun lad', 'cutting punch', 'punch maker', 'ulhasnagar', 'very kind, reasonable, co-operative', 'Manufacturer', '', 2, 0, 111),
(59, 30, '20-06-2019', 'Thu', 'purchase manager', 'baker', 'bakers boat', '', '', '', '-', 0, 0, 222),
(60, 1, '27-06-2019', 'Thu', 'Dr. Shweta Kaurani', 'Sono and X ray diagnostic center', 'Satyam Diagnostic center', 'Ambernath', 'all types of sonography and x-rays', 'Service Provider', '', 1, 0, 111),
(61, 1, '27-06-2019', 'Thu', 'Any', 'Diagnostic center', 'Sonography and X ray diagnostic center', '', '', '', '-', 0, 0, 222),
(62, 13, '18-07-2019', 'Thu', 'Mukesh Paryani', 'Doctor', 'Eye Surgeon - Doctor Mukesh', 'Pune', 'MD - Eye Surgeon', 'Service Provider', '', 1, 0, 111),
(63, 13, '18-07-2019', 'Thu', 'Corporate Traveler', 'Banks', 'Banks', '', '', '', '-', 0, 0, 222),
(64, 34, '10-08-2019', 'Sat', 'Zafar Ahmed', 'Hospital', 'Maxlife Hospital', 'Shantinagar ulhasnagar 3', '-', 'Service Provider', '', 1, 0, 111),
(65, 34, '10-08-2019', 'Sat', 'Mr.Ravi', 'Builders', 'Tharwani Builders', '', '', '', '-', 0, 0, 222);

-- --------------------------------------------------------

--
-- Table structure for table `bni_like_detail`
--

CREATE TABLE `bni_like_detail` (
  `id` int(11) NOT NULL,
  `g_a_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bni_like_detail`
--

INSERT INTO `bni_like_detail` (`id`, `g_a_id`, `user_id`) VALUES
(153, 36, 23),
(152, 42, 1),
(143, 31, 1),
(146, 36, 1),
(145, 35, 1),
(139, 29, 31),
(138, 30, 31),
(189, 44, 1),
(140, 27, 1),
(190, 45, 22),
(191, 31, 22),
(192, 35, 22),
(193, 48, 1),
(194, 36, 33),
(195, 45, 33),
(196, 48, 33),
(197, 50, 1),
(198, 50, 11),
(199, 52, 1),
(200, 34, 7),
(201, 32, 7),
(202, 30, 7),
(203, 29, 7),
(204, 45, 41),
(205, 53, 21),
(206, 55, 21),
(214, 56, 1),
(209, 31, 30),
(212, 48, 21),
(213, 52, 21),
(215, 58, 21),
(216, 60, 27),
(217, 45, 27),
(218, 56, 9),
(219, 46, 9),
(220, 36, 9),
(224, 62, 1),
(223, 58, 1),
(227, 64, 1),
(226, 55, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bni_user`
--

CREATE TABLE `bni_user` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(350) NOT NULL,
  `category` varchar(350) NOT NULL,
  `company_name` varchar(350) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `business_keyword` text NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `create_date_time` datetime NOT NULL,
  `chapter_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bni_user`
--

INSERT INTO `bni_user` (`user_id`, `full_name`, `category`, `company_name`, `mobile`, `email`, `password`, `business_keyword`, `address`, `image`, `create_date_time`, `chapter_id`) VALUES
(1, 'Naresh Gwalani', 'Mobile App Developer', 'JMD Infotech', '9890322940', 'naresh@gmail.com', 'naresh123', 'android, php', 'Kailash Colony Ulhasnagr 5', 'http://mezyapps.com/ournetworth/json/uploads/20190806123318784586528.jpg', '0000-00-00 00:00:00', 1),
(7, 'Sanjay Vaswani', 'Tax Consultant', 'RS Consultancy', '9373343000', '-', 'sanjay123', 'Income Tax,GST', '-', 'http://mezyapps.com/ournetworth/json/uploads/201905181247372014808008.jpg', '0000-00-00 00:00:00', 0),
(8, 'Sarvesh Chaubey', 'Food Franchise', 'The Biryani House', '7045322155', 'sarveshchaubey24@gmail.com', 'sarvesh123', 'Food franchise ', 'kalyan', '', '0000-00-00 00:00:00', 0),
(6, 'Chhaya Anand', 'Computer Hardware', 'Shree Computers', '7021263283', '', 'chhaya123', 'hardware,networking', '-', '', '0000-00-00 00:00:00', 0),
(9, 'Amit Ruchandani', 'Home Loans', 'Millionaire Consultants', '9823598628', 'amitruchandani@gmail.com', 'amit123', 'home loans', 'ulhasnagar ', '', '0000-00-00 00:00:00', 0),
(10, 'Sunil Garud', 'Event Management', 'Khushi Events Management', '8007262103', 'khushievents2015@gmail.com', 'sunil123', 'event management', 'ambernath', '', '0000-00-00 00:00:00', 0),
(11, 'Vinod Jagiasi', 'General Insurance', 'Fin Assure', '8007721313', 'vinod.ioe@gmail.com', 'vinod123', 'Fire Insurance, Health Insurance', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(12, 'Nandu Kumavat', 'Life Insurance', 'Nandu Kumavat', '9764323386', 'nbkumavat@gmail.com', 'nandu123', 'Life Insurance', 'kalyan', '', '0000-00-00 00:00:00', 0),
(13, 'Satish Sabhandasani', 'Online Travel Portal', 'StayQuick E-Booking LLP', '7588998833', 'satish@stayquick.in', 'satish123', 'Online travel booking for hotels,flights', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(17, 'Jugesh Sharma', 'Water Purification Systems', 'JSK Appliances', '8007498149', 'jskappliances@gmail.com', 'jugesh123', 'water purification system, ro water system', 'kalyan', 'http://mezyapps.com/ournetworth/json/uploads/20190517123330229226609.jpg', '0000-00-00 00:00:00', 0),
(18, 'Ratan Rajai', 'Hotel', 'River Winds Resort', '8888844888', 'ratan.rajai@gmail.com', 'ratan123', 'Hotel Bookings for Group Picni, One Day Picnic, Family Get Togather', 'kalyan', 'http://mezyapps.com/ournetworth/json/uploads/201906191828171859474688.jpg', '0000-00-00 00:00:00', 0),
(19, 'Shilpa Kurhade', 'Counselling', 'DYB Consultancy Pvt Ltd.', '7666011199', 'shilpa@decodeyourbrain.in', 'shilpa123', 'Counselling For Children', 'kalyan', '', '0000-00-00 00:00:00', 0),
(20, 'Arjun Kuna', 'Graphic Designer', 'Ardent Design Studio', '8308506871', 'ardentdzn@gmail.com', 'arjun123', 'Visiting Card, Brochures, Flyers , Advertisements', 'Ulhasnagar 3', '', '0000-00-00 00:00:00', 0),
(21, 'Kirti Murpani', 'Web Design & Development', 'Reyama Technology Pvt Ltd.', '7715922533', 'kirtimurpani@gmail.com', 'kirti123', 'E-COMMERCE WEBSITE,STATIC AND DYNAMIC BUSINESS WEBSITES', '', '', '0000-00-00 00:00:00', 0),
(22, 'Deepak Mahale', 'Corporate Gifting', 'Kedar Enterprises', '8369767459', 'kedar.enterprise123@gmail.com', 'deepak123', 'giftings', 'ulhasnagar', 'http://mezyapps.com/ournetworth/json/uploads/201905131143382070162662.jpg', '0000-00-00 00:00:00', 0),
(23, 'Niranjan Kuna', 'Digital Marketing', 'Ho Jao Digital', '7507667508', 'niranjank@hojaodigital.com', 'niranjan12', 'social media marketing', 'badlapur', '', '0000-00-00 00:00:00', 0),
(24, 'Balwantpal Singh Marwaha', 'Packaged Drinking Water', 'Marwaha Enterprises', '9320413131', 'marwahaindustries@gmail.com', 'balwant123', 'packaged drinking water', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(26, 'Rajkumar Tolani', 'Chartered Accountant', 'R.G. Tolani & Associates', '9322006675', 'carajkumartolani@gmail.com', 'rajkumar12', 'Audit, Finalisation of Accounts', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(27, 'Santosh Pamnani', 'Offset Printing', 'Shree Sai Creations', '9226171888', 'sscshreesaicreation@gmail.com', 'santosh123', 'Offset Printing', 'ulhasnagar', 'http://mezyapps.com/ournetworth/json/uploads/201906270737541135609613.jpg', '0000-00-00 00:00:00', 0),
(28, 'Chandrashekhar Rodda', 'Uniform Manufacturer', 'Chandra Sohan Garments', '9146300358', 'cblt8430@gmail.com', 'chandrashe', 'Uniforms Manufacturers', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(29, 'Sangeeta Gaikwad', 'Corrugated Box', 'Phoenix Engineering Works', '9987976177', 'nktgaikwad@yahoo.co.in', 'sangeeta12', 'corrugated box', 'badlapur', '', '0000-00-00 00:00:00', 0),
(30, 'Jayesh Marathe', 'Blister Packaging', 'Vishal Plast', '7977128284', 'vishalplast@gmail.com', 'jayesh123', 'blister packaging', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(32, 'Atul Kudtarkar', 'Structural Consultant', 'Atul Kudtarkar & Associates', '8007863744', 'atulmon2@gmail.com', 'atul123', 'structural consultant', 'badlapur', '', '0000-00-00 00:00:00', 0),
(33, 'Sanchita Roy', 'Electronic Security Systems', 'Matrix Technologies', '7507333000', 'matrixsoftwareindia@gmail.com', 'sanchita12', 'cctv,security systems', 'ulhasnagar', 'http://mezyapps.com/ournetworth/json/uploads/201906191346291337814447.jpg', '0000-00-00 00:00:00', 0),
(34, 'Pankaj Udasi', 'Pest Control Services', 'Oolite Pest Controls', '8237966000', 'oolitepestcontrols@gmail.com', 'pankaj123', 'pest control for home,offices,cars', 'ulhasnagar', 'http://mezyapps.com/ournetworth/json/uploads/20190628073421562758069.jpg', '0000-00-00 00:00:00', 0),
(35, 'Vijay Telang', 'Chair Manufacturer', 'Neelkant Designer Chairs', '8875215497', 'neelkanthdesignerchairs2015@gmail.com', 'vijay123', 'revolving chair mfrs', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(36, 'Herjinder Sangtani', 'Digital Paintings', 'Satnam Laminations and Frames', '8087174510', 'pritamsingh1910@gmail.com', 'herjinder1', 'Digital Paintings', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(37, 'Ajinkya Deoghare', 'Fire Equipments & Services', 'World Fire Safety System', '9552486108', 'worldfire26@gmail.com', 'ajinkya123', 'Fire alarm system', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(38, 'Avinash Patil', 'Security Manpower Provider', 'Marshal Security Power Services', '9975590237', '78avinashpatil@gmail.com', 'avinash123', 'security manpower services', 'bhiwandi', '', '0000-00-00 00:00:00', 0),
(39, 'Rahul Ramrakhyani', 'PVC Flooring', 'Foam N Flooring', '8149392323', 'foamflooring2003@gmail.com', 'rahul123', 'pvc flooring', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(40, 'Rajesh Kadam', 'Photo Frame Mfg', 'Lords Framing', '9323696099', 'rajeshlordsframing4@gmail.com', 'rajesh123', 'photo frame mfrs', 'ulhasnagar', '', '0000-00-00 00:00:00', 0),
(41, 'Sonal Ambekar', 'Fine Arts/Artist', 'MuktRang Arts', '9898980277', 'muktrang.kala@gmail.com', 'sonal123', 'fine arts, Painting, crafts, art classes, fine art CET, NATA,', 'MuktRang Art Academy, Mehul Villa, Shop no 2, Rambag 4, Kalyan', '', '0000-00-00 00:00:00', 0),
(42, 'Deepak Ghyar', 'Air Conditioner Sales & Services', 'Shree Enterprises', '8652321515', 'shree.enterprises00018@gmail.com', 'deepak123', 'Air Conditionar Services', 'kalyan', '', '0000-00-00 00:00:00', 0),
(43, 'Navin Chavan', 'Regional Director', 'BNI Umang', '9768131222', 'navin@bni-india.in', 'navin123', 'Trainer,Motivator,Business Coach', 'Navi Mumbai', '', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `date_wise_emp_details`
-- (See below for the actual view)
--
CREATE TABLE `date_wise_emp_details` (
`emp_id` varchar(100)
,`login_date` date
,`login` varchar(30)
,`logout` varchar(30)
,`day_min` varchar(100)
,`work_min` varchar(100)
,`location_in` varchar(200)
,`location_out` varchar(200)
,`status` varchar(100)
,`add_min` double
,`less_min` double
);

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_user`
--

CREATE TABLE `enquiry_user` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry_user`
--

INSERT INTO `enquiry_user` (`id`, `name`, `mobile`, `email`, `message`) VALUES
(11, 'NARESH', '9890322940', 'nareshgwalani.g@gmail.com', 'hi'),
(14, 'Kelabsemo', '86427746884', 'kelKeeree@emaill.host', 'Avanafil 200 Mg  <a href=http://gaprap.com>viagra online prescription</a> Vente Cialis Generique Pas Cher Cialis 20 Mg Effets Dangers With Expired Cephalexin  Propecia Sperm Analysis  <a href=http://sildenafbuy.com>viagra</a> Pastillas Para La Ereccion  The Antibiotic Cephalexin Cheap Viagra 25mg Real Viagra Pills Cheapest  <a href=http://rxbill6.com>levitra sold over the counter</a> Cytotec Vs Misoprostol Viagra Delivery France Levitra Compresse Essere  Levitra Paypal Accepted Finasterid 1mg Kaufen Ohne Rezept  <a href=http://bestviaonline.com>generic viagra</a> Order Azithromycin Online  '),
(15, 'NARESH', '9890322940', 'nareshgwalani.g@gmail.com', 'i required '),
(22, '', '', '', ''),
(21, 'EllSminee', '82432412813', 'elldift@zmail.website', 'Pro Cialis 20 Mg  <a href=http://banzell.net>viagra</a> Discount Acticin Store Cialis Et Glaucome Benadryl  '),
(23, 'BusinessCapitalAdvisors', 'noreply@business-capital-advisors.com', 'noreply@business-capital-advisors.com', 'Hi, letting you know that http://Business-Capital-Advisors.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. \r\n \r\nFind Out how much you qualify for by clicking here: \r\n \r\nhttp://Business-Capital-Advisors.com \r\n \r\nMinimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. \r\n \r\nThis is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. \r\n \r\nIf you need fast and easy business funding take a look at these programs now as there is limited availability: \r\n \r\nhttp://Business-Capital-Advisors.com \r\n \r\nHave a great day, \r\nThe Business Capital Advisors Team \r\n \r\nunsubscribe/remove - http://business-capital-advisors.com/r.php?url=jmd-infotech.com&id=e158'),
(24, 'Ultimate', 'noreply@get-more-leads-now.com', 'noreply@get-more-leads-now.com', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. \r\n \r\nDownload and install now to be building databases of leads in minutes: \r\n \r\nhttp://Get-More-Leads-Now.com \r\n \r\nThe Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. \r\n \r\nThis pack is only available on sale as a short promotional offer, please download now if at all interested. \r\n \r\nClick Here: http://Get-More-Leads-Now.com \r\n \r\nHave a Great Day, \r\nThe Ultimate Lead Generation Pack Team \r\n \r\nunsubscribe/remove Here: http://get-more-leads-now.com/r.php?url=jmd-infotech.com&id=ulg14'),
(25, '', '', '', ''),
(26, '', '', '', ''),
(27, '', '', '', ''),
(28, '', '', '', ''),
(29, 'FURdCQLnbsNm', '6597074007', 'fredericamccarthy8196@gmail.com', ''),
(30, 'Stevsach', '85492128379', 'carrington@miki7.site', 'Where To Buy Metronidazole Doxycycline Mail Order Virginia Beach  <a href=http://eulexin.net>viagra prescription</a> Propecia E Impotencia Comprar  '),
(31, '', '', '', ''),
(32, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `j_admin_user`
--

CREATE TABLE `j_admin_user` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_admin_user`
--

INSERT INTO `j_admin_user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `j_atendance`
--

CREATE TABLE `j_atendance` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `c_date` datetime NOT NULL,
  `login_date` date NOT NULL,
  `login_time` varchar(30) NOT NULL,
  `logout_time` varchar(30) NOT NULL,
  `login_date_time` datetime NOT NULL,
  `tag` varchar(5) NOT NULL,
  `total_minut` varchar(100) NOT NULL,
  `work_time` varchar(100) NOT NULL,
  `bal_minut` varchar(100) NOT NULL,
  `location_in` varchar(200) NOT NULL,
  `location_out` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_atendance`
--

INSERT INTO `j_atendance` (`id`, `emp_id`, `c_date`, `login_date`, `login_time`, `logout_time`, `login_date_time`, `tag`, `total_minut`, `work_time`, `bal_minut`, `location_in`, `location_out`, `status`) VALUES
(456, '009', '2019-05-22 17:35:04', '2019-05-06', '12:24', ' ', '2019-05-06 12:24:00', 'I', '', '', '', '19.1996922,70.1744977', '', 'NM'),
(455, '009', '2019-05-22 17:34:16', '2019-05-04', ' ', '20:58', '2019-05-04 20:58:00', 'O', '510', '486', '-24', '', '19.1996801,73.1744916', ''),
(453, '009', '2019-05-22 17:33:15', '2019-05-03', ' ', '21:41', '2019-05-03 21:41:00', 'O', '510', '821', '311', '19.1996805,73.1745061', '', ''),
(454, '009', '2019-05-22 17:33:49', '2019-05-04', '12:52', ' ', '2019-05-04 12:52:00', 'I', '', '', '', '19.1996815,73.174504', '', 'NM'),
(452, '009', '2019-05-22 17:32:55', '2019-05-03', '08:00', ' ', '2019-05-03 08:00:00', 'I', '', '', '', '19.1996826,73.1745097', '', 'NM'),
(449, '009', '2019-05-22 17:31:08', '2019-05-01', ' ', '20:27', '2019-05-01 20:27:00', 'O', '510', '477', '-33', '19.1996727,73.1744917', '', ''),
(450, '009', '2019-05-22 17:31:42', '2019-05-02', '17:41', ' ', '2019-05-02 17:41:00', 'I', '', '', '', '19.1996707,73.1744846', '', 'EM'),
(451, '009', '2019-05-22 17:31:59', '2019-05-02', ' ', '20:50', '2019-05-02 20:50:00', 'O', '510', '189', '-321', '19.1996773,73.1744971', '', ''),
(445, '005', '2019-05-22 17:06:44', '2019-05-20', ' ', '18:24', '2019-05-20 18:24:00', 'O', '510', '473', '-37', '19.1996691,73.1744855', '', ''),
(446, '005', '2019-05-22 17:13:03', '2019-05-18', '10:32', ' ', '2019-05-18 10:32:00', 'I', '', '', '', '19.1996948,73.1745261', '', 'NM'),
(447, '005', '2019-05-22 17:13:38', '2019-05-18', ' ', '19:01', '2019-05-18 19:01:00', 'O', '510', '509', '-1', '19.1996875,73.1745102', '', ''),
(448, '009', '2019-05-22 17:30:20', '2019-05-01', '12:30', ' ', '2019-05-01 12:30:00', 'I', '', '', '', '19.1996746,73.1744943', '', 'NM'),
(437, '003', '2019-05-22 15:03:32', '2019-05-18', ' ', '19:01', '2019-05-18 19:01:00', 'O', '510', '505', '-5', '19.1997087,73.1745099', '', ''),
(436, '003', '2019-05-22 15:03:21', '2019-05-18', '10:36', ' ', '2019-05-18 10:36:00', 'I', '', '', '', '19.1997072,73.1745104', '', 'NM'),
(435, '003', '2019-05-22 15:00:12', '2019-05-20', ' ', '19:43', '2019-05-20 19:43:00', 'O', '510', '512', '2', '19.1997392,73.1745231', '', ''),
(442, '009', '2019-05-22 16:45:12', '2019-05-20', '15:09', ' ', '2019-05-20 15:09:00', 'I', '', '', '', '19.1997217,73.1745251', '', 'EM'),
(443, '009', '2019-05-22 16:45:29', '2019-05-20', ' ', '20:44', '2019-05-20 20:44:00', 'O', '510', '335', '-175', '19.199713,73.1745125', '', ''),
(444, '005', '2019-05-22 17:02:46', '2019-05-20', '10:31', ' ', '2019-05-20 10:31:00', 'I', '', '', '', '19.199716,73.174511', '', 'NM'),
(434, '003', '2019-05-22 14:59:47', '2019-05-20', '11:11', ' ', '2019-05-20 11:11:00', 'I', '', '', '', '19.1997027,73.1745084', '', 'NM'),
(433, '003', '2019-05-22 14:56:58', '2019-05-21', ' ', '19:21', '2019-05-21 19:21:00', 'O', '510', '511', '1', '19.1997264,73.1745264', '', ''),
(432, '003', '2019-05-22 14:56:39', '2019-05-21', '10:50', ' ', '2019-05-21 10:50:00', 'I', '', '', '', '19.1997256,73.1745339', '', 'NM'),
(430, '003', '2019-05-22 14:52:40', '2019-05-22', '10:20', ' ', '2019-05-22 10:20:00', 'I', '', '', '', '19.1997343,73.1745208', '', 'NM'),
(424, '005', '2019-05-22 13:10:40', '2019-05-22', '10:54', ' ', '2019-05-22 10:54:00', 'I', '', '', '', '19.1997443,73.1745486', '', 'NM'),
(427, '005', '2019-05-22 13:17:26', '2019-05-21', '10:28', ' ', '2019-05-21 10:28:00', 'I', '', '', '', '19.1997294,73.1745342', '', 'NM'),
(429, '005', '2019-05-22 13:18:36', '2019-05-21', ' ', '19:06', '2019-05-21 19:06:00', 'O', '510', '518', '8', '19.1997262,73.1745422', '', ''),
(457, '009', '2019-05-22 17:35:56', '2019-05-06', ' ', '22:15', '2019-05-06 22:15:00', 'O', '510', '591', '81', '19.1996883,73.1745071', '', ''),
(458, '009', '2019-05-22 17:37:24', '2019-05-07', '12:35', ' ', '2019-05-07 12:35:00', 'I', '', '', '', '19.1996871,73.1744885', '', 'NM'),
(459, '009', '2019-05-22 17:42:15', '2019-05-07', ' ', '21:13', '2019-05-07 21:13:00', 'O', '510', '518', '8', '19.1996733,73.1744908', '', ''),
(460, '009', '2019-05-22 17:43:08', '2019-05-08', '12:20', ' ', '2019-05-08 12:20:00', 'I', '', '', '', '19.1996682,73.1744867', '', 'NM'),
(461, '009', '2019-05-22 17:43:25', '2019-05-08', ' ', '21:19', '2019-05-08 21:19:00', 'O', '510', '539', '29', '19.1996689,73.1744904', '', ''),
(470, '009', '2019-05-22 17:54:26', '2019-05-09', '12:10', ' ', '2019-05-09 12:10:00', 'I', '', '', '', '19.1996888,73.1745116', '', 'NM'),
(464, '009', '2019-05-22 17:44:43', '2019-05-10', '12:05', ' ', '2019-05-10 12:05:00', 'I', '', '', '', '19.1996706,73.1745004', '', 'NM'),
(465, '009', '2019-05-22 17:45:03', '2019-05-10', ' ', '20:01', '2019-05-10 20:01:00', 'O', '510', '476', '-34', '19.1996693,73.1744877', '', ''),
(469, '009', '2019-05-22 17:53:13', '2019-05-11', ' ', '21:00', '2019-05-11 21:00:00', 'O', '510', '530', '20', '19.1996562,73.1745318', '', ''),
(468, '009', '2019-05-22 17:51:49', '2019-05-11', '12:10', ' ', '2019-05-11 12:10:00', 'I', '', '', '', '19.1997048,73.1745222', '', 'NM'),
(471, '009', '2019-05-22 17:54:48', '2019-05-09', ' ', '21:32', '2019-05-09 21:32:00', 'O', '510', '562', '52', '19.1997038,73.1745357', '', ''),
(472, '005', '2019-05-22 17:57:49', '2019-05-17', '10:30', ' ', '2019-05-17 10:30:00', 'I', '', '', '', '19.199686,73.1745085', '', 'NM'),
(473, '005', '2019-05-22 17:58:14', '2019-05-17', ' ', '19:55', '2019-05-17 19:55:00', 'O', '510', '565', '55', '19.1996944,73.1745274', '', ''),
(474, '005', '2019-05-22 17:58:47', '2019-05-16', '10:39', ' ', '2019-05-16 10:39:00', 'I', '', '', '', '19.1996764,73.1744989', '', 'NM'),
(475, '005', '2019-05-22 17:59:03', '2019-05-16', ' ', '19:35', '2019-05-16 19:35:00', 'O', '510', '536', '26', '19.1996764,73.1744989', '', ''),
(476, '005', '2019-05-22 17:59:30', '2019-05-15', '10:29', ' ', '2019-05-15 10:29:00', 'I', '', '', '', '19.1996755,73.174498', '', 'NM'),
(477, '005', '2019-05-22 17:59:53', '2019-05-15', ' ', '19:09', '2019-05-15 19:09:00', 'O', '510', '520', '10', '19.1996851,73.1745119', '', ''),
(478, '005', '2019-05-22 18:00:22', '2019-05-14', '10:37', ' ', '2019-05-14 10:37:00', 'I', '', '', '', '19.199685,73.1745073', '', 'NM'),
(479, '005', '2019-05-22 18:00:34', '2019-05-14', ' ', '19:16', '2019-05-14 19:16:00', 'O', '510', '519', '9', '19.1996849,73.1745072', '', ''),
(480, '005', '2019-05-22 18:01:12', '2019-05-13', '10:36', ' ', '2019-05-13 10:36:00', 'I', '', '', '', '19.1996887,73.1745139', '', 'NM'),
(481, '005', '2019-05-22 18:01:28', '2019-05-13', ' ', '19:17', '2019-05-13 19:17:00', 'O', '510', '521', '11', '19.1996778,73.1745007', '', ''),
(482, '005', '2019-05-22 18:02:28', '2019-05-11', '10:35', ' ', '2019-05-11 10:35:00', 'I', '', '', '', '19.1996768,73.1744996', '', 'NM'),
(483, '005', '2019-05-22 18:02:55', '2019-05-11', ' ', '19:05', '2019-05-11 19:05:00', 'O', '510', '510', '0', '19.1996861,73.1745085', '', ''),
(484, '005', '2019-05-22 18:03:16', '2019-05-10', '10:38', ' ', '2019-05-10 10:38:00', 'I', '', '', '', '19.1996771,73.1744999', '', 'NM'),
(485, '005', '2019-05-22 18:03:46', '2019-05-10', ' ', '17:00', '2019-05-10 17:00:00', 'O', '510', '382', '-128', '19.1996866,73.1745091', '', ''),
(486, '005', '2019-05-22 18:04:11', '2019-05-09', '10:30', ' ', '2019-05-09 10:30:00', 'I', '', '', '', '19.1996693,73.1744857', '', 'NM'),
(487, '005', '2019-05-22 18:05:02', '2019-05-09', ' ', '19:07', '2019-05-09 19:07:00', 'O', '510', '517', '7', '19.1996766,73.1745046', '', ''),
(488, '005', '2019-05-22 18:05:28', '2019-05-08', '10:30', ' ', '2019-05-08 10:30:00', 'I', '', '', '', '19.1996852,73.1745076', '', 'NM'),
(489, '005', '2019-05-22 18:06:09', '2019-05-08', ' ', '19:04', '2019-05-08 19:04:00', 'O', '510', '514', '4', '19.199676,73.1744985', '', ''),
(490, '005', '2019-05-22 18:07:22', '2019-05-07', '10:59', ' ', '2019-05-07 10:59:00', 'I', '', '', '', '19.1996865,73.1745091', '', 'NM'),
(491, '005', '2019-05-22 18:07:50', '2019-05-07', ' ', '20:25', '2019-05-07 20:25:00', 'O', '510', '566', '56', '19.1996906,73.174516', '', ''),
(1323, '004', '2019-06-10 18:08:28', '2019-06-05', '11:50', ' ', '2019-06-05 11:50:00', 'I', '', '', '', '19.1996373,73.174438', '', 'NM'),
(1322, '003', '2019-06-05 17:05:05', '2019-06-05', '10:55', ' ', '2019-06-05 10:55:00', 'I', '', '', '', '19.1996432,73.1744605', '', 'NM'),
(494, '010', '2019-05-22 18:16:32', '2019-05-22', '13:29', ' ', '2019-05-22 13:29:00', 'I', '', '', '', '19.1997194,73.1745163', '', 'EM'),
(495, '010', '2019-05-22 18:19:47', '2019-05-21', '12:00', ' ', '2019-05-21 12:00:00', 'I', '', '', '', '19.1996898,73.1745048', '', 'NM'),
(496, '010', '2019-05-22 18:20:53', '2019-05-21', ' ', '21:01', '2019-05-21 21:01:00', 'O', '540', '541', '1', '19.1996814,73.1744993', '', ''),
(497, '010', '2019-05-22 18:22:12', '2019-05-20', '12:05', ' ', '2019-05-20 12:05:00', 'I', '', '', '', '19.1997038,73.1745186', '', 'NM'),
(498, '010', '2019-05-22 18:22:39', '2019-05-20', ' ', '21:02', '2019-05-20 21:02:00', 'O', '540', '537', '-3', '19.1997038,73.1745186', '', ''),
(499, '010', '2019-05-22 18:24:02', '2019-05-18', '12:10', ' ', '2019-05-18 12:10:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'NM'),
(502, '010', '2019-05-22 18:32:25', '2019-05-18', ' ', '21:03', '2019-05-18 21:03:00', 'O', '540', '533', '-7', '19.1997371,73.1745586', '', ''),
(503, '004', '2019-05-22 18:33:31', '2019-05-21', '11:55', ' ', '2019-05-21 11:55:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'LM'),
(504, '004', '2019-05-22 18:35:10', '2019-05-21', ' ', '20:38', '2019-05-21 20:38:00', 'O', '540', '523', '-17', '19.1996691,73.1744855', '', ''),
(505, '003', '2019-05-22 18:36:13', '2019-05-01', '11:48', ' ', '2019-05-01 11:48:00', 'I', '', '', '', '19.1997231,73.1745452', '', 'NM'),
(506, '003', '2019-05-22 18:36:28', '2019-05-01', ' ', '19:41', '2019-05-01 19:41:00', 'O', '510', '473', '-37', '19.1997231,73.1745452', '', ''),
(507, '010', '2019-05-22 18:37:09', '2019-05-17', '12:04', ' ', '2019-05-17 12:04:00', 'I', '', '', '', '19.1997466,73.1745649', '', 'NM'),
(508, '010', '2019-05-22 18:37:35', '2019-05-17', ' ', '21:20', '2019-05-17 21:20:00', 'O', '540', '556', '16', '19.1997466,73.1745649', '', ''),
(509, '010', '2019-05-22 18:38:23', '2019-05-16', '12:09', ' ', '2019-05-16 12:09:00', 'I', '', '', '', '19.1997428,73.1745554', '', 'NM'),
(510, '010', '2019-05-22 18:38:39', '2019-05-16', ' ', '21:07', '2019-05-16 21:07:00', 'O', '540', '538', '-2', '19.1997428,73.1745554', '', ''),
(511, '003', '2019-05-22 18:38:53', '2019-05-02', '11:59', ' ', '2019-05-02 11:59:00', 'I', '', '', '', '19.1997343,73.1745538', '', 'NM'),
(512, '003', '2019-05-22 18:39:05', '2019-05-02', ' ', '20:36', '2019-05-02 20:36:00', 'O', '510', '517', '7', '19.1997388,73.1745574', '', ''),
(513, '010', '2019-05-22 18:39:18', '2019-05-15', '12:01', ' ', '2019-05-15 12:01:00', 'I', '', '', '', '19.199742,73.174543', '', 'NM'),
(514, '010', '2019-05-22 18:39:28', '2019-05-15', ' ', '21:02', '2019-05-15 21:02:00', 'O', '540', '541', '1', '19.199742,73.174543', '', ''),
(515, '010', '2019-05-22 18:40:04', '2019-05-14', '12:06', ' ', '2019-05-14 12:06:00', 'I', '', '', '', '19.1997493,73.1745487', '', 'NM'),
(516, '010', '2019-05-22 18:40:20', '2019-05-14', ' ', '21:03', '2019-05-14 21:03:00', 'O', '540', '537', '-3', '19.1997493,73.1745487', '', ''),
(517, '003', '2019-05-22 18:41:12', '2019-05-03', '12:32', ' ', '2019-05-03 12:32:00', 'I', '', '', '', '19.1997332,73.17455', '', 'LM'),
(518, '010', '2019-05-22 18:41:29', '2019-05-13', '11:41', ' ', '2019-05-13 11:41:00', 'I', '', '', '', '19.1997382,73.1745492', '', 'NM'),
(519, '003', '2019-05-22 18:41:35', '2019-05-03', ' ', '20:32', '2019-05-03 20:32:00', 'O', '510', '480', '-30', '19.1997391,73.1745522', '', ''),
(520, '010', '2019-05-22 18:41:41', '2019-05-13', ' ', '21:05', '2019-05-13 21:05:00', 'O', '540', '564', '24', '19.1997382,73.1745492', '', ''),
(521, '003', '2019-05-22 18:42:45', '2019-05-04', '11:57', ' ', '2019-05-04 11:57:00', 'I', '', '', '', '19.1997351,73.1745462', '', 'NM'),
(522, '010', '2019-05-22 18:42:48', '2019-05-11', '12:04', ' ', '2019-05-11 12:04:00', 'I', '', '', '', '19.1997325,73.1745418', '', 'NM'),
(523, '010', '2019-05-22 18:43:01', '2019-05-11', ' ', '21:02', '2019-05-11 21:02:00', 'O', '540', '538', '-2', '19.1997325,73.1745418', '', ''),
(524, '003', '2019-05-22 18:43:02', '2019-05-04', ' ', '20:20', '2019-05-04 20:20:00', 'O', '510', '503', '-7', '19.1997341,73.1745471', '', ''),
(525, '010', '2019-05-22 18:43:46', '2019-05-10', '11:58', ' ', '2019-05-10 11:58:00', 'I', '', '', '', '19.1997454,73.1745587', '', 'NM'),
(526, '010', '2019-05-22 18:43:58', '2019-05-10', ' ', '20:55', '2019-05-10 20:55:00', 'O', '540', '537', '-3', '19.1997454,73.1745587', '', ''),
(570, '004', '2019-05-22 18:59:12', '2019-05-03', ' ', '20:28', '2019-05-03 20:28:00', 'O', '540', '539', '-1', '19.1996691,73.1744855', '', ''),
(569, '004', '2019-05-22 18:58:41', '2019-05-03', '11:29', ' ', '2019-05-03 11:29:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'NM'),
(529, '003', '2019-05-22 18:46:27', '2019-05-06', '11:58', ' ', '2019-05-06 11:58:00', 'I', '', '', '', '19.1997173,73.1745386', '', 'NM'),
(530, '003', '2019-05-22 18:46:45', '2019-05-06', ' ', '20:30', '2019-05-06 20:30:00', 'O', '510', '512', '2', '19.1997239,73.1745399', '', ''),
(531, '010', '2019-05-22 18:46:59', '2019-05-08', '12:05', ' ', '2019-05-08 12:05:00', 'I', '', '', '', '19.1997296,73.1745428', '', 'NM'),
(532, '010', '2019-05-22 18:47:23', '2019-05-08', ' ', '21:00', '2019-05-08 21:00:00', 'O', '540', '535', '-5', '19.1997296,73.1745428', '', ''),
(533, '003', '2019-05-22 18:47:42', '2019-05-07', '10:45', ' ', '2019-05-07 10:45:00', 'I', '', '', '', '19.1997331,73.1745511', '', 'NM'),
(534, '003', '2019-05-22 18:48:16', '2019-05-07', ' ', '19:45', '2019-05-07 19:45:00', 'O', '510', '540', '30', '19.1996786,73.1745091', '', ''),
(535, '010', '2019-05-22 18:48:20', '2019-05-07', '12:06', ' ', '2019-05-07 12:06:00', 'I', '', '', '', '19.1997469,73.1745609', '', 'NM'),
(536, '010', '2019-05-22 18:48:32', '2019-05-07', ' ', '21:12', '2019-05-07 21:12:00', 'O', '540', '546', '6', '19.1997469,73.1745609', '', ''),
(537, '003', '2019-05-22 18:49:31', '2019-05-09', '11:49', ' ', '2019-05-09 11:49:00', 'I', '', '', '', '19.1997345,73.1745396', '', 'NM'),
(538, '010', '2019-05-22 18:49:32', '2019-05-06', '11:36', ' ', '2019-05-06 11:36:00', 'I', '', '', '', '19.1997469,73.1745608', '', 'NM'),
(539, '003', '2019-05-22 18:49:45', '2019-05-09', ' ', '20:49', '2019-05-09 20:49:00', 'O', '510', '540', '30', '19.1997367,73.1745418', '', ''),
(540, '010', '2019-05-22 18:49:46', '2019-05-06', ' ', '20:58', '2019-05-06 20:58:00', 'O', '540', '562', '22', '19.1997469,73.1745608', '', ''),
(541, '003', '2019-05-22 18:50:12', '2019-05-10', '11:51', ' ', '2019-05-10 11:51:00', 'I', '', '', '', '19.1997445,73.17456', '', 'NM'),
(542, '010', '2019-05-22 18:50:41', '2019-05-04', '11:49', ' ', '2019-05-04 11:49:00', 'I', '', '', '', '19.1997498,73.1745534', '', 'NM'),
(543, '003', '2019-05-22 18:50:45', '2019-05-10', ' ', '20:50', '2019-05-10 20:50:00', 'O', '510', '539', '29', '19.199737,73.1745522', '', ''),
(544, '010', '2019-05-22 18:50:52', '2019-05-04', ' ', '20:57', '2019-05-04 20:57:00', 'O', '540', '548', '8', '19.1997498,73.1745534', '', ''),
(545, '003', '2019-05-22 18:51:14', '2019-05-11', '11:44', ' ', '2019-05-11 11:44:00', 'I', '', '', '', '19.1997463,73.1745615', '', 'NM'),
(546, '010', '2019-05-22 18:51:25', '2019-05-03', '12:04', ' ', '2019-05-03 12:04:00', 'I', '', '', '', '19.1997267,73.1745426', '', 'NM'),
(547, '003', '2019-05-22 18:51:28', '2019-05-11', ' ', '20:31', '2019-05-11 20:31:00', 'O', '510', '527', '17', '19.1997303,73.1745462', '', ''),
(548, '010', '2019-05-22 18:51:45', '2019-05-03', ' ', '20:59', '2019-05-03 20:59:00', 'O', '540', '535', '-5', '19.1997267,73.1745426', '', ''),
(549, '003', '2019-05-22 18:52:03', '2019-05-13', '11:42', ' ', '2019-05-13 11:42:00', 'I', '', '', '', '19.1997422,73.174547', '', 'NM'),
(550, '003', '2019-05-22 18:52:18', '2019-05-13', ' ', '20:23', '2019-05-13 20:23:00', 'O', '510', '521', '11', '19.1997505,73.174555', '', ''),
(551, '003', '2019-05-27 14:46:51', '2019-05-14', '10:22', ' ', '2019-05-14 10:22:00', 'I', '', '', '', '-', '', 'NM'),
(552, '003', '2019-05-27 14:46:51', '2019-05-14', ' ', '19:07', '2019-05-14 19:07:00', 'O', '510', '525', '15', '19.1997468,73.1745611', '-', ''),
(565, '003', '2019-05-22 18:57:21', '2019-05-17', '10:40', ' ', '2019-05-17 10:40:00', 'I', '', '', '', '19.199745,73.1745589', '', 'NM'),
(564, '010', '2019-05-22 18:57:17', '2019-05-02', '11:50', ' ', '2019-05-02 11:50:00', 'I', '', '', '', '19.1997093,73.1745223', '', 'NM'),
(555, '003', '2019-05-22 18:53:47', '2019-05-15', '10:26', ' ', '2019-05-15 10:26:00', 'I', '', '', '', '19.1997507,73.1745559', '', 'NM'),
(556, '003', '2019-05-22 18:54:10', '2019-05-15', ' ', '19:08', '2019-05-15 19:08:00', 'O', '510', '522', '12', '19.1997401,73.1745517', '', ''),
(557, '010', '2019-05-22 18:54:14', '2019-05-01', '12:09', ' ', '2019-05-01 12:09:00', 'I', '', '', '', '19.1997407,73.1745589', '', 'NM'),
(558, '010', '2019-05-22 18:54:29', '2019-05-01', ' ', '21:00', '2019-05-01 21:00:00', 'O', '540', '531', '-9', '19.1997407,73.1745589', '', ''),
(559, '003', '2019-05-22 18:54:49', '2019-05-16', '10:28', ' ', '2019-05-16 10:28:00', 'I', '', '', '', '19.1997402,73.1745741', '', 'NM'),
(560, '003', '2019-05-22 18:55:04', '2019-05-16', ' ', '19:06', '2019-05-16 19:06:00', 'O', '510', '518', '8', '19.1997427,73.1745629', '', ''),
(606, '004', '2019-05-22 19:37:32', '2019-05-02', '11:47', ' ', '2019-05-02 11:47:00', 'I', '', '', '', '19.1997228,73.1745576', '', 'LM'),
(605, '004', '2019-05-22 19:37:06', '2019-05-01', ' ', '20:28', '2019-05-01 20:28:00', 'O', '540', '546', '6', '19.1997082,73.1745364', '', ''),
(604, '004', '2019-05-22 19:36:48', '2019-05-01', '11:22', ' ', '2019-05-01 11:22:00', 'I', '', '', '', '19.1997096,73.1745345', '', 'NM'),
(567, '003', '2019-05-22 18:57:39', '2019-05-17', ' ', '19:11', '2019-05-17 19:11:00', 'O', '510', '511', '1', '19.1997413,73.174546', '', ''),
(568, '010', '2019-05-22 18:57:52', '2019-05-02', ' ', '20:59', '2019-05-02 20:59:00', 'O', '540', '549', '9', '19.1997395,73.1745732', '', ''),
(571, '010', '2019-05-22 18:59:28', '2019-05-09', '11:57', ' ', '2019-05-09 11:57:00', 'I', '', '', '', '19.1997093,73.1745225', '', 'NM'),
(572, '010', '2019-05-22 18:59:50', '2019-05-09', ' ', '20:58', '2019-05-09 20:58:00', 'O', '540', '541', '1', '19.1997093,73.1745225', '', ''),
(574, '004', '2019-05-22 19:03:11', '2019-05-04', '11:30', ' ', '2019-05-04 11:30:00', 'I', '', '', '', '19.1996717,73.1744851', '', 'NM'),
(575, '004', '2019-05-22 19:03:27', '2019-05-04', ' ', '20:35', '2019-05-04 20:35:00', 'O', '540', '545', '5', '19.1996717,73.1744851', '', ''),
(576, '004', '2019-05-22 19:05:12', '2019-05-06', '10:45', ' ', '2019-05-06 10:45:00', 'I', '', '', '', '19.1996894,73.1744978', '', 'NM'),
(577, '004', '2019-05-22 19:05:56', '2019-05-07', '11:04', ' ', '2019-05-07 11:04:00', 'I', '', '', '', '19.1996731,73.1744852', '', 'NM'),
(578, '004', '2019-05-22 19:06:09', '2019-05-07', ' ', '20:00', '2019-05-07 20:00:00', 'O', '540', '536', '-4', '19.1996691,73.1744855', '', ''),
(579, '004', '2019-05-22 19:06:56', '2019-05-08', '11:04', ' ', '2019-05-08 11:04:00', 'I', '', '', '', '19.1997214,73.1745211', '', 'NM'),
(580, '004', '2019-05-22 19:07:17', '2019-05-08', ' ', '20:08', '2019-05-08 20:08:00', 'O', '540', '544', '4', '19.1996691,73.1744855', '', ''),
(581, '004', '2019-05-22 19:08:15', '2019-05-09', '11:35', ' ', '2019-05-09 11:35:00', 'I', '', '', '', '19.1996985,73.1745022', '', 'NM'),
(582, '004', '2019-05-22 19:08:35', '2019-05-09', ' ', '20:34', '2019-05-09 20:34:00', 'O', '540', '539', '-1', '19.1997098,73.1745032', '', ''),
(583, '004', '2019-05-22 19:08:55', '2019-05-10', '15:31', ' ', '2019-05-10 15:31:00', 'I', '', '', '', '19.1997098,73.1745032', '', 'EM'),
(584, '004', '2019-05-22 19:09:07', '2019-05-10', ' ', '20:31', '2019-05-10 20:31:00', 'O', '540', '300', '-240', '19.1996691,73.1744855', '', ''),
(585, '004', '2019-05-22 19:09:34', '2019-05-11', '11:02', ' ', '2019-05-11 11:02:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'NM'),
(586, '004', '2019-05-22 19:09:43', '2019-05-11', ' ', '20:06', '2019-05-11 20:06:00', 'O', '540', '544', '4', '19.199688,73.1744896', '', ''),
(587, '004', '2019-05-22 19:10:18', '2019-05-13', '11:30', ' ', '2019-05-13 11:30:00', 'I', '', '', '', '19.1997012,73.1744998', '', 'NM'),
(588, '004', '2019-05-22 19:10:29', '2019-05-13', ' ', '20:35', '2019-05-13 20:35:00', 'O', '540', '545', '5', '19.1997012,73.1744998', '', ''),
(589, '004', '2019-05-22 19:10:59', '2019-05-14', '13:06', ' ', '2019-05-14 13:06:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'EM'),
(590, '003', '2019-05-22 19:13:00', '2019-05-22', ' ', '19:08', '2019-05-22 19:08:00', 'O', '510', '528', '18', '19.1997157,73.1745538', '', ''),
(591, '004', '2019-05-22 19:13:04', '2019-05-14', ' ', '20:31', '2019-05-14 20:31:00', 'O', '540', '445', '-95', '19.1996981,73.1745154', '', ''),
(592, '004', '2019-05-22 19:13:49', '2019-05-15', '11:33', ' ', '2019-05-15 11:33:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'NM'),
(593, '004', '2019-05-22 19:14:01', '2019-05-15', ' ', '20:29', '2019-05-15 20:29:00', 'O', '540', '536', '-4', '19.199673,73.174486', '', ''),
(594, '004', '2019-05-22 19:14:30', '2019-05-16', '11:39', ' ', '2019-05-16 11:39:00', 'I', '', '', '', '19.1996702,73.1744856', '', 'LM'),
(595, '004', '2019-05-22 19:14:51', '2019-05-16', ' ', '20:41', '2019-05-16 20:41:00', 'O', '540', '542', '2', '19.1996691,73.1744855', '', ''),
(649, '005', '2019-05-23 10:36:19', '2019-05-23', '10:28', ' ', '2019-05-23 10:28:00', 'I', '', '', '', '19.1997496,73.1745755', '', 'NM'),
(598, '004', '2019-05-22 19:20:50', '2019-05-17', '11:41', ' ', '2019-05-17 11:41:00', 'I', '', '', '', '19.1997073,73.1745281', '', 'HM'),
(599, '004', '2019-05-22 19:21:06', '2019-05-17', ' ', '20:35', '2019-05-17 20:35:00', 'O', '540', '534', '-6', '19.1997161,73.1745345', '', ''),
(600, '004', '2019-05-22 19:21:31', '2019-05-18', '11:40', ' ', '2019-05-18 11:40:00', 'I', '', '', '', '19.1997161,73.174532', '', 'HM'),
(601, '004', '2019-05-22 19:21:39', '2019-05-18', ' ', '20:37', '2019-05-18 20:37:00', 'O', '540', '537', '-3', '19.1997161,73.174532', '', ''),
(602, '004', '2019-05-22 19:21:53', '2019-05-20', '11:25', ' ', '2019-05-20 11:25:00', 'I', '', '', '', '19.1996691,73.1744855', '', 'NM'),
(603, '004', '2019-05-22 19:22:02', '2019-05-20', ' ', '20:27', '2019-05-20 20:27:00', 'O', '540', '542', '2', '19.1996691,73.1744855', '', ''),
(607, '004', '2019-05-22 19:37:45', '2019-05-02', ' ', '20:33', '2019-05-02 20:33:00', 'O', '540', '526', '-14', '19.1997268,73.1745691', '', ''),
(609, '004', '2019-05-22 19:39:34', '2019-05-06', ' ', '19:46', '2019-05-06 19:46:00', 'O', '540', '541', '1', '19.1997178,73.1745303', '', ''),
(610, '011', '2019-05-22 19:40:55', '2019-05-11', '12:01', ' ', '2019-05-11 12:01:00', 'I', '', '', '', '19.199876,73.1747281', '', 'NM'),
(611, '011', '2019-05-22 19:41:35', '2019-05-11', ' ', '21:02', '2019-05-11 21:02:00', 'O', '540', '541', '1', '19.1997028,73.1745302', '', ''),
(612, '011', '2019-05-22 19:45:22', '2019-05-13', '12:21', ' ', '2019-05-13 12:21:00', 'I', '', '', '', '19.1997178,73.1745378', '', 'LM'),
(613, '011', '2019-05-22 19:46:37', '2019-05-13', ' ', '21:06', '2019-05-13 21:06:00', 'O', '540', '525', '-15', '19.1998433,73.1747058', '', ''),
(614, '011', '2019-05-22 19:47:59', '2019-05-14', '11:58', ' ', '2019-05-14 11:58:00', 'I', '', '', '', '19.1996847,73.1745026', '', 'NM'),
(615, '011', '2019-05-22 19:48:26', '2019-05-14', ' ', '21:04', '2019-05-14 21:04:00', 'O', '540', '546', '6', '19.1998651,73.1747156', '', ''),
(616, '011', '2019-05-22 19:48:52', '2019-05-15', '11:58', ' ', '2019-05-15 11:58:00', 'I', '', '', '', '19.1997013,73.174528', '', 'NM'),
(617, '011', '2019-05-22 19:49:17', '2019-05-15', ' ', '21:03', '2019-05-15 21:03:00', 'O', '540', '545', '5', '19.1997601,73.1745925', '', ''),
(618, '011', '2019-05-22 19:51:13', '2019-05-16', '11:57', ' ', '2019-05-16 11:57:00', 'I', '', '', '', '19.1997358,73.1745664', '', 'NM'),
(619, '011', '2019-05-22 19:51:41', '2019-05-16', ' ', '21:08', '2019-05-16 21:08:00', 'O', '540', '551', '11', '19.1997172,73.1745414', '', ''),
(620, '011', '2019-05-22 19:52:47', '2019-05-17', '12:05', ' ', '2019-05-17 12:05:00', 'I', '', '', '', '19.1997608,73.1745957', '', 'NM'),
(621, '011', '2019-05-22 19:54:05', '2019-05-17', ' ', '21:08', '2019-05-17 21:08:00', 'O', '540', '543', '3', '19.1997723,73.1746002', '', ''),
(622, '011', '2019-05-22 19:54:41', '2019-05-18', '11:56', ' ', '2019-05-18 11:56:00', 'I', '', '', '', '19.1998729,73.1747261', '', 'NM'),
(623, '011', '2019-05-22 19:55:05', '2019-05-18', ' ', '21:04', '2019-05-18 21:04:00', 'O', '540', '548', '8', '19.1997336,73.1745642', '', ''),
(624, '011', '2019-05-22 19:55:34', '2019-05-20', '12:45', ' ', '2019-05-20 12:45:00', 'I', '', '', '', '19.1996851,73.1745084', '', 'EM'),
(625, '011', '2019-05-22 19:55:59', '2019-05-20', ' ', '21:03', '2019-05-20 21:03:00', 'O', '540', '498', '-42', '19.1997947,73.1746489', '', ''),
(626, '011', '2019-05-22 19:58:01', '2019-05-21', '12:00', ' ', '2019-05-21 12:00:00', 'I', '', '', '', '19.199703,73.174507', '', 'NM'),
(627, '011', '2019-05-22 19:58:25', '2019-05-21', ' ', '21:02', '2019-05-21 21:02:00', 'O', '540', '542', '2', '19.1998709,73.1747223', '', ''),
(631, '004', '2019-05-22 20:01:20', '2019-05-22', '10:57', ' ', '2019-05-22 10:57:00', 'I', '', '', '', '19.1997466,73.1745582', '', 'NM'),
(634, '004', '2019-05-22 20:02:52', '2019-05-22', ' ', '20:02', '2019-05-22 20:02:00', 'O', '540', '545', '5', '19.1997153,73.1745379', '', ''),
(633, '011', '2019-05-22 20:01:37', '2019-05-22', '11:44', ' ', '2019-05-22 11:44:00', 'I', '', '', '', '19.1996841,73.1745065', '', 'NM'),
(646, '005', '2019-05-22 20:43:32', '2019-05-22', ' ', '19:34', '2019-05-22 19:34:00', 'O', '510', '520', '10', '19.199334,73.1681029', '', ''),
(650, '005', '2019-05-23 10:37:28', '2019-05-06', '11:00', ' ', '2019-05-06 11:00:00', 'I', '', '', '', '19.1997532,73.174597', '', 'NM'),
(651, '005', '2019-05-23 10:38:23', '2019-05-06', ' ', '19:22', '2019-05-06 19:22:00', 'O', '510', '502', '-8', '19.1997025,73.1745415', '', ''),
(642, '009', '2019-05-22 20:37:28', '2019-05-14', ' ', '18:00', '2019-05-14 18:00:00', 'O', '510', '358', '-152', '19.2052465,73.1636908', '', ''),
(641, '009', '2019-05-22 20:36:25', '2019-05-14', '12:02', ' ', '2019-05-14 12:02:00', 'I', '', '', '', '19.2052209,73.1637006', '', 'NM'),
(640, '009', '2019-05-22 20:35:59', '2019-05-13', ' ', '21:00', '2019-05-13 21:00:00', 'O', '510', '506', '-4', '19.2052171,73.1637012', '', ''),
(639, '009', '2019-05-22 20:35:22', '2019-05-13', '12:34', ' ', '2019-05-13 12:34:00', 'I', '', '', '', '19.2052595,73.1636805', '', 'NM'),
(644, '009', '2019-05-22 20:41:57', '2019-05-15', ' ', '22:28', '2019-05-15 22:28:00', 'O', '510', '502', '-8', '19.2052712,73.1637217', '', ''),
(643, '009', '2019-05-22 20:41:39', '2019-05-15', '14:06', ' ', '2019-05-15 14:06:00', 'I', '', '', '', '19.2052675,73.1636723', '', 'HM'),
(652, '005', '2019-05-23 10:38:53', '2019-05-04', '11:00', ' ', '2019-05-04 11:00:00', 'I', '', '', '', '19.1996837,73.1745284', '', 'NM'),
(648, '011', '2019-05-22 21:08:04', '2019-05-22', ' ', '21:07', '2019-05-22 21:07:00', 'O', '540', '563', '23', '19.1996741,73.1745141', '', ''),
(655, '005', '2019-05-28 18:14:08', '2019-05-03', ' ', '19:31', '2019-05-03 19:31:00', 'O', '510', '511', '1', '19.1997369,73.1745702', '-', ''),
(654, '005', '2019-05-28 18:14:08', '2019-05-03', '11:00', ' ', '2019-05-03 11:00:00', 'I', '', '', '', '-', '', 'NM'),
(653, '005', '2019-05-23 10:39:32', '2019-05-04', ' ', '19:23', '2019-05-04 19:23:00', 'O', '510', '503', '-7', '19.1996606,73.1744886', '', ''),
(656, '005', '2019-05-23 10:40:57', '2019-05-02', '10:58', ' ', '2019-05-02 10:58:00', 'I', '', '', '', '19.1997575,73.1745872', '', 'NM'),
(657, '005', '2019-05-23 10:41:12', '2019-05-02', ' ', '19:55', '2019-05-02 19:55:00', 'O', '510', '537', '27', '19.1997618,73.1745917', '', ''),
(658, '005', '2019-05-23 10:41:28', '2019-05-01', '11:00', ' ', '2019-05-01 11:00:00', 'I', '', '', '', '19.199763,73.174592', '', 'NM'),
(659, '005', '2019-05-23 10:41:43', '2019-05-01', ' ', '19:30', '2019-05-01 19:30:00', 'O', '510', '510', '0', '19.1997676,73.174596', '', ''),
(660, '003', '2019-05-23 13:09:18', '2019-05-23', '11:00', ' ', '2019-05-23 11:00:00', 'I', '', '', '', '19.1997183,73.1745055', '', 'NM'),
(661, '010', '2019-05-23 14:30:39', '2019-05-22', ' ', '21:07', '2019-05-22 21:07:00', 'O', '540', '458', '-82', '', '', ''),
(662, '010', '2019-05-23 14:31:07', '2019-05-23', '12:00', ' ', '2019-05-23 12:00:00', 'I', '', '', '', '', '', 'NM'),
(663, '011', '2019-05-23 14:58:22', '2019-05-23', '12:05', ' ', '2019-05-23 12:05:00', 'I', '', '', '', '19.1996571,73.1744708', '', 'NM'),
(664, '009', '2019-05-23 19:53:11', '2019-05-16', '11:18', ' ', '2019-05-16 11:18:00', 'I', '', '', '', '19.1996714,73.1745137', '', 'NM'),
(665, '009', '2019-05-23 19:54:21', '2019-05-16', ' ', '21:21', '2019-05-16 21:21:00', 'O', '510', '603', '93', '19.1996804,73.1744977', '', ''),
(666, '009', '2019-05-23 19:55:23', '2019-05-17', '12:18', ' ', '2019-05-17 12:18:00', 'I', '', '', '', '19.1996887,73.1745104', '', 'NM'),
(667, '009', '2019-05-23 19:55:40', '2019-05-17', ' ', '20:42', '2019-05-17 20:42:00', 'O', '510', '504', '-6', '19.1996872,73.1745079', '', ''),
(668, '009', '2019-05-23 19:56:36', '2019-05-18', '12:40', ' ', '2019-05-18 12:40:00', 'I', '', '', '', '19.1996813,73.1744957', '', 'NM'),
(669, '009', '2019-05-23 19:56:53', '2019-05-18', ' ', '21:30', '2019-05-18 21:30:00', 'O', '510', '530', '20', '19.1996821,73.1745069', '', ''),
(670, '009', '2019-05-23 19:58:07', '2019-05-21', '12:58', ' ', '2019-05-21 12:58:00', 'I', '', '', '', '19.1996866,73.174508', '', 'NM'),
(671, '009', '2019-05-23 19:58:31', '2019-05-21', ' ', '20:40', '2019-05-21 20:40:00', 'O', '510', '462', '-48', '19.1996824,73.1745012', '', ''),
(766, '012', '2019-05-24 14:38:28', '2019-05-22', '12:00', ' ', '2019-05-22 12:00:00', 'I', '', '', '', '19.1996744,73.1744747', '', 'NM'),
(673, '009', '2019-05-23 20:02:15', '2019-05-23', '13:00', ' ', '2019-05-23 13:00:00', 'I', '', '', '', '19.1996684,73.1744848', '', 'NM'),
(674, '005', '2019-05-23 20:07:04', '2019-05-23', ' ', '19:26', '2019-05-23 19:26:00', 'O', '510', '538', '28', '19.1993385,73.1681248', '', ''),
(675, '003', '2019-05-23 20:38:33', '2019-05-23', ' ', '19:22', '2019-05-23 19:22:00', 'O', '510', '502', '-8', '19.2547159,73.3896107', '', ''),
(765, '012', '2019-05-24 14:37:54', '2019-05-21', ' ', '21:13', '2019-05-21 21:13:00', 'O', '540', '508', '-32', '19.199677,73.1744763', '', ''),
(1264, '030', '2019-06-04 20:13:38', '2019-06-04', ' ', '20:13', '2019-06-04 20:13:00', 'O', '540', '540', '0', '', '19.1997209,73.1744559', ''),
(680, '011', '2019-05-23 21:06:32', '2019-05-23', ' ', '21:06', '2019-05-23 21:06:00', 'O', '540', '541', '1', '19.1996616,73.1744654', '', ''),
(764, '012', '2019-05-24 14:37:25', '2019-05-21', '12:45', ' ', '2019-05-21 12:45:00', 'I', '', '', '', '19.1996732,73.1744778', '', 'EM'),
(682, '005', '2019-05-24 10:18:21', '2019-05-24', '10:10', ' ', '2019-05-24 10:10:00', 'I', '', '', '', '19.2007188,73.1744763', '', 'NM'),
(683, '003', '2019-05-24 10:50:11', '2019-05-24', '10:44', ' ', '2019-05-24 10:44:00', 'I', '', '', '', '19.1996951,73.1744924', '', 'NM'),
(684, '011', '2019-05-24 12:01:33', '2019-05-24', '12:00', ' ', '2019-05-24 12:00:00', 'I', '', '', '', '19.1996896,73.1745032', '', 'NM'),
(685, '010', '2019-05-24 12:08:00', '2019-05-23', ' ', '21:23', '2019-05-23 21:23:00', 'O', '540', '563', '23', '', '', ''),
(686, '010', '2019-05-24 12:08:31', '2019-05-24', '12:04', ' ', '2019-05-24 12:04:00', 'I', '', '', '', '', '', 'NM'),
(687, '009', '2019-05-24 12:28:29', '2019-05-24', '12:26', ' ', '2019-05-24 12:26:00', 'I', '', '', '', '19.1996538,73.1744579', '', 'NM'),
(688, '004', '2019-05-24 12:30:17', '2019-05-23', '11:25', ' ', '2019-05-23 11:25:00', 'I', '', '', '', '19.1996839,73.1744591', '', 'NM'),
(689, '002', '2019-05-24 12:30:33', '2019-05-24', '12:00', ' ', '2019-05-24 12:00:00', 'I', '', '', '', '19.1996616,73.1744636', '', 'NM'),
(690, '004', '2019-05-24 12:30:34', '2019-05-23', ' ', '20:29', '2019-05-23 20:29:00', 'O', '540', '544', '4', '19.1996839,73.1744591', '', ''),
(691, '004', '2019-05-24 12:30:54', '2019-05-24', '11:50', ' ', '2019-05-24 11:50:00', 'I', '', '', '', '19.1996616,73.1744654', '', 'HM'),
(692, '006', '2019-05-24 13:10:09', '2019-05-01', '11:32', ' ', '2019-05-01 11:32:00', 'I', '', '', '', '', '', 'NM'),
(693, '006', '2019-05-24 13:12:13', '2019-05-01', ' ', '21:05', '2019-05-01 21:05:00', 'O', '540', '573', '33', '', '', ''),
(694, '006', '2019-05-24 13:33:53', '2019-05-03', '11:13', ' ', '2019-05-03 11:13:00', 'I', '', '', '', '', '', 'NM'),
(695, '006', '2019-05-24 13:34:15', '2019-05-03', ' ', '20:03', '2019-05-03 20:03:00', 'O', '540', '530', '-10', '', '', ''),
(763, '012', '2019-05-24 14:36:57', '2019-05-20', ' ', '20:15', '2019-05-20 20:15:00', 'O', '540', '480', '-60', '19.1996855,73.1744864', '', ''),
(697, '006', '2019-05-24 13:35:00', '2019-05-04', '11:20', ' ', '2019-05-04 11:20:00', 'I', '', '', '', '', '', 'NM'),
(698, '006', '2019-05-24 13:35:32', '2019-05-04', ' ', '17:02', '2019-05-04 17:02:00', 'O', '540', '342', '-198', '', '', ''),
(762, '012', '2019-05-24 14:36:44', '2019-05-20', '12:15', ' ', '2019-05-20 12:15:00', 'I', '', '', '', '19.1997193,73.1745256', '', 'NM'),
(771, '012', '2019-05-24 14:53:18', '2019-05-18', ' ', '21:10', '2019-05-18 21:10:00', 'O', '540', '545', '5', '19.1998273,73.1746577', '', ''),
(701, '006', '2019-05-24 13:36:38', '2019-05-06', '12:01', ' ', '2019-05-06 12:01:00', 'I', '', '', '', '', '', 'LM'),
(702, '006', '2019-05-24 13:36:55', '2019-05-06', ' ', '20:39', '2019-05-06 20:39:00', 'O', '540', '518', '-22', '', '', ''),
(760, '012', '2019-05-24 14:36:10', '2019-05-18', '12:05', ' ', '2019-05-18 12:05:00', 'I', '', '', '', '19.1996712,73.1744743', '', 'NM'),
(704, '006', '2019-05-24 13:37:21', '2019-05-08', '11:05', ' ', '2019-05-08 11:05:00', 'I', '', '', '', '', '', 'NM'),
(705, '006', '2019-05-24 13:38:07', '2019-05-08', ' ', '19:01', '2019-05-08 19:01:00', 'O', '540', '476', '-64', '', '', ''),
(706, '006', '2019-05-24 13:38:36', '2019-05-09', '11:16', ' ', '2019-05-09 11:16:00', 'I', '', '', '', '', '', 'NM'),
(707, '006', '2019-05-24 13:39:01', '2019-05-09', ' ', '20:17', '2019-05-09 20:17:00', 'O', '540', '541', '1', '', '', ''),
(708, '006', '2019-05-24 13:39:32', '2019-05-10', '11:13', ' ', '2019-05-10 11:13:00', 'I', '', '', '', '', '', 'NM'),
(709, '006', '2019-05-24 13:39:49', '2019-05-10', ' ', '20:39', '2019-05-10 20:39:00', 'O', '540', '566', '26', '', '', ''),
(710, '006', '2019-05-24 13:40:18', '2019-05-11', '13:40', ' ', '2019-05-11 13:40:00', 'I', '', '', '', '', '', 'EM'),
(711, '006', '2019-05-24 13:41:02', '2019-05-11', ' ', '20:40', '2019-05-11 20:40:00', 'O', '540', '420', '-120', '', '', ''),
(759, '012', '2019-05-24 14:35:37', '2019-05-13', ' ', '21:09', '2019-05-13 21:09:00', 'O', '540', '494', '-46', '19.1996702,73.1744729', '', ''),
(758, '012', '2019-05-24 14:35:26', '2019-05-13', '12:55', ' ', '2019-05-13 12:55:00', 'I', '', '', '', '19.1996606,73.1744654', '', 'LM'),
(757, '012', '2019-05-24 14:34:42', '2019-05-11', ' ', '21:04', '2019-05-11 21:04:00', 'O', '540', '507', '-33', '19.1996648,73.174469', '', ''),
(756, '012', '2019-05-24 14:34:24', '2019-05-11', '12:37', ' ', '2019-05-11 12:37:00', 'I', '', '', '', '19.1996703,73.174478', '', 'LM'),
(755, '012', '2019-05-24 14:34:03', '2019-05-10', ' ', '21:06', '2019-05-10 21:06:00', 'O', '540', '536', '-4', '19.1996666,73.1744709', '', ''),
(754, '012', '2019-05-24 14:33:50', '2019-05-10', '12:10', ' ', '2019-05-10 12:10:00', 'I', '', '', '', '19.199687,73.1744943', '', 'NM'),
(753, '012', '2019-05-24 14:33:23', '2019-05-09', ' ', '21:10', '2019-05-09 21:10:00', 'O', '540', '537', '-3', '19.1996646,73.1744682', '', ''),
(752, '012', '2019-05-24 14:32:22', '2019-05-09', '12:13', ' ', '2019-05-09 12:13:00', 'I', '', '', '', '19.199666,73.1744693', '', 'NM'),
(751, '012', '2019-05-24 14:30:53', '2019-05-08', ' ', '21:10', '2019-05-08 21:10:00', 'O', '540', '555', '15', '19.199657,73.1744786', '', ''),
(750, '012', '2019-05-24 14:26:38', '2019-05-08', '11:55', ' ', '2019-05-08 11:55:00', 'I', '', '', '', '19.1996656,73.1744869', '', 'NM'),
(749, '012', '2019-05-24 14:25:56', '2019-05-07', ' ', '21:20', '2019-05-07 21:20:00', 'O', '540', '548', '8', '19.199673,73.174483', '', ''),
(748, '012', '2019-05-24 14:25:21', '2019-05-07', '12:12', ' ', '2019-05-07 12:12:00', 'I', '', '', '', '19.199813,73.1746517', '', 'NM'),
(747, '012', '2019-05-24 14:24:56', '2019-05-06', ' ', '21:00', '2019-05-06 21:00:00', 'O', '540', '515', '-25', '19.1998307,73.1746759', '', ''),
(746, '012', '2019-05-24 14:24:40', '2019-05-06', '12:25', ' ', '2019-05-06 12:25:00', 'I', '', '', '', '19.1998157,73.1746566', '', 'NM'),
(745, '012', '2019-05-24 14:24:22', '2019-05-03', ' ', '21:02', '2019-05-03 21:02:00', 'O', '540', '469', '-71', '19.1998303,73.1746472', '', ''),
(744, '012', '2019-05-24 14:23:49', '2019-05-03', '13:13', ' ', '2019-05-03 13:13:00', 'I', '', '', '', '19.1997966,73.174574', '', 'EM'),
(743, '012', '2019-05-24 14:23:27', '2019-05-04', ' ', '21:00', '2019-05-04 21:00:00', 'O', '540', '515', '-25', '19.1997037,73.174502', '', ''),
(742, '012', '2019-05-24 14:23:11', '2019-05-04', '12:25', ' ', '2019-05-04 12:25:00', 'I', '', '', '', '19.1997347,73.1745203', '', 'NM'),
(741, '012', '2019-05-24 14:16:34', '2019-05-02', ' ', '21:01', '2019-05-02 21:01:00', 'O', '540', '526', '-14', '19.1997136,73.1745045', '', ''),
(740, '012', '2019-05-24 14:16:19', '2019-05-02', '12:15', ' ', '2019-05-02 12:15:00', 'I', '', '', '', '19.1997026,73.1744952', '', 'NM'),
(739, '012', '2019-05-24 14:13:00', '2019-05-01', ' ', '21:04', '2019-05-01 21:04:00', 'O', '540', '504', '-36', '19.1997208,73.1745123', '', ''),
(738, '012', '2019-05-24 14:12:40', '2019-05-01', '12:40', ' ', '2019-05-01 12:40:00', 'I', '', '', '', '19.1996828,73.1744875', '', 'LM'),
(767, '012', '2019-05-24 14:38:41', '2019-05-22', ' ', '21:09', '2019-05-22 21:09:00', 'O', '540', '549', '9', '19.1996648,73.1744677', '', ''),
(768, '012', '2019-05-24 14:38:59', '2019-05-23', '12:07', ' ', '2019-05-23 12:07:00', 'I', '', '', '', '19.1996671,73.1744718', '', 'NM'),
(769, '012', '2019-05-24 14:44:49', '2019-05-23', ' ', '21:25', '2019-05-23 21:25:00', 'O', '540', '558', '18', '19.1997821,73.1746012', '', ''),
(770, '012', '2019-05-24 14:45:26', '2019-05-24', '13:25', ' ', '2019-05-24 13:25:00', 'I', '', '', '', '19.1997316,73.1745435', '', 'HM'),
(772, '006', '2019-05-24 16:31:06', '2019-05-13', '11:12', ' ', '2019-05-13 11:12:00', 'I', '', '', '', '', '', 'NM'),
(773, '006', '2019-05-24 16:31:32', '2019-05-13', ' ', '20:03', '2019-05-13 20:03:00', 'O', '540', '531', '-9', '', '', ''),
(774, '006', '2019-05-25 11:58:57', '2019-05-15', '11:50', ' ', '2019-05-15 11:50:00', 'I', '', '', '', '-', '', 'LM'),
(775, '006', '2019-05-25 11:58:57', '2019-05-15', ' ', '18:28', '2019-05-15 18:28:00', 'O', '540', '398', '-142', '', '-', ''),
(776, '006', '2019-05-24 16:33:10', '2019-05-17', '11:03', ' ', '2019-05-17 11:03:00', 'I', '', '', '', '', '', 'NM'),
(777, '006', '2019-05-24 16:33:35', '2019-05-17', ' ', '19:55', '2019-05-17 19:55:00', 'O', '540', '532', '-8', '', '', ''),
(778, '006', '2019-05-24 16:34:02', '2019-05-18', '11:08', ' ', '2019-05-18 11:08:00', 'I', '', '', '', '', '', 'NM'),
(779, '006', '2019-05-24 16:34:14', '2019-05-18', ' ', '20:37', '2019-05-18 20:37:00', 'O', '540', '569', '29', '', '', ''),
(780, '006', '2019-05-24 16:34:50', '2019-05-20', '11:13', ' ', '2019-05-20 11:13:00', 'I', '', '', '', '', '', 'NM'),
(781, '006', '2019-05-24 16:35:09', '2019-05-20', ' ', '20:01', '2019-05-20 20:01:00', 'O', '540', '528', '-12', '', '', ''),
(782, '006', '2019-05-24 16:37:29', '2019-05-21', '11:19', ' ', '2019-05-21 11:19:00', 'I', '', '', '', '', '', 'NM'),
(783, '006', '2019-05-24 16:38:08', '2019-05-22', '11:23', ' ', '2019-05-22 11:23:00', 'I', '', '', '', '', '', 'NM'),
(784, '006', '2019-05-24 16:38:23', '2019-05-22', ' ', '20:13', '2019-05-22 20:13:00', 'O', '540', '530', '-10', '', '', ''),
(785, '006', '2019-05-24 16:38:42', '2019-05-23', '11:19', ' ', '2019-05-23 11:19:00', 'I', '', '', '', '', '', 'NM'),
(786, '006', '2019-05-24 16:38:56', '2019-05-23', ' ', '20:26', '2019-05-23 20:26:00', 'O', '540', '547', '7', '', '', ''),
(787, '006', '2019-05-24 16:39:20', '2019-05-24', '11:17', ' ', '2019-05-24 11:17:00', 'I', '', '', '', '', '', 'NM'),
(810, '010', '2019-05-25 16:32:00', '2019-05-25', '12:06', ' ', '2019-05-25 12:06:00', 'I', '', '', '', '', '', 'NM'),
(1320, '001', '2019-06-10 17:52:48', '2019-06-05', '12:05', ' ', '2019-06-05 12:05:00', 'I', '', '', '', '19.1997852,73.1745186', '', 'NM'),
(791, '006', '2019-05-24 17:15:45', '2019-05-21', ' ', '19:31', '2019-05-21 19:31:00', 'O', '540', '492', '-48', '', '19.1996947,73.1744888', ''),
(792, '003', '2019-05-24 17:40:53', '2019-05-24', ' ', '17:40', '2019-05-24 17:40:00', 'O', '510', '416', '-94', '', '19.1997027,73.1745058', ''),
(793, '006', '2019-05-24 19:30:12', '2019-05-24', ' ', '19:30', '2019-05-24 19:30:00', 'O', '540', '493', '-47', '', '19.1997272,73.1745797', ''),
(794, '002', '2019-05-24 20:42:54', '2019-05-24', ' ', '20:42', '2019-05-24 20:42:00', 'O', '510', '522', '12', '', '19.1996616,73.1744654', ''),
(795, '004', '2019-05-24 20:43:24', '2019-05-24', ' ', '20:43', '2019-05-24 20:43:00', 'O', '540', '533', '-7', '', '19.1996616,73.1744654', ''),
(798, '005', '2019-05-24 21:06:57', '2019-05-24', ' ', '20:36', '2019-05-24 20:36:00', 'O', '510', '626', '116', '', '19.1993378,73.1681181', ''),
(799, '005', '2019-05-25 11:10:50', '2019-05-25', '11:00', ' ', '2019-05-25 11:00:00', 'I', '', '', '', '19.1997118,73.1745189', '', 'NM'),
(800, '003', '2019-05-25 11:45:46', '2019-05-25', '10:38', ' ', '2019-05-25 10:38:00', 'I', '', '', '', '19.2019986,73.1731283', '', 'NM'),
(801, '006', '2019-05-25 12:00:53', '2019-05-25', '11:18', ' ', '2019-05-25 11:18:00', 'I', '', '', '', '19.1996819,73.1744785', '', 'NM'),
(802, '002', '2019-05-25 12:02:08', '2019-05-25', '12:01', ' ', '2019-05-25 12:01:00', 'I', '', '', '', '19.1996796,73.1744892', '', 'NM'),
(803, '011', '2019-05-25 12:08:46', '2019-05-24', ' ', '21:20', '2019-05-24 21:20:00', 'O', '540', '560', '20', '', '19.1996927,73.1744941', ''),
(804, '011', '2019-05-25 12:09:10', '2019-05-25', '12:01', ' ', '2019-05-25 12:01:00', 'I', '', '', '', '19.1996651,73.1744651', '', 'NM'),
(811, '010', '2019-05-25 16:32:35', '2019-05-24', ' ', '21:30', '2019-05-24 21:30:00', 'O', '540', '566', '26', '', '', ''),
(812, '012', '2019-05-25 17:36:54', '2019-05-24', ' ', '21:42', '2019-05-24 21:42:00', 'O', '540', '497', '-43', '', '19.1996603,73.1744653', ''),
(813, '012', '2019-05-27 18:48:40', '2019-05-25', '12:45', ' ', '2019-05-25 12:45:00', 'I', '', '', '', '-', '', 'HM'),
(1318, '002', '2019-06-04 22:10:21', '2019-06-04', ' ', '21:08', '2019-06-04 21:08:00', 'O', '510', '550', '40', '', '19.2142879,73.2046246', ''),
(1319, '011', '2019-06-04 22:54:12', '2019-06-04', ' ', '21:07', '2019-06-04 21:07:00', 'O', '540', '558', '18', '', '19.201945,73.16702', ''),
(825, '002', '2019-05-25 19:11:51', '2019-05-25', ' ', '19:11', '2019-05-25 19:11:00', 'O', '510', '430', '-80', '', '19.1996655,73.1744732', ''),
(827, '005', '2019-05-25 19:31:08', '2019-05-25', ' ', '19:31', '2019-05-25 19:31:00', 'O', '510', '511', '1', '', '19.1996966,73.1744987', ''),
(828, '004', '2019-05-25 20:25:25', '2019-05-25', '11:25', ' ', '2019-05-25 11:25:00', 'I', '', '', '', '19.1996616,73.1744654', '', 'NM'),
(829, '004', '2019-05-25 20:25:34', '2019-05-25', ' ', '20:25', '2019-05-25 20:25:00', 'O', '540', '540', '0', '', '19.1996616,73.1744654', ''),
(830, '011', '2019-05-25 21:16:03', '2019-05-25', ' ', '21:14', '2019-05-25 21:14:00', 'O', '540', '553', '13', '', '19.1998747,73.1747425', ''),
(831, '010', '2019-05-25 21:16:36', '2019-05-25', ' ', '21:14', '2019-05-25 21:14:00', 'O', '540', '548', '8', '', '', ''),
(832, '009', '2019-05-26 16:58:28', '2019-05-23', ' ', '21:30', '2019-05-23 21:30:00', 'O', '510', '510', '0', '', '19.1997536,73.1744875', ''),
(833, '009', '2019-05-26 16:59:35', '2019-05-24', ' ', '21:20', '2019-05-24 21:20:00', 'O', '510', '534', '24', '', '19.199665,73.1744693', ''),
(834, '009', '2019-05-26 17:00:03', '2019-05-25', '12:25', ' ', '2019-05-25 12:25:00', 'I', '', '', '', '19.1996948,73.1744778', '', 'NM'),
(835, '009', '2019-05-26 17:00:25', '2019-05-25', ' ', '21:30', '2019-05-25 21:30:00', 'O', '510', '545', '35', '', '19.1996645,73.1744643', ''),
(836, '011', '2019-05-27 11:31:56', '2019-05-27', '11:30', ' ', '2019-05-27 11:30:00', 'I', '', '', '', '19.1997093,73.1745215', '', 'NM'),
(837, '002', '2019-05-27 12:05:01', '2019-05-27', '12:01', ' ', '2019-05-27 12:01:00', 'I', '', '', '', '19.1996743,73.174473', '', 'NM'),
(838, '010', '2019-05-27 12:15:49', '2019-05-27', '12:04', ' ', '2019-05-27 12:04:00', 'I', '', '', '', '', '', 'NM'),
(839, '003', '2019-05-27 12:20:51', '2019-05-27', '11:10', ' ', '2019-05-27 11:10:00', 'I', '', '', '', '19.1997644,73.1745167', '', 'NM'),
(840, '003', '2019-05-27 12:22:13', '2019-05-25', ' ', '19:14', '2019-05-25 19:14:00', 'O', '510', '516', '6', '', '19.1997063,73.1744918', ''),
(1259, '001', '2019-06-04 19:31:22', '2019-06-04', '13:24', ' ', '2019-06-04 13:24:00', 'I', '', '', '', '19.1997385,73.1745097', '', 'EM'),
(844, '002', '2019-05-27 18:33:30', '2019-05-01', '12:32', ' ', '2019-05-01 12:32:00', 'I', '', '', '', '19.199683,73.1744897', '', 'LM'),
(845, '002', '2019-05-27 18:34:52', '2019-05-01', ' ', '19:33', '2019-05-01 19:33:00', 'O', '510', '421', '-89', '', '19.1996677,73.1744659', ''),
(846, '002', '2019-05-27 18:36:47', '2019-05-02', '11:59', ' ', '2019-05-02 11:59:00', 'I', '', '', '', '19.1996739,73.1744846', '', 'NM'),
(847, '002', '2019-05-27 18:37:01', '2019-05-02', ' ', '19:37', '2019-05-02 19:37:00', 'O', '510', '458', '-52', '', '19.1996697,73.1744729', ''),
(848, '002', '2019-05-27 18:37:32', '2019-05-03', '12:02', ' ', '2019-05-03 12:02:00', 'I', '', '', '', '19.1996749,73.1744805', '', 'NM'),
(849, '002', '2019-05-27 18:37:51', '2019-05-03', ' ', '19:48', '2019-05-03 19:48:00', 'O', '510', '466', '-44', '', '19.1996714,73.1744758', ''),
(850, '002', '2019-05-27 18:38:23', '2019-05-04', '12:01', ' ', '2019-05-04 12:01:00', 'I', '', '', '', '19.1996746,73.1744826', '', 'NM'),
(851, '002', '2019-05-27 18:38:39', '2019-05-04', ' ', '20:05', '2019-05-04 20:05:00', 'O', '510', '484', '-26', '', '19.1996682,73.1744711', ''),
(852, '012', '2019-05-27 18:48:40', '2019-05-25', ' ', '21:07', '2019-05-25 21:07:00', 'O', '540', '502', '-38', '', '-', ''),
(853, '002', '2019-05-27 18:58:42', '2019-05-06', '11:59', ' ', '2019-05-06 11:59:00', 'I', '', '', '', '19.1996709,73.174478', '', 'NM'),
(854, '002', '2019-05-27 18:59:13', '2019-05-06', ' ', '20:23', '2019-05-06 20:23:00', 'O', '510', '504', '-6', '', '19.1996755,73.1744811', ''),
(855, '002', '2019-05-27 19:00:16', '2019-05-09', '12:26', ' ', '2019-05-09 12:26:00', 'I', '', '', '', '19.1996616,73.1744654', '', 'LM'),
(856, '002', '2019-05-27 19:00:51', '2019-05-09', ' ', '21:30', '2019-05-09 21:30:00', 'O', '510', '544', '34', '', '19.1996716,73.1744764', ''),
(857, '002', '2019-05-27 19:07:20', '2019-05-10', '12:02', ' ', '2019-05-10 12:02:00', 'I', '', '', '', '19.1996681,73.1744787', '', 'NM'),
(858, '002', '2019-05-27 19:07:31', '2019-05-10', ' ', '20:15', '2019-05-10 20:15:00', 'O', '510', '493', '-17', '', '19.1996708,73.1744785', ''),
(859, '002', '2019-05-27 19:07:58', '2019-05-11', '12:00', ' ', '2019-05-11 12:00:00', 'I', '', '', '', '19.199675,73.1744837', '', 'NM'),
(860, '002', '2019-05-27 19:08:04', '2019-05-11', ' ', '20:15', '2019-05-11 20:15:00', 'O', '510', '495', '-15', '', '19.1996707,73.174489', ''),
(861, '002', '2019-05-27 19:08:34', '2019-05-13', '12:30', ' ', '2019-05-13 12:30:00', 'I', '', '', '', '19.1996714,73.1744732', '', 'LM'),
(862, '002', '2019-05-27 19:08:43', '2019-05-13', ' ', '21:30', '2019-05-13 21:30:00', 'O', '510', '540', '30', '', '19.1996709,73.174478', ''),
(863, '002', '2019-05-27 19:09:19', '2019-05-14', '11:35', ' ', '2019-05-14 11:35:00', 'I', '', '', '', '19.1996677,73.1744707', '', 'NM'),
(864, '002', '2019-05-27 19:09:37', '2019-05-14', ' ', '20:31', '2019-05-14 20:31:00', 'O', '510', '536', '26', '', '19.1996691,73.1744716', ''),
(865, '002', '2019-05-27 19:10:00', '2019-05-15', '14:00', ' ', '2019-05-15 14:00:00', 'I', '', '', '', '19.1996698,73.1744743', '', 'EM'),
(866, '002', '2019-05-27 19:10:19', '2019-05-15', ' ', '21:00', '2019-05-15 21:00:00', 'O', '510', '420', '-90', '', '19.1996686,73.1744706', ''),
(867, '002', '2019-05-27 19:10:40', '2019-05-16', '11:48', ' ', '2019-05-16 11:48:00', 'I', '', '', '', '19.1996692,73.1744738', '', 'NM'),
(868, '002', '2019-05-27 19:11:02', '2019-05-16', ' ', '20:35', '2019-05-16 20:35:00', 'O', '510', '527', '17', '', '19.1996688,73.1744699', ''),
(869, '002', '2019-05-27 19:11:37', '2019-05-17', '11:58', ' ', '2019-05-17 11:58:00', 'I', '', '', '', '19.1996698,73.1744699', '', 'NM'),
(870, '002', '2019-05-27 19:11:54', '2019-05-17', ' ', '18:49', '2019-05-17 18:49:00', 'O', '510', '411', '-99', '', '19.199667,73.1744658', ''),
(871, '002', '2019-05-27 19:12:22', '2019-05-18', '11:54', ' ', '2019-05-18 11:54:00', 'I', '', '', '', '19.1996687,73.1744708', '', 'NM'),
(872, '002', '2019-05-27 19:12:51', '2019-05-18', ' ', '18:50', '2019-05-18 18:50:00', 'O', '510', '416', '-94', '', '19.1996683,73.1744706', ''),
(873, '002', '2019-05-27 19:15:42', '2019-05-23', '11:49', ' ', '2019-05-23 11:49:00', 'I', '', '', '', '19.1996616,73.1744654', '', 'NM'),
(874, '002', '2019-05-27 19:15:54', '2019-05-23', ' ', '20:37', '2019-05-23 20:37:00', 'O', '510', '528', '18', '', '19.1996932,73.1745097', ''),
(875, '010', '2019-05-27 21:03:41', '2019-05-27', ' ', '21:01', '2019-05-27 21:01:00', 'O', '540', '537', '-3', '', '', ''),
(876, '002', '2019-05-27 22:24:31', '2019-05-27', ' ', '21:30', '2019-05-27 21:30:00', 'O', '510', '569', '59', '', '19.2142757,73.2044651', '');
INSERT INTO `j_atendance` (`id`, `emp_id`, `c_date`, `login_date`, `login_time`, `logout_time`, `login_date_time`, `tag`, `total_minut`, `work_time`, `bal_minut`, `location_in`, `location_out`, `status`) VALUES
(877, '005', '2019-05-28 10:51:57', '2019-05-28', '10:48', ' ', '2019-05-28 10:48:00', 'I', '', '', '', '19.1997096,73.1745183', '', 'NM'),
(878, '002', '2019-05-28 12:01:37', '2019-05-28', '11:59', ' ', '2019-05-28 11:59:00', 'I', '', '', '', '19.1996594,73.1744739', '', 'NM'),
(879, '010', '2019-05-28 12:12:09', '2019-05-28', '12:02', ' ', '2019-05-28 12:02:00', 'I', '', '', '', '', '', 'NM'),
(880, '003', '2019-05-28 12:12:35', '2019-05-28', '10:48', ' ', '2019-05-28 10:48:00', 'I', '', '', '', '19.1996935,73.1744849', '', 'NM'),
(881, '003', '2019-05-28 12:13:10', '2019-05-27', ' ', '19:25', '2019-05-27 19:25:00', 'O', '510', '495', '-15', '', '19.1996877,73.1744839', ''),
(1317, '008', '2019-06-04 20:58:28', '2019-06-04', '12:02', ' ', '2019-06-04 12:02:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1315, '008', '2019-06-04 20:57:55', '2019-06-03', '12:01', ' ', '2019-06-03 12:01:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1316, '008', '2019-06-04 20:58:12', '2019-06-03', ' ', '21:07', '2019-06-03 21:07:00', 'O', '540', '546', '6', '', '19.1997165,73.1744991', ''),
(1314, '008', '2019-06-04 20:57:20', '2019-06-01', ' ', '21:05', '2019-06-01 21:05:00', 'O', '540', '552', '12', '', '19.1997182,73.1744912', ''),
(1313, '008', '2019-06-04 20:57:06', '2019-06-01', '11:53', ' ', '2019-06-01 11:53:00', 'I', '', '', '', '19.1997127,73.1744838', '', 'NM'),
(1312, '008', '2019-06-04 20:56:32', '2019-05-31', ' ', '21:12', '2019-05-31 21:12:00', 'O', '540', '430', '-110', '', '19.1997027,73.1744913', ''),
(1311, '008', '2019-06-04 20:55:43', '2019-05-31', '14:02', ' ', '2019-05-31 14:02:00', 'I', '', '', '', '19.199716,73.1744714', '', 'EM'),
(1310, '008', '2019-06-04 20:54:49', '2019-05-30', ' ', '20:44', '2019-05-30 20:44:00', 'O', '540', '505', '-35', '', '19.1996959,73.1743293', ''),
(1309, '008', '2019-06-04 20:54:36', '2019-05-30', '12:19', ' ', '2019-05-30 12:19:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1308, '008', '2019-06-04 20:54:04', '2019-05-29', ' ', '21:07', '2019-05-29 21:07:00', 'O', '540', '540', '0', '', '19.1997174,73.1744999', ''),
(1307, '008', '2019-06-04 20:53:45', '2019-05-29', '12:07', ' ', '2019-05-29 12:07:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1306, '008', '2019-06-04 20:52:24', '2019-05-28', ' ', '21:07', '2019-05-28 21:07:00', 'O', '540', '540', '0', '', '19.1997027,73.1744913', ''),
(1305, '008', '2019-06-04 20:52:00', '2019-05-28', '12:07', ' ', '2019-05-28 12:07:00', 'I', '', '', '', '19.1997429,73.1745349', '', 'NM'),
(902, '011', '2019-05-28 14:51:33', '2019-05-27', ' ', '21:02', '2019-05-27 21:02:00', 'O', '540', '572', '32', '', '19.1996769,73.1744852', ''),
(1304, '008', '2019-06-04 20:51:16', '2019-05-27', ' ', '21:15', '2019-05-27 21:15:00', 'O', '540', '541', '1', '', '19.1997253,73.1744993', ''),
(1303, '008', '2019-06-04 20:50:50', '2019-05-27', '12:14', ' ', '2019-05-27 12:14:00', 'I', '', '', '', '19.1996988,73.1744671', '', 'NM'),
(905, '011', '2019-05-28 14:52:30', '2019-05-28', '12:12', ' ', '2019-05-28 12:12:00', 'I', '', '', '', '19.1996931,73.1744966', '', 'LM'),
(1302, '008', '2019-06-04 20:49:54', '2019-05-25', ' ', '21:10', '2019-05-25 21:10:00', 'O', '540', '566', '26', '', '19.1997282,73.1745015', ''),
(1301, '008', '2019-06-04 20:49:30', '2019-05-25', '11:44', ' ', '2019-05-25 11:44:00', 'I', '', '', '', '19.1997212,73.1744919', '', 'NM'),
(1300, '008', '2019-06-04 20:48:26', '2019-05-24', ' ', '21:22', '2019-05-24 21:22:00', 'O', '540', '540', '0', '', '19.1997684,73.1745093', ''),
(1298, '008', '2019-06-04 20:46:50', '2019-05-23', '21:35', ' ', '2019-05-23 21:35:00', 'I', '', '', '', '19.1997233,73.1745099', '', 'EM'),
(1296, '008', '2019-06-04 20:45:28', '2019-05-22', '12:12', ' ', '2019-05-22 12:12:00', 'I', '', '', '', '19.1997711,73.1745232', '', 'NM'),
(1294, '008', '2019-06-04 20:42:13', '2019-05-21', '12:15', ' ', '2019-05-21 12:15:00', 'I', '', '', '', '19.1997231,73.1744816', '', 'NM'),
(1292, '008', '2019-06-04 20:41:05', '2019-05-20', '12:21', ' ', '2019-05-20 12:21:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1290, '008', '2019-06-04 20:39:40', '2019-05-18', '12:20', ' ', '2019-05-18 12:20:00', 'I', '', '', '', '19.1997385,73.1745023', '', 'NM'),
(1289, '009', '2019-06-04 20:39:31', '2019-06-04', ' ', '20:39', '2019-06-04 20:39:00', 'O', '510', '451', '-59', '', '', ''),
(1288, '008', '2019-06-04 20:38:23', '2019-05-17', ' ', '21:15', '2019-05-17 21:15:00', 'O', '540', '534', '-6', '', '19.1997027,73.1744913', ''),
(1287, '008', '2019-06-04 20:37:52', '2019-05-17', '12:21', ' ', '2019-05-17 12:21:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1286, '008', '2019-06-04 20:36:32', '2019-05-16', ' ', '21:07', '2019-05-16 21:07:00', 'O', '540', '516', '-24', '', '19.1997179,73.174501', ''),
(1285, '008', '2019-06-04 20:35:22', '2019-05-16', '12:31', ' ', '2019-05-16 12:31:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1284, '008', '2019-06-04 20:34:30', '2019-05-15', ' ', '21:17', '2019-05-15 21:17:00', 'O', '540', '529', '-11', '', '19.1997027,73.1744913', ''),
(1283, '008', '2019-06-04 20:34:06', '2019-05-15', '12:28', ' ', '2019-05-15 12:28:00', 'I', '', '', '', '19.1997175,73.1744971', '', 'NM'),
(930, '005', '2019-05-28 18:20:30', '2019-05-27', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'P'),
(947, '011', '2019-05-28 18:30:52', '2019-05-06', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(946, '011', '2019-05-28 18:30:52', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(945, '011', '2019-05-28 18:30:52', '2019-05-04', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(944, '011', '2019-05-28 18:30:52', '2019-05-03', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(943, '011', '2019-05-28 18:30:52', '2019-05-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(942, '011', '2019-05-28 18:30:52', '2019-05-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(948, '011', '2019-05-28 18:30:52', '2019-05-07', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(949, '011', '2019-05-28 18:30:52', '2019-05-08', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(950, '011', '2019-05-28 18:30:52', '2019-05-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(951, '011', '2019-05-28 18:30:52', '2019-05-10', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(952, '005', '2019-05-28 19:30:19', '2019-05-28', ' ', '19:20', '2019-05-28 19:20:00', 'O', '510', '512', '2', '', '19.2069902,73.1647936', ''),
(1258, '001', '2019-06-04 19:30:43', '2019-06-03', ' ', '20:56', '2019-06-03 20:56:00', 'O', '510', '527', '17', '', '19.1997174,73.1744919', ''),
(954, '002', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(955, '003', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(956, '004', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(957, '005', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(958, '006', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1280, '008', '2019-06-04 20:31:52', '2019-05-11', ' ', '20:34', '2019-05-11 20:34:00', 'O', '540', '453', '-87', '', '19.1996959,73.1743293', ''),
(960, '009', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(961, '010', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(962, '011', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(963, '012', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(964, '025', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(965, '030', '2019-05-28 20:01:16', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1257, '001', '2019-06-04 19:30:15', '2019-06-03', '12:09', ' ', '2019-06-03 12:09:00', 'I', '', '', '', '19.1997307,73.1745042', '', 'LM'),
(967, '002', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(968, '003', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(969, '004', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(970, '005', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(971, '006', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1279, '008', '2019-06-04 20:31:35', '2019-05-11', '13:01', ' ', '2019-05-11 13:01:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(973, '009', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(974, '010', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(975, '011', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(976, '012', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(977, '025', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(978, '030', '2019-05-28 20:02:25', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1256, '001', '2019-06-04 19:29:41', '2019-06-01', ' ', '18:40', '2019-06-01 18:40:00', 'O', '510', '417', '-93', '', '19.1997395,73.1745338', ''),
(980, '002', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(981, '003', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(982, '004', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(983, '005', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(984, '006', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(986, '009', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(987, '010', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(988, '011', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(989, '012', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(990, '025', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(991, '030', '2019-05-28 20:03:45', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1255, '001', '2019-06-04 19:29:12', '2019-06-01', '11:43', ' ', '2019-06-01 11:43:00', 'I', '', '', '', '19.1997449,73.1745419', '', 'NM'),
(993, '002', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(994, '003', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(995, '004', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(996, '005', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(997, '006', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(999, '009', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1000, '010', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1001, '011', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1002, '012', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1003, '025', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1004, '030', '2019-05-28 20:04:04', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1254, '001', '2019-06-04 19:34:18', '2019-05-31', ' ', '21:14', '2019-05-31 21:14:00', 'O', '510', '375', '-135', '', '-', ''),
(1253, '001', '2019-06-04 19:34:18', '2019-05-31', '14:59', ' ', '2019-05-31 14:59:00', 'I', '', '', '', '-', '', 'EM'),
(1252, '001', '2019-06-04 19:27:23', '2019-05-30', ' ', '21:21', '2019-05-30 21:21:00', 'O', '510', '557', '47', '', '19.1997455,73.1745198', ''),
(1251, '001', '2019-06-04 19:27:12', '2019-05-30', '12:04', ' ', '2019-05-30 12:04:00', 'I', '', '', '', '19.1997285,73.1745021', '', 'NM'),
(1250, '001', '2019-06-04 19:26:01', '2019-05-29', ' ', '21:30', '2019-05-29 21:30:00', 'O', '510', '573', '63', '', '19.1997286,73.1745027', ''),
(1249, '001', '2019-06-04 19:25:13', '2019-05-29', '11:57', ' ', '2019-05-29 11:57:00', 'I', '', '', '', '19.1998867,73.1746938', '', 'NM'),
(1248, '001', '2019-06-04 19:24:45', '2019-05-28', ' ', '21:07', '2019-05-28 21:07:00', 'O', '510', '543', '33', '', '19.1997212,73.174495', ''),
(1247, '001', '2019-06-04 19:24:27', '2019-05-28', '12:04', ' ', '2019-05-28 12:04:00', 'I', '', '', '', '19.1997577,73.1745229', '', 'NM'),
(1246, '001', '2019-06-04 19:23:52', '2019-05-27', ' ', '21:25', '2019-05-27 21:25:00', 'O', '510', '458', '-52', '', '19.1997585,73.1745282', ''),
(1244, '005', '2019-06-04 19:23:05', '2019-06-04', ' ', '19:11', '2019-06-04 19:11:00', 'O', '510', '521', '11', '', '19.1993556,73.1681146', ''),
(1243, '001', '2019-06-04 19:22:43', '2019-05-25', ' ', '20:19', '2019-05-25 20:19:00', 'O', '510', '499', '-11', '', '19.1997353,73.1745077', ''),
(1242, '001', '2019-06-04 19:22:32', '2019-05-25', '12:00', ' ', '2019-05-25 12:00:00', 'I', '', '', '', '19.1997821,73.1745728', '', 'NM'),
(1241, '001', '2019-06-04 19:21:43', '2019-05-23', ' ', '21:17', '2019-05-23 21:17:00', 'O', '510', '561', '51', '', '19.1998184,73.1746246', ''),
(1240, '001', '2019-06-04 19:21:23', '2019-05-23', '11:56', ' ', '2019-05-23 11:56:00', 'I', '', '', '', '19.1997381,73.1745248', '', 'NM'),
(1239, '001', '2019-06-04 19:20:31', '2019-05-21', ' ', '21:14', '2019-05-21 21:14:00', 'O', '510', '570', '60', '', '19.1997966,73.1745946', ''),
(1238, '001', '2019-06-04 19:20:01', '2019-05-21', '11:44', ' ', '2019-05-21 11:44:00', 'I', '', '', '', '19.1997283,73.1745151', '', 'NM'),
(1237, '001', '2019-06-04 19:19:23', '2019-05-20', ' ', '21:14', '2019-05-20 21:14:00', 'O', '510', '557', '47', '', '19.199723,73.1745184', ''),
(1236, '001', '2019-06-04 19:19:00', '2019-05-20', '11:57', ' ', '2019-05-20 11:57:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1235, '001', '2019-06-04 19:17:31', '2019-05-17', ' ', '21:14', '2019-05-17 21:14:00', 'O', '510', '552', '42', '', '19.1997147,73.1744853', ''),
(1233, '001', '2019-06-04 19:16:42', '2019-05-16', ' ', '19:13', '2019-05-16 19:13:00', 'O', '510', '425', '-85', '', '19.1997387,73.1745151', ''),
(1232, '001', '2019-06-04 19:15:55', '2019-05-16', '12:08', ' ', '2019-05-16 12:08:00', 'I', '', '', '', '19.1997226,73.1744818', '', 'LM'),
(1231, '001', '2019-06-04 19:15:04', '2019-05-15', ' ', '20:34', '2019-05-15 20:34:00', 'O', '510', '534', '24', '', '-', ''),
(1230, '001', '2019-06-04 19:15:04', '2019-05-15', '11:40', ' ', '2019-05-15 11:40:00', 'I', '', '', '', '-', '', 'NM'),
(1229, '001', '2019-06-04 19:12:58', '2019-05-14', ' ', '20:50', '2019-05-14 20:50:00', 'O', '510', '527', '17', '', '19.1998089,73.1746087', ''),
(1227, '001', '2019-06-04 19:34:00', '2019-05-13', ' ', '19:42', '2019-05-13 19:42:00', 'O', '510', '467', '-43', '', '-', ''),
(1226, '001', '2019-06-04 19:34:00', '2019-05-13', '11:55', ' ', '2019-05-13 11:55:00', 'I', '', '', '', '-', '', 'NM'),
(1225, '001', '2019-06-04 19:10:40', '2019-05-11', ' ', '20:36', '2019-05-11 20:36:00', 'O', '510', '516', '6', '', '19.1997268,73.1745', ''),
(1224, '001', '2019-06-04 19:10:10', '2019-05-11', '12:00', ' ', '2019-05-11 12:00:00', 'I', '', '', '', '19.1997283,73.1745151', '', 'NM'),
(1222, '001', '2019-06-04 19:08:39', '2019-05-10', '12:06', ' ', '2019-05-10 12:06:00', 'I', '', '', '', '19.1997223,73.1745125', '', 'LM'),
(1220, '001', '2019-06-04 19:04:22', '2019-05-09', '12:03', ' ', '2019-05-09 12:03:00', 'I', '', '', '', '19.1997459,73.174511', '', 'NM'),
(1218, '001', '2019-06-04 19:02:50', '2019-05-08', '12:05', ' ', '2019-05-08 12:05:00', 'I', '', '', '', '19.1997105,73.1744674', '', 'NM'),
(1045, '011', '2019-05-28 21:05:01', '2019-05-28', ' ', '21:03', '2019-05-28 21:03:00', 'O', '540', '531', '-9', '', '19.2000272,73.174727', ''),
(1048, '005', '2019-05-29 10:33:22', '2019-05-29', '10:30', ' ', '2019-05-29 10:30:00', 'I', '', '', '', '19.2072837,73.1853635', '', 'NM'),
(1049, '003', '2019-05-29 10:53:45', '2019-05-29', '10:47', ' ', '2019-05-29 10:47:00', 'I', '', '', '', '', '', 'NM'),
(1050, '003', '2019-05-29 10:54:07', '2019-05-28', ' ', '19:30', '2019-05-28 19:30:00', 'O', '510', '522', '12', '', '', ''),
(1051, '011', '2019-05-29 11:42:01', '2019-05-29', '11:32', ' ', '2019-05-29 11:32:00', 'I', '', '', '', '19.1997039,73.1744931', '', 'NM'),
(1052, '002', '2019-05-29 12:04:01', '2019-05-29', '12:02', ' ', '2019-05-29 12:02:00', 'I', '', '', '', '19.1997107,73.1744876', '', 'NM'),
(1053, '002', '2019-05-29 12:05:09', '2019-05-28', ' ', '19:14', '2019-05-28 19:14:00', 'O', '510', '435', '-75', '', '19.1997138,73.1744917', ''),
(1054, '002', '2019-05-29 12:14:00', '2019-05-07', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'P'),
(1055, '002', '2019-05-29 12:15:33', '2019-05-08', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1056, '002', '2019-05-29 12:16:43', '2019-05-20', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1057, '002', '2019-05-29 12:16:43', '2019-05-21', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1058, '002', '2019-05-29 12:16:43', '2019-05-22', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1059, '010', '2019-05-29 12:55:16', '2019-05-29', '12:04', ' ', '2019-05-29 12:04:00', 'I', '', '', '', '', '', 'NM'),
(1060, '012', '2019-05-29 13:48:37', '2019-05-14', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1061, '012', '2019-05-29 13:48:37', '2019-05-15', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1062, '012', '2019-05-29 13:48:37', '2019-05-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1063, '012', '2019-05-29 13:48:37', '2019-05-17', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1064, '012', '2019-05-29 13:50:09', '2019-05-27', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1065, '012', '2019-05-29 13:50:09', '2019-05-28', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1066, '012', '2019-05-29 13:50:09', '2019-05-29', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'E'),
(1067, '009', '2019-05-29 13:51:49', '2019-05-27', '12:25', ' ', '2019-05-27 12:25:00', 'I', '', '', '', '19.1997394,73.1745132', '', 'NM'),
(1068, '009', '2019-05-29 14:01:04', '2019-05-27', ' ', '21:30', '2019-05-27 21:30:00', 'O', '510', '545', '35', '', '19.1997265,73.1745039', ''),
(1069, '009', '2019-05-29 14:03:10', '2019-05-28', '10:30', ' ', '2019-05-28 10:30:00', 'I', '', '', '', '19.1997402,73.1745268', '', 'NM'),
(1070, '009', '2019-05-29 14:03:21', '2019-05-28', ' ', '21:30', '2019-05-28 21:30:00', 'O', '510', '660', '150', '', '19.199739,73.1745143', ''),
(1071, '009', '2019-05-29 14:05:43', '2019-05-29', '12:35', ' ', '2019-05-29 12:35:00', 'I', '', '', '', '19.1997378,73.1745225', '', 'NM'),
(1275, '008', '2019-06-04 20:30:20', '2019-05-09', '11:23', ' ', '2019-05-09 11:23:00', 'I', '', '', '', '-', '', 'NM'),
(1073, '005', '2019-05-29 19:40:26', '2019-05-29', ' ', '19:30', '2019-05-29 19:30:00', 'O', '510', '540', '30', '', '19.1993458,73.1681163', ''),
(1074, '009', '2019-05-29 19:51:18', '2019-05-29', ' ', '19:08', '2019-05-29 19:08:00', 'O', '510', '393', '-117', '', '19.2029044,73.1619415', ''),
(1075, '002', '2019-05-29 20:26:58', '2019-05-29', ' ', '20:26', '2019-05-29 20:26:00', 'O', '510', '504', '-6', '', '19.1997027,73.1744913', ''),
(1076, '010', '2019-05-29 21:06:47', '2019-05-29', ' ', '21:05', '2019-05-29 21:05:00', 'O', '540', '541', '1', '', '', ''),
(1216, '001', '2019-06-04 19:01:34', '2019-05-07', '11:27', ' ', '2019-05-07 11:27:00', 'I', '', '', '', '19.1997167,73.1744905', '', 'NM'),
(1080, '003', '2019-05-30 10:49:27', '2019-05-29', ' ', '19:30', '2019-05-29 19:30:00', 'O', '510', '523', '13', '', '', ''),
(1081, '003', '2019-05-30 10:50:45', '2019-05-30', '10:37', ' ', '2019-05-30 10:37:00', 'I', '', '', '', '', '', 'NM'),
(1082, '009', '2019-05-30 10:58:49', '2019-05-30', '10:57', ' ', '2019-05-30 10:57:00', 'I', '', '', '', '19.1997433,73.1745117', '', 'NM'),
(1083, '005', '2019-05-30 11:42:21', '2019-05-30', '10:30', ' ', '2019-05-30 10:30:00', 'I', '', '', '', '19.0189484,72.842873', '', 'NM'),
(1084, '011', '2019-05-30 12:03:42', '2019-05-29', ' ', '21:05', '2019-05-29 21:05:00', 'O', '540', '573', '33', '', '19.1998601,73.174667', ''),
(1085, '011', '2019-05-30 12:04:08', '2019-05-30', '11:57', ' ', '2019-05-30 11:57:00', 'I', '', '', '', '19.1998305,73.1746337', '', 'NM'),
(1086, '010', '2019-05-30 12:21:08', '2019-05-30', '12:03', ' ', '2019-05-30 12:03:00', 'I', '', '', '', '', '', 'NM'),
(1214, '001', '2019-06-04 18:58:32', '2019-05-06', '11:57', ' ', '2019-05-06 11:57:00', 'I', '', '', '', '19.199714,73.1744889', '', 'NM'),
(1273, '008', '2019-06-04 20:27:35', '2019-05-06', '11:37', ' ', '2019-05-06 11:37:00', 'I', '', '', '', '19.1999084,73.1747434', '', 'NM'),
(1089, '003', '2019-05-30 19:00:23', '2019-05-08', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1090, '003', '2019-05-30 19:07:31', '2019-05-30', ' ', '19:07', '2019-05-30 19:07:00', 'O', '510', '510', '0', '', '19.1997351,73.1745097', ''),
(1091, '002', '2019-05-30 19:17:25', '2019-05-30', '19:14', ' ', '2019-05-30 19:14:00', 'I', '', '', '', '19.1997116,73.1744893', '', 'EM'),
(1092, '005', '2019-05-30 20:38:58', '2019-05-30', ' ', '19:15', '2019-05-30 19:15:00', 'O', '510', '525', '15', '', '19.1993315,73.1679872', ''),
(1093, '009', '2019-05-30 21:00:46', '2019-05-30', ' ', '20:43', '2019-05-30 20:43:00', 'O', '510', '586', '76', '', '19.1997153,73.1744903', ''),
(1094, '002', '2019-05-30 21:06:35', '2019-05-30', ' ', '21:06', '2019-05-30 21:06:00', 'O', '510', '112', '-398', '', '19.1997272,73.1745013', ''),
(1095, '010', '2019-05-30 21:07:51', '2019-05-30', ' ', '21:05', '2019-05-30 21:05:00', 'O', '540', '542', '2', '', '', ''),
(1096, '011', '2019-05-30 21:21:34', '2019-05-30', ' ', '21:06', '2019-05-30 21:06:00', 'O', '540', '549', '9', '', '19.2005455,73.168341', ''),
(1097, '005', '2019-05-31 10:48:19', '2019-05-31', '10:30', ' ', '2019-05-31 10:30:00', 'I', '', '', '', '19.1997232,73.1745019', '', 'NM'),
(1098, '011', '2019-05-31 12:24:20', '2019-05-31', '12:02', ' ', '2019-05-31 12:02:00', 'I', '', '', '', '19.199665,73.1744618', '', 'NM'),
(1099, '010', '2019-05-31 18:41:37', '2019-05-31', '11:51', ' ', '2019-05-31 11:51:00', 'I', '', '', '', '-', '', 'NM'),
(1100, '009', '2019-05-31 12:40:07', '2019-05-31', '12:18', ' ', '2019-05-31 12:18:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1101, '002', '2019-05-31 12:46:55', '2019-05-31', '11:39', ' ', '2019-05-31 11:39:00', 'I', '', '', '', '19.1997096,73.1744851', '', 'NM'),
(1104, '005', '2019-05-31 17:34:56', '2019-05-31', ' ', '17:30', '2019-05-31 17:30:00', 'O', '510', '420', '-90', '', '19.2006516,73.1727703', ''),
(1105, '009', '2019-05-31 20:43:59', '2019-05-31', ' ', '20:43', '2019-05-31 20:43:00', 'O', '510', '505', '-5', '', '19.1996767,73.1746818', ''),
(1106, '002', '2019-05-31 21:01:14', '2019-05-31', ' ', '21:01', '2019-05-31 21:01:00', 'O', '510', '562', '52', '', '19.199721,73.1745137', ''),
(1107, '011', '2019-05-31 21:16:04', '2019-05-31', ' ', '21:14', '2019-05-31 21:14:00', 'O', '540', '552', '12', '', '19.2001321,73.1746236', ''),
(1108, '010', '2019-05-31 21:16:29', '2019-05-31', ' ', '21:14', '2019-05-31 21:14:00', 'O', '540', '563', '23', '', '', ''),
(1272, '008', '2019-06-04 20:27:06', '2019-05-04', ' ', '20:38', '2019-05-04 20:38:00', 'O', '540', '558', '18', '', '19.1997322,73.1745191', ''),
(1212, '001', '2019-06-04 18:57:14', '2019-05-04', '11:58', ' ', '2019-05-04 11:58:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1112, '005', '2019-06-01 11:05:52', '2019-06-01', '11:03', ' ', '2019-06-01 11:03:00', 'I', '', '', '', '19.1997334,73.1745237', '', 'NM'),
(1271, '008', '2019-06-04 20:26:48', '2019-05-04', '11:20', ' ', '2019-05-04 11:20:00', 'I', '', '', '', '19.1997904,73.1745734', '', 'NM'),
(1114, '010', '2019-06-01 12:56:40', '2019-06-01', '12:09', ' ', '2019-06-01 12:09:00', 'I', '', '', '', '', '', 'NM'),
(1115, '005', '2019-06-01 19:40:26', '2019-06-01', ' ', '19:17', '2019-06-01 19:17:00', 'O', '510', '494', '-16', '', '19.1993452,73.1681166', ''),
(1116, '010', '2019-06-01 21:05:47', '2019-06-01', ' ', '21:04', '2019-06-01 21:04:00', 'O', '540', '535', '-5', '', '', ''),
(1117, '011', '2019-06-01 21:08:06', '2019-06-01', '12:03', ' ', '2019-06-01 12:03:00', 'I', '', '', '', '19.2006445,73.1720404', '', 'NM'),
(1118, '011', '2019-06-01 21:08:13', '2019-06-01', ' ', '21:04', '2019-06-01 21:04:00', 'O', '540', '541', '1', '', '19.200672,73.17175', ''),
(1120, '002', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1121, '003', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1122, '004', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1123, '005', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1124, '006', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1126, '009', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1127, '010', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1128, '011', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1129, '012', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1130, '025', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1131, '030', '2019-06-02 12:30:17', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1132, '003', '2019-06-03 11:32:09', '2019-06-03', '11:07', ' ', '2019-06-03 11:07:00', 'I', '', '', '', '19.2013483,73.1738658', '', 'NM'),
(1133, '009', '2019-06-03 11:35:55', '2019-06-03', '11:16', ' ', '2019-06-03 11:16:00', 'I', '', '', '', '19.1997245,73.1745041', '', 'NM'),
(1134, '009', '2019-06-03 11:37:22', '2019-06-01', '12:20', ' ', '2019-06-01 12:20:00', 'I', '', '', '', '19.1997278,73.1745071', '', 'NM'),
(1135, '009', '2019-06-03 11:37:48', '2019-06-01', ' ', '17:43', '2019-06-01 17:43:00', 'O', '510', '323', '-187', '', '19.1997687,73.1745703', ''),
(1136, '011', '2019-06-03 12:06:02', '2019-06-03', '11:59', ' ', '2019-06-03 11:59:00', 'I', '', '', '', '19.1997469,73.1745525', '', 'NM'),
(1137, '010', '2019-06-03 12:07:12', '2019-06-03', '12:01', ' ', '2019-06-03 12:01:00', 'I', '', '', '', '', '', 'NM'),
(1138, '002', '2019-06-03 12:42:12', '2019-06-03', '12:32', ' ', '2019-06-03 12:32:00', 'I', '', '', '', '19.1997096,73.174538', '', 'LM'),
(1269, '008', '2019-06-04 20:25:39', '2019-05-03', '11:26', ' ', '2019-05-03 11:26:00', 'I', '', '', '', '19.1996979,73.1744871', '', 'NM'),
(1268, '008', '2019-06-04 20:25:15', '2019-05-02', ' ', '20:36', '2019-05-02 20:36:00', 'O', '540', '544', '4', '', '19.1997468,73.1745248', ''),
(1267, '008', '2019-06-04 20:23:39', '2019-05-02', '11:32', ' ', '2019-05-02 11:32:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1142, '005', '2019-06-03 16:35:30', '2019-06-03', '14:27', ' ', '2019-06-03 14:27:00', 'I', '', '', '', '19.1997181,73.1745008', '', 'EM'),
(1143, '005', '2019-06-03 19:41:33', '2019-06-03', ' ', '19:29', '2019-06-03 19:29:00', 'O', '510', '302', '-208', '', '19.2005802,73.1689077', ''),
(1144, '003', '2019-06-03 19:47:03', '2019-06-03', ' ', '19:46', '2019-06-03 19:46:00', 'O', '510', '519', '9', '', '', ''),
(1145, '004', '2019-06-03 20:39:08', '2019-05-27', '12:02', ' ', '2019-05-27 12:02:00', 'I', '', '', '', '19.1998383,73.1746494', '', 'HM'),
(1146, '004', '2019-06-03 20:39:23', '2019-05-27', ' ', '20:46', '2019-05-27 20:46:00', 'O', '540', '524', '-16', '', '19.1998383,73.1746494', ''),
(1147, '004', '2019-06-03 20:39:43', '2019-05-28', '11:35', ' ', '2019-05-28 11:35:00', 'I', '', '', '', '19.1997659,73.1745585', '', 'NM'),
(1148, '004', '2019-06-03 20:39:57', '2019-05-28', ' ', '20:35', '2019-05-28 20:35:00', 'O', '540', '540', '0', '', '19.1997639,73.1745794', ''),
(1149, '004', '2019-06-03 20:42:46', '2019-05-30', '11:58', ' ', '2019-05-30 11:58:00', 'I', '', '', '', '19.1997742,73.1745599', '', 'HM'),
(1150, '004', '2019-06-03 20:42:55', '2019-05-30', ' ', '20:43', '2019-05-30 20:43:00', 'O', '540', '525', '-15', '', '19.1997567,73.1745402', ''),
(1208, '001', '2019-06-04 18:45:35', '2019-05-02', '12:02', ' ', '2019-05-02 12:02:00', 'I', '', '', '', '19.1997646,73.1744792', '', 'NM'),
(1153, '009', '2019-06-03 21:00:49', '2019-06-03', ' ', '21:00', '2019-06-03 21:00:00', 'O', '510', '584', '74', '', '19.1997225,73.1744988', ''),
(1154, '002', '2019-06-03 21:04:50', '2019-06-03', ' ', '21:04', '2019-06-03 21:04:00', 'O', '510', '512', '2', '', '19.1999005,73.1746286', ''),
(1155, '011', '2019-06-03 21:06:48', '2019-06-03', ' ', '21:03', '2019-06-03 21:03:00', 'O', '540', '544', '4', '', '19.2007221,73.1743448', ''),
(1156, '010', '2019-06-03 21:08:44', '2019-06-03', ' ', '21:03', '2019-06-03 21:03:00', 'O', '540', '542', '2', '', '19.2006087,73.1729101', ''),
(1157, '005', '2019-06-04 10:42:50', '2019-06-04', '10:30', ' ', '2019-06-04 10:30:00', 'I', '', '', '', '19.206028,73.1952178', '', 'NM'),
(1158, '003', '2019-06-04 11:00:21', '2019-06-04', '10:36', ' ', '2019-06-04 10:36:00', 'I', '', '', '', '19.199748,73.1745329', '', 'NM'),
(1159, '011', '2019-06-04 11:53:30', '2019-06-04', '11:49', ' ', '2019-06-04 11:49:00', 'I', '', '', '', '19.1997254,73.1744805', '', 'NM'),
(1160, '002', '2019-06-04 12:01:33', '2019-06-04', '11:58', ' ', '2019-06-04 11:58:00', 'I', '', '', '', '19.1997134,73.1745039', '', 'NM'),
(1161, '010', '2019-06-04 12:07:28', '2019-06-04', '12:03', ' ', '2019-06-04 12:03:00', 'I', '', '', '', '', '', 'NM'),
(1265, '008', '2019-06-04 20:20:15', '2019-05-01', '11:35', ' ', '2019-05-01 11:35:00', 'I', '', '', '', '19.1996959,73.1743293', '', 'NM'),
(1266, '008', '2019-06-04 20:20:41', '2019-05-01', ' ', '20:45', '2019-05-01 20:45:00', 'O', '540', '550', '10', '', '19.1997294,73.174506', ''),
(1164, '025', '2019-06-04 12:22:31', '2019-06-01', '12:21', ' ', '2019-06-01 12:21:00', 'I', '', '', '', '19.1996891,73.17458', '', 'EM'),
(1165, '025', '2019-06-04 12:23:02', '2019-06-03', '12:21', ' ', '2019-06-03 12:21:00', 'I', '', '', '', '19.1996891,73.17458', '', 'EM'),
(1166, '025', '2019-06-04 12:23:08', '2019-06-04', '12:21', ' ', '2019-06-04 12:21:00', 'I', '', '', '', '19.1996891,73.17458', '', 'HM'),
(1167, '006', '2019-06-04 12:30:36', '2019-05-25', ' ', '20:25', '2019-05-25 20:25:00', 'O', '540', '547', '7', '', '', ''),
(1168, '009', '2019-06-04 13:26:56', '2019-06-04', '13:08', ' ', '2019-06-04 13:08:00', 'I', '', '', '', '19.1997027,73.1744977', '', 'LM'),
(1260, '003', '2019-06-04 19:35:13', '2019-06-04', ' ', '19:34', '2019-06-04 19:34:00', 'O', '510', '538', '28', '', '19.1998961,73.17472', ''),
(1245, '001', '2019-06-04 19:23:36', '2019-05-27', '13:47', ' ', '2019-05-27 13:47:00', 'I', '', '', '', '19.1997275,73.1745016', '', 'EM'),
(1204, '030', '2019-06-04 20:13:28', '2019-06-04', '11:13', ' ', '2019-06-04 11:13:00', 'I', '', '', '', '19.1996959,73.1743293', '', 'NM'),
(1203, '012', '2019-06-04 17:48:25', '2019-06-04', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1202, '006', '2019-06-04 17:48:25', '2019-06-04', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1201, '004', '2019-06-10 17:34:59', '2019-06-04', '15:30', ' ', '2019-06-04 15:30:00', 'I', '', '', '', '19.1996373,73.174438', '', 'EM'),
(1206, '001', '2019-06-04 18:41:03', '2019-05-01', ' ', '20:44', '2019-05-01 20:44:00', 'O', '510', '554', '44', '', '19.1997168,73.1744867', ''),
(1234, '001', '2019-06-04 19:17:10', '2019-05-17', '12:02', ' ', '2019-05-17 12:02:00', 'I', '', '', '', '19.1997391,73.1745058', '', 'NM'),
(1228, '001', '2019-06-04 19:12:36', '2019-05-14', '12:03', ' ', '2019-05-14 12:03:00', 'I', '', '', '', '19.1997964,73.1746013', '', 'NM'),
(1223, '001', '2019-06-04 19:09:10', '2019-05-10', ' ', '20:50', '2019-05-10 20:50:00', 'O', '510', '524', '14', '', '19.1997338,73.1745196', ''),
(1221, '001', '2019-06-04 19:04:39', '2019-05-09', ' ', '21:12', '2019-05-09 21:12:00', 'O', '510', '549', '39', '', '19.1997431,73.1745087', ''),
(1219, '001', '2019-06-04 19:03:35', '2019-05-08', ' ', '21:17', '2019-05-08 21:17:00', 'O', '510', '552', '42', '', '19.1997304,73.1745044', ''),
(1217, '001', '2019-06-04 19:02:12', '2019-05-07', ' ', '20:56', '2019-05-07 20:56:00', 'O', '510', '569', '59', '', '19.1997166,73.1744859', ''),
(1215, '001', '2019-06-04 18:58:56', '2019-05-06', ' ', '20:54', '2019-05-06 20:54:00', 'O', '510', '537', '27', '', '19.1998962,73.1747031', ''),
(1213, '001', '2019-06-04 18:57:40', '2019-05-04', ' ', '20:42', '2019-05-04 20:42:00', 'O', '510', '524', '14', '', '19.1997493,73.1745278', ''),
(1211, '001', '2019-06-04 18:49:10', '2019-05-03', ' ', '21:30', '2019-05-03 21:30:00', 'O', '510', '593', '83', '', '19.1997086,73.1744723', ''),
(1210, '001', '2019-06-04 18:47:40', '2019-05-03', '11:37', ' ', '2019-05-03 11:37:00', 'I', '', '', '', '19.199712,73.1744901', '', 'NM'),
(1209, '001', '2019-06-04 18:45:58', '2019-05-02', ' ', '20:49', '2019-05-02 20:49:00', 'O', '510', '527', '17', '', '19.1997102,73.174453', ''),
(1205, '001', '2019-06-04 18:40:49', '2019-05-01', '11:30', ' ', '2019-05-01 11:30:00', 'I', '', '', '', '19.1997396,73.1745144', '', 'NM'),
(1321, '002', '2019-06-05 21:11:32', '2019-06-05', '12:01', ' ', '2019-06-05 12:01:00', 'I', '', '', '', '19.1996482,73.1744497', '', 'NM'),
(1299, '008', '2019-06-04 20:47:41', '2019-05-24', '12:22', ' ', '2019-05-24 12:22:00', 'I', '', '', '', '19.1997208,73.1744941', '', 'NM'),
(1297, '008', '2019-06-04 20:45:47', '2019-05-22', ' ', '21:12', '2019-05-22 21:12:00', 'O', '540', '540', '0', '', '19.1997027,73.1744913', ''),
(1295, '008', '2019-06-04 20:42:42', '2019-05-21', ' ', '21:14', '2019-05-21 21:14:00', 'O', '540', '539', '-1', '', '19.1997154,73.1744818', ''),
(1293, '008', '2019-06-04 20:41:27', '2019-05-20', ' ', '21:05', '2019-05-20 21:05:00', 'O', '540', '524', '-16', '', '19.1997027,73.1744913', ''),
(1291, '008', '2019-06-04 20:40:16', '2019-05-18', ' ', '20:39', '2019-05-18 20:39:00', 'O', '540', '499', '-41', '', '19.1997027,73.1744913', ''),
(1282, '008', '2019-06-04 20:33:37', '2019-05-14', ' ', '21:05', '2019-05-14 21:05:00', 'O', '540', '479', '-61', '', '19.1997027,73.1744913', ''),
(1281, '008', '2019-06-04 20:33:13', '2019-05-14', '13:06', ' ', '2019-05-14 13:06:00', 'I', '', '', '', '19.1997197,73.1744955', '', 'LM'),
(1278, '008', '2019-06-04 20:30:59', '2019-05-10', ' ', '20:46', '2019-05-10 20:46:00', 'O', '540', '547', '7', '', '19.1997155,73.1745062', ''),
(1277, '008', '2019-06-04 20:30:43', '2019-05-10', '11:39', ' ', '2019-05-10 11:39:00', 'I', '', '', '', '19.1997027,73.1744913', '', 'NM'),
(1276, '008', '2019-06-04 20:30:20', '2019-05-09', ' ', '20:50', '2019-05-09 20:50:00', 'O', '540', '567', '27', '', '-', ''),
(1274, '008', '2019-06-04 20:27:59', '2019-05-06', ' ', '20:50', '2019-05-06 20:50:00', 'O', '540', '553', '13', '', '19.1997428,73.1745205', ''),
(1270, '008', '2019-06-04 20:25:59', '2019-05-03', ' ', '20:33', '2019-05-03 20:33:00', 'O', '540', '547', '7', '', '19.1997435,73.1745218', ''),
(1324, '005', '2019-06-06 11:56:46', '2019-06-05', '10:38', ' ', '2019-06-05 10:38:00', 'I', '', '', '', '-', '', 'NM'),
(1325, '006', '2019-06-05 12:30:01', '2019-06-05', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1326, '008', '2019-06-05 12:30:01', '2019-06-05', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1327, '009', '2019-06-05 13:28:36', '2019-06-05', '12:36', ' ', '2019-06-05 12:36:00', 'I', '', '', '', '19.1996415,73.1744392', '', 'NM'),
(1328, '010', '2019-06-06 20:04:16', '2019-06-05', '12:16', ' ', '2019-06-05 12:16:00', 'I', '', '', '', '', '', 'NM'),
(1329, '011', '2019-06-07 12:10:15', '2019-06-05', '12:08', ' ', '2019-06-05 12:08:00', 'I', '', '', '', '19.1996548,73.1744495', '', 'LM'),
(1330, '012', '2019-06-05 12:30:01', '2019-06-05', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1331, '025', '2019-06-05 12:30:01', '2019-06-05', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1332, '030', '2019-06-05 12:30:01', '2019-06-05', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1333, '003', '2019-06-05 19:30:23', '2019-06-05', ' ', '19:30', '2019-06-05 19:30:00', 'O', '510', '515', '5', '', '', ''),
(1334, '002', '2019-06-05 21:11:48', '2019-06-05', ' ', '21:11', '2019-06-05 21:11:00', 'O', '510', '550', '40', '', '19.1996497,73.1744523', ''),
(1335, '009', '2019-06-05 21:17:24', '2019-06-05', ' ', '21:17', '2019-06-05 21:17:00', 'O', '510', '521', '11', '', '19.1998414,73.1746896', ''),
(1360, '012', '2019-06-06 12:16:32', '2019-06-06', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1359, '011', '2019-06-07 12:11:08', '2019-06-06', '17:14', ' ', '2019-06-06 17:14:00', 'I', '', '', '', '19.1996587,73.1744579', '', 'EM'),
(1350, '001', '2019-06-10 17:53:27', '2019-06-06', '11:49', ' ', '2019-06-06 11:49:00', 'I', '', '', '', '19.2016734,73.173497', '', 'NM'),
(1349, '005', '2019-06-06 12:07:09', '2019-06-05', ' ', '19:16', '2019-06-05 19:16:00', 'O', '510', '518', '8', '', '19.1996804,73.1744805', ''),
(1358, '010', '2019-06-06 20:05:43', '2019-06-06', '13:13', ' ', '2019-06-06 13:13:00', 'I', '', '', '', '', '', 'EM'),
(1357, '009', '2019-06-06 21:02:05', '2019-06-06', '11:43', ' ', '2019-06-06 11:43:00', 'I', '', '', '', '19.1996706,73.1744594', '', 'NM'),
(1356, '008', '2019-06-06 13:39:28', '2019-06-06', '11:45', ' ', '2019-06-06 11:45:00', 'I', '', '', '', '19.1996636,73.1745086', '', 'NM'),
(1355, '006', '2019-06-06 12:16:32', '2019-06-06', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1354, '005', '2019-06-06 16:24:51', '2019-06-06', '11:03', ' ', '2019-06-06 11:03:00', 'I', '', '', '', '19.199651,73.1744615', '', 'NM'),
(1353, '004', '2019-06-10 18:09:14', '2019-06-06', '11:57', ' ', '2019-06-06 11:57:00', 'I', '', '', '', '19.1996373,73.174438', '', 'NM'),
(1352, '003', '2019-06-06 20:14:43', '2019-06-06', '10:50', ' ', '2019-06-06 10:50:00', 'I', '', '', '', '19.2351772,73.1395705', '', 'NM'),
(1351, '002', '2019-06-06 18:42:47', '2019-06-06', '11:57', ' ', '2019-06-06 11:57:00', 'I', '', '', '', '19.1996563,73.1744342', '', 'NM'),
(1361, '025', '2019-06-06 12:16:32', '2019-06-06', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1362, '030', '2019-06-06 12:16:32', '2019-06-06', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1363, '008', '2019-06-06 12:19:50', '2019-06-04', ' ', '21:08', '2019-06-04 21:08:00', 'O', '540', '546', '6', '', '19.1996817,73.1744792', ''),
(1364, '008', '2019-05-05 12:01:01', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1365, '001', '2019-05-05 12:01:01', '2019-05-05', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1366, '001', '2019-05-05 12:01:01', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1367, '008', '2019-05-05 12:01:01', '2019-05-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1368, '008', '2019-05-05 12:01:01', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1369, '001', '2019-05-05 12:01:01', '2019-05-19', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1370, '001', '2019-05-05 12:01:01', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1371, '008', '2019-05-05 12:01:01', '2019-05-26', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1372, '008', '2019-05-05 12:01:01', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1373, '001', '2019-05-05 12:01:01', '2019-06-02', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1374, '001', '2019-05-05 12:01:01', '2019-05-18', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1375, '001', '2019-05-05 12:01:01', '2019-05-22', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1376, '001', '2019-05-05 12:01:01', '2019-05-24', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'P'),
(1377, '008', '2019-05-05 12:01:01', '2019-05-07', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1378, '008', '2019-05-05 12:01:01', '2019-05-08', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1379, '008', '2019-05-05 12:01:01', '2019-05-13', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1380, '008', '2019-05-05 12:01:01', '2019-05-13', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1381, '008', '2019-05-05 12:01:01', '2019-05-13', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1382, '002', '2019-06-01 12:01:01', '2019-06-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1383, '005', '2019-06-06 19:29:59', '2019-06-06', ' ', '19:17', '2019-06-06 19:17:00', 'O', '510', '494', '-16', '', '19.1993419,73.1681198', ''),
(1384, '002', '2019-06-06 19:35:15', '2019-06-06', ' ', '19:35', '2019-06-06 19:35:00', 'O', '510', '458', '-52', '', '19.1996373,73.174438', ''),
(1385, '010', '2019-06-06 20:03:37', '2019-06-04', ' ', '21:06', '2019-06-04 21:06:00', 'O', '540', '543', '3', '', '', ''),
(1386, '010', '2019-06-06 20:04:54', '2019-06-05', ' ', '21:13', '2019-06-05 21:13:00', 'O', '540', '537', '-3', '', '', ''),
(1387, '009', '2019-06-06 21:02:12', '2019-06-06', ' ', '21:02', '2019-06-06 21:02:00', 'O', '510', '559', '49', '', '19.1996725,73.1744547', ''),
(1388, '003', '2019-06-06 21:15:44', '2019-06-06', ' ', '19:33', '2019-06-06 19:33:00', 'O', '510', '523', '13', '', '19.2568624,73.3719229', ''),
(1389, '001', '2019-06-10 17:54:14', '2019-06-07', '12:08', ' ', '2019-06-07 12:08:00', 'I', '', '', '', '19.2016734,73.173497', '', 'LM'),
(1390, '002', '2019-06-07 12:05:54', '2019-06-07', '12:02', ' ', '2019-06-07 12:02:00', 'I', '', '', '', '19.1996394,73.1744222', '', 'NM'),
(1391, '003', '2019-06-08 10:49:56', '2019-06-07', '11:19', ' ', '2019-06-07 11:19:00', 'I', '', '', '', '19.199676,73.1744602', '', 'NM'),
(1392, '004', '2019-06-10 18:10:06', '2019-06-07', '12:07', ' ', '2019-06-07 12:07:00', 'I', '', '', '', '19.1996373,73.174438', '', 'LM'),
(1393, '005', '2019-06-07 11:07:34', '2019-06-07', '11:04', ' ', '2019-06-07 11:04:00', 'I', '', '', '', '19.199695,73.1745071', '', 'NM'),
(1394, '006', '2019-06-07 09:58:02', '2019-06-07', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1395, '008', '2019-06-07 12:00:11', '2019-06-07', '11:30', ' ', '2019-06-07 11:30:00', 'I', '', '', '', '19.1996776,73.1744464', '', 'NM'),
(1396, '009', '2019-06-07 20:35:22', '2019-06-07', '13:05', ' ', '2019-06-07 13:05:00', 'I', '', '', '', '19.1996575,73.1744553', '', 'NM'),
(1397, '010', '2019-06-07 13:01:34', '2019-06-07', '12:04', ' ', '2019-06-07 12:04:00', 'I', '', '', '', '', '', 'NM'),
(1398, '011', '2019-06-07 12:11:58', '2019-06-07', '12:04', ' ', '2019-06-07 12:04:00', 'I', '', '', '', '19.1996379,73.174445', '', 'NM'),
(1399, '012', '2019-06-07 09:58:02', '2019-06-07', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1400, '025', '2019-06-07 09:58:02', '2019-06-07', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1401, '030', '2019-06-07 09:58:02', '2019-06-07', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1402, '008', '2019-06-07 11:59:49', '2019-06-06', ' ', '20:48', '2019-06-06 20:48:00', 'O', '540', '543', '3', '', '19.1998159,73.1745648', ''),
(1403, '011', '2019-06-07 12:10:35', '2019-06-05', ' ', '21:13', '2019-06-05 21:13:00', 'O', '540', '545', '5', '', '19.1996463,73.174449', ''),
(1404, '011', '2019-06-07 12:11:27', '2019-06-06', ' ', '21:03', '2019-06-06 21:03:00', 'O', '540', '229', '-311', '', '19.1996388,73.1744469', ''),
(1405, '005', '2019-06-07 17:18:15', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'P'),
(1406, '002', '2019-06-07 19:09:56', '2019-06-07', ' ', '19:09', '2019-06-07 19:09:00', 'O', '510', '427', '-83', '', '19.1998143,73.1746474', ''),
(1407, '005', '2019-06-07 19:40:32', '2019-06-07', ' ', '19:25', '2019-06-07 19:25:00', 'O', '510', '501', '-9', '', '19.1991684,73.1698096', ''),
(1408, '011', '2019-06-07 21:13:23', '2019-06-07', ' ', '21:08', '2019-06-07 21:08:00', 'O', '540', '544', '4', '', '19.2006995,73.1732761', ''),
(1409, '009', '2019-06-07 21:21:59', '2019-06-07', ' ', '21:20', '2019-06-07 21:20:00', 'O', '510', '495', '-15', '', '19.2018848,73.1745486', ''),
(1410, '010', '2019-06-08 08:28:37', '2019-06-07', ' ', '21:07', '2019-06-07 21:07:00', 'O', '540', '543', '3', '', '', ''),
(1411, '001', '2019-06-10 17:54:44', '2019-06-08', '11:45', ' ', '2019-06-08 11:45:00', 'I', '', '', '', '19.199922,73.1747101', '', 'NM'),
(1412, '002', '2019-06-08 12:01:31', '2019-06-08', '11:59', ' ', '2019-06-08 11:59:00', 'I', '', '', '', '19.1996473,73.1744381', '', 'NM'),
(1413, '003', '2019-06-08 10:50:48', '2019-06-08', '10:33', ' ', '2019-06-08 10:33:00', 'I', '', '', '', '19.1996792,73.1744659', '', 'NM'),
(1414, '004', '2019-06-10 18:11:06', '2019-06-08', '11:30', ' ', '2019-06-08 11:30:00', 'I', '', '', '', '19.1996373,73.174438', '', 'NM'),
(1415, '005', '2019-06-08 10:55:32', '2019-06-08', '10:39', ' ', '2019-06-08 10:39:00', 'I', '', '', '', '19.1996456,73.1744533', '', 'NM'),
(1416, '006', '2019-06-08 09:27:02', '2019-06-08', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1417, '008', '2019-06-10 11:52:12', '2019-06-08', '11:45', ' ', '2019-06-08 11:45:00', 'I', '', '', '', '19.1996658,73.1744639', '', 'NM'),
(1418, '009', '2019-06-08 20:45:29', '2019-06-08', '13:18', ' ', '2019-06-08 13:18:00', 'I', '', '', '', '19.1997049,73.1744691', '', 'LM'),
(1419, '010', '2019-06-08 12:17:04', '2019-06-08', '12:09', ' ', '2019-06-08 12:09:00', 'I', '', '', '', '', '', 'NM'),
(1420, '011', '2019-06-10 15:19:03', '2019-06-08', '11:55', ' ', '2019-06-08 11:55:00', 'I', '', '', '', '19.1997474,73.1745731', '', 'NM'),
(1421, '012', '2019-06-08 09:27:02', '2019-06-08', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1422, '025', '2019-06-08 09:27:02', '2019-06-08', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1423, '030', '2019-06-08 09:27:02', '2019-06-08', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1424, '003', '2019-06-08 10:50:09', '2019-06-07', ' ', '19:45', '2019-06-07 19:45:00', 'O', '510', '506', '-4', '', '19.1996805,73.1744767', ''),
(1425, '010', '2019-06-08 12:18:32', '2019-06-06', ' ', '21:02', '2019-06-06 21:02:00', 'O', '540', '469', '-71', '', '', ''),
(1426, '003', '2019-06-08 17:22:04', '2019-06-08', ' ', '17:21', '2019-06-08 17:21:00', 'O', '510', '408', '-102', '', '19.2020332,73.173497', ''),
(1427, '009', '2019-06-08 20:45:41', '2019-06-08', ' ', '20:45', '2019-06-08 20:45:00', 'O', '510', '447', '-63', '', '19.1996873,73.1745111', ''),
(1428, '002', '2019-06-09 01:43:04', '2019-06-08', ' ', '21:15', '2019-06-08 21:15:00', 'O', '510', '556', '46', '', '19.2144212,73.2046533', ''),
(1429, '002', '2019-06-09 01:44:17', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1430, '002', '2019-06-09 01:44:17', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'C'),
(1431, '001', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1432, '002', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1433, '003', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1434, '004', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1435, '005', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1436, '006', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1437, '008', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1438, '009', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1439, '010', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1440, '011', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1441, '012', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1442, '025', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN');
INSERT INTO `j_atendance` (`id`, `emp_id`, `c_date`, `login_date`, `login_time`, `logout_time`, `login_date_time`, `tag`, `total_minut`, `work_time`, `bal_minut`, `location_in`, `location_out`, `status`) VALUES
(1443, '030', '2019-06-09 12:31:01', '2019-06-09', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1444, '005', '2019-06-10 07:08:00', '2019-06-08', ' ', '17:00', '2019-06-08 17:00:00', 'O', '510', '381', '-129', '', '16.208028,77.3588222', ''),
(1445, '001', '2019-06-10 17:55:10', '2019-06-10', '11:53', ' ', '2019-06-10 11:53:00', 'I', '', '', '', '19.2016734,73.173497', '', 'NM'),
(1446, '002', '2019-06-10 11:57:16', '2019-06-10', '11:55', ' ', '2019-06-10 11:55:00', 'I', '', '', '', '19.1996376,73.1744385', '', 'NM'),
(1447, '003', '2019-06-10 08:02:03', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1448, '004', '2019-06-10 18:11:49', '2019-06-10', '14:33', ' ', '2019-06-10 14:33:00', 'I', '', '', '', '19.1996373,73.174438', '', 'EM'),
(1449, '006', '2019-06-10 08:02:03', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1450, '008', '2019-06-10 11:51:29', '2019-06-10', '11:42', ' ', '2019-06-10 11:42:00', 'I', '', '', '', '19.1996392,73.1744406', '', 'NM'),
(1451, '009', '2019-06-15 18:42:47', '2019-06-10', '11:44', ' ', '2019-06-10 11:44:00', 'I', '', '', '', '-', '', 'NM'),
(1452, '010', '2019-06-10 14:08:16', '2019-06-10', '11:42', ' ', '2019-06-10 11:42:00', 'I', '', '', '', '', '', 'NM'),
(1453, '011', '2019-06-10 15:20:23', '2019-06-10', '15:09', ' ', '2019-06-10 15:09:00', 'I', '', '', '', '19.1998014,73.1746298', '', 'EM'),
(1454, '012', '2019-06-10 08:02:03', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1455, '025', '2019-06-10 08:02:03', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1456, '030', '2019-06-10 08:02:03', '2019-06-10', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1457, '008', '2019-06-10 11:52:26', '2019-06-08', ' ', '21:15', '2019-06-08 21:15:00', 'O', '540', '570', '30', '', '19.1996677,73.1744673', ''),
(1458, '008', '2019-06-10 11:52:59', '2019-06-07', ' ', '20:44', '2019-06-07 20:44:00', 'O', '540', '554', '14', '', '19.1996707,73.1744702', ''),
(1459, '010', '2019-06-10 14:08:31', '2019-06-08', ' ', '21:12', '2019-06-08 21:12:00', 'O', '540', '543', '3', '', '', ''),
(1460, '011', '2019-06-10 15:19:34', '2019-06-08', ' ', '21:13', '2019-06-08 21:13:00', 'O', '540', '558', '18', '', '19.1997407,73.1745583', ''),
(1461, '002', '2019-06-10 16:59:41', '2019-06-10', ' ', '17:00', '2019-06-10 17:00:00', 'O', '510', '305', '-205', '', '19.1996371,73.1744436', ''),
(1462, '004', '2019-06-10 17:35:34', '2019-06-04', ' ', '20:24', '2019-06-04 20:24:00', 'O', '540', '294', '-246', '', '19.1996414,73.1744447', ''),
(1463, '001', '2019-06-10 17:52:29', '2019-06-04', ' ', '18:12', '2019-06-04 18:12:00', 'O', '510', '288', '-222', '', '19.19968,73.1743467', ''),
(1464, '001', '2019-06-10 17:53:06', '2019-06-05', ' ', '21:25', '2019-06-05 21:25:00', 'O', '510', '560', '50', '', '19.1998,73.1745583', ''),
(1465, '001', '2019-06-10 17:53:37', '2019-06-06', ' ', '20:48', '2019-06-06 20:48:00', 'O', '510', '539', '29', '', '19.2016734,73.173497', ''),
(1466, '001', '2019-06-10 17:54:25', '2019-06-07', ' ', '21:04', '2019-06-07 21:04:00', 'O', '510', '536', '26', '', '19.2016734,73.173497', ''),
(1467, '001', '2019-06-10 17:54:56', '2019-06-08', ' ', '20:48', '2019-06-08 20:48:00', 'O', '510', '543', '33', '', '19.199865,73.1746533', ''),
(1468, '004', '2019-06-10 18:04:43', '2019-06-01', '11:29', ' ', '2019-06-01 11:29:00', 'I', '', '', '', '19.1996481,73.1744399', '', 'NM'),
(1469, '004', '2019-06-10 18:04:57', '2019-06-01', ' ', '21:04', '2019-06-01 21:04:00', 'O', '540', '575', '35', '', '19.1996481,73.1744399', ''),
(1470, '004', '2019-06-10 18:07:24', '2019-06-03', '11:40', ' ', '2019-06-03 11:40:00', 'I', '', '', '', '19.1996373,73.174438', '', 'NM'),
(1471, '004', '2019-06-10 18:07:45', '2019-06-03', ' ', '20:24', '2019-06-03 20:24:00', 'O', '540', '524', '-16', '', '19.1996373,73.174438', ''),
(1472, '004', '2019-06-10 18:08:43', '2019-06-05', ' ', '20:30', '2019-06-05 20:30:00', 'O', '540', '520', '-20', '', '19.1996373,73.174438', ''),
(1473, '004', '2019-06-10 18:09:47', '2019-06-06', ' ', '21:25', '2019-06-06 21:25:00', 'O', '540', '568', '28', '', '19.1996373,73.174438', ''),
(1474, '004', '2019-06-10 18:10:34', '2019-06-07', ' ', '20:41', '2019-06-07 20:41:00', 'O', '540', '514', '-26', '', '19.1996396,73.1744438', ''),
(1475, '004', '2019-06-10 18:11:19', '2019-06-08', ' ', '20:34', '2019-06-08 20:34:00', 'O', '540', '544', '4', '', '19.1996373,73.174438', ''),
(1476, '004', '2019-06-10 20:30:24', '2019-06-10', ' ', '20:30', '2019-06-10 20:30:00', 'O', '540', '357', '-183', '', '19.1996373,73.174438', ''),
(1477, '008', '2019-06-11 06:55:36', '2019-06-10', ' ', '21:15', '2019-06-10 21:15:00', 'O', '540', '573', '33', '', '19.2366788,73.1539129', ''),
(1478, '001', '2019-06-11 14:46:50', '2019-06-11', '11:44', ' ', '2019-06-11 11:44:00', 'I', '', '', '', '19.199643,73.1744528', '', 'NM'),
(1479, '003', '2019-06-11 17:54:10', '2019-06-11', '13:15', ' ', '2019-06-11 13:15:00', 'I', '', '', '', '19.1996512,73.1744527', '', 'EM'),
(1480, '004', '2019-06-21 18:56:44', '2019-06-11', '11:55', ' ', '2019-06-11 11:55:00', 'I', '', '', '', '19.1996438,73.1744742', '', 'NM'),
(1481, '005', '2019-06-11 16:27:10', '2019-06-11', '13:50', ' ', '2019-06-11 13:50:00', 'I', '', '', '', '19.1996373,73.174438', '', 'EM'),
(1482, '006', '2019-06-11 07:01:02', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1483, '008', '2019-06-11 07:01:02', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1484, '009', '2019-06-11 20:56:30', '2019-06-11', '18:00', ' ', '2019-06-11 18:00:00', 'I', '', '', '', '19.1996387,73.1744401', '', 'EM'),
(1485, '010', '2019-06-11 12:24:03', '2019-06-11', '12:05', ' ', '2019-06-11 12:05:00', 'I', '', '', '', '', '', 'NM'),
(1486, '011', '2019-06-11 11:58:37', '2019-06-11', '11:51', ' ', '2019-06-11 11:51:00', 'I', '', '', '', '19.1996623,73.1744559', '', 'NM'),
(1487, '012', '2019-06-11 07:01:02', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1488, '025', '2019-06-11 07:01:02', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1489, '030', '2019-06-11 07:01:02', '2019-06-11', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1490, '011', '2019-06-11 11:58:25', '2019-06-10', ' ', '21:15', '2019-06-10 21:15:00', 'O', '540', '366', '-174', '', '19.1996709,73.1744645', ''),
(1491, '010', '2019-06-11 12:23:15', '2019-06-10', ' ', '21:15', '2019-06-10 21:15:00', 'O', '540', '573', '33', '', '', ''),
(1492, '001', '2019-06-11 14:44:54', '2019-06-10', ' ', '20:18', '2019-06-10 20:18:00', 'O', '510', '505', '-5', '', '19.1996373,73.174438', ''),
(1493, '003', '2019-06-11 20:07:25', '2019-06-11', ' ', '20:07', '2019-06-11 20:07:00', 'O', '510', '412', '-98', '', '19.1996393,73.1744435', ''),
(1494, '005', '2019-06-11 20:07:55', '2019-06-11', ' ', '19:33', '2019-06-11 19:33:00', 'O', '510', '343', '-167', '', '19.1993394,73.1681255', ''),
(1495, '009', '2019-06-15 18:42:47', '2019-06-10', ' ', '21:15', '2019-06-10 21:15:00', 'O', '510', '571', '-61', '', '-', ''),
(1496, '009', '2019-06-11 20:56:42', '2019-06-11', ' ', '20:56', '2019-06-11 20:56:00', 'O', '510', '176', '-334', '', '19.1996393,73.1744406', ''),
(1497, '001', '2019-06-21 18:25:20', '2019-06-12', '12:00', ' ', '2019-06-12 12:00:00', 'I', '', '', '', '19.1996578,73.1744842', '', 'NM'),
(1498, '003', '2019-06-14 19:54:14', '2019-06-12', '10:59', ' ', '2019-06-12 10:59:00', 'I', '', '', '', '19.2279617,73.1493067', '', 'NM'),
(1499, '004', '2019-06-21 18:57:33', '2019-06-12', '11:43', ' ', '2019-06-12 11:43:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1500, '005', '2019-06-12 11:44:02', '2019-06-12', '10:35', ' ', '2019-06-12 10:35:00', 'I', '', '', '', '19.199657,73.1744459', '', 'NM'),
(1501, '006', '2019-06-12 06:37:02', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1502, '008', '2019-06-12 06:37:02', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1504, '010', '2019-06-13 19:12:45', '2019-06-12', '12:05', ' ', '2019-06-12 12:05:00', 'I', '', '', '', '', '', 'NM'),
(1505, '011', '2019-06-15 12:10:16', '2019-06-12', '11:59', ' ', '2019-06-12 11:59:00', 'I', '', '', '', '19.1996906,73.1744542', '', 'NM'),
(1506, '012', '2019-06-12 06:37:02', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1507, '025', '2019-06-12 06:37:02', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1508, '030', '2019-06-12 06:37:02', '2019-06-12', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1509, '010', '2019-06-12 08:08:29', '2019-06-11', ' ', '21:01', '2019-06-11 21:01:00', 'O', '540', '536', '-4', '', '', ''),
(1568, '002', '2019-06-15 20:38:27', '2019-06-15', ' ', '20:38', '2019-06-15 20:38:00', 'O', '510', '520', '10', '', '19.1996739,73.1744755', ''),
(1510, '005', '2019-06-12 20:52:15', '2019-06-12', ' ', '19:25', '2019-06-12 19:25:00', 'O', '510', '530', '20', '', '19.1992857,73.1672284', ''),
(1511, '001', '2019-06-21 18:25:53', '2019-06-13', '11:25', ' ', '2019-06-13 11:25:00', 'I', '', '', '', '19.1996601,73.174487', '', 'NM'),
(1512, '002', '2019-06-14 15:42:02', '2019-06-13', '11:55', ' ', '2019-06-13 11:55:00', 'I', '', '', '', '19.1996852,73.1744698', '', 'NM'),
(1513, '003', '2019-06-14 19:48:58', '2019-06-13', '10:45', ' ', '2019-06-13 10:45:00', 'I', '', '', '', '19.2198917,73.1599183', '', 'NM'),
(1514, '004', '2019-06-21 18:58:22', '2019-06-13', '11:55', ' ', '2019-06-13 11:55:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1515, '005', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1516, '006', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1517, '008', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1518, '009', '2019-06-14 19:17:08', '2019-06-13', '15:05', ' ', '2019-06-13 15:05:00', 'I', '', '', '', '', '', 'HM'),
(1519, '010', '2019-06-13 19:13:05', '2019-06-13', '12:05', ' ', '2019-06-13 12:05:00', 'I', '', '', '', '', '', 'NM'),
(1520, '011', '2019-06-15 12:35:08', '2019-06-13', '11:20', ' ', '2019-06-13 11:20:00', 'I', '', '', '', '19.1996686,73.1744399', '', 'NM'),
(1521, '012', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1522, '025', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1523, '030', '2019-06-13 10:50:01', '2019-06-13', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1524, '010', '2019-06-13 19:12:55', '2019-06-12', ' ', '21:07', '2019-06-12 21:07:00', 'O', '540', '542', '2', '', '', ''),
(1525, '001', '2019-06-21 18:26:22', '2019-06-14', '12:00', ' ', '2019-06-14 12:00:00', 'I', '', '', '', '19.1996488,73.1744723', '', 'NM'),
(1526, '002', '2019-06-14 15:39:15', '2019-06-14', '15:32', ' ', '2019-06-14 15:32:00', 'I', '', '', '', '19.199669,73.1744517', '', 'EM'),
(1527, '003', '2019-06-14 19:57:39', '2019-06-14', '10:49', ' ', '2019-06-14 10:49:00', 'I', '', '', '', '19.2278815,73.1493007', '', 'NM'),
(1528, '004', '2019-06-21 18:59:36', '2019-06-14', '11:55', ' ', '2019-06-14 11:55:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1529, '005', '2019-06-14 11:01:37', '2019-06-14', '10:45', ' ', '2019-06-14 10:45:00', 'I', '', '', '', '19.1997001,73.1744652', '', 'NM'),
(1530, '006', '2019-06-14 09:12:01', '2019-06-14', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1531, '008', '2019-06-14 09:12:01', '2019-06-14', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1532, '009', '2019-06-14 19:18:42', '2019-06-14', '12:55', ' ', '2019-06-14 12:55:00', 'I', '', '', '', '', '', 'NM'),
(1533, '010', '2019-06-14 12:14:56', '2019-06-14', '12:05', ' ', '2019-06-14 12:05:00', 'I', '', '', '', '', '', 'NM'),
(1534, '011', '2019-06-15 12:36:18', '2019-06-14', '12:01', ' ', '2019-06-14 12:01:00', 'I', '', '', '', '19.1996632,73.1743422', '', 'NM'),
(1535, '012', '2019-06-14 09:12:01', '2019-06-14', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1536, '025', '2019-06-14 09:12:01', '2019-06-14', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1537, '030', '2019-06-14 09:12:01', '2019-06-14', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1538, '010', '2019-06-14 12:14:23', '2019-06-13', ' ', '21:04', '2019-06-13 21:04:00', 'O', '540', '539', '-1', '', '', ''),
(1539, '002', '2019-06-14 15:42:34', '2019-06-13', ' ', '20:44', '2019-06-13 20:44:00', 'O', '510', '529', '19', '', '19.1996661,73.1744448', ''),
(1567, '005', '2019-06-15 19:43:27', '2019-06-15', ' ', '19:18', '2019-06-15 19:18:00', 'O', '510', '500', '-10', '', '19.1993397,73.1681411', ''),
(1541, '009', '2019-06-14 19:17:28', '2019-06-13', ' ', '21:15', '2019-06-13 21:15:00', 'O', '510', '370', '-140', '', '', ''),
(1542, '003', '2019-06-14 19:49:21', '2019-06-13', ' ', '19:26', '2019-06-13 19:26:00', 'O', '510', '521', '11', '', '19.2211133,73.1584783', ''),
(1543, '003', '2019-06-14 19:54:46', '2019-06-12', ' ', '19:04', '2019-06-12 19:04:00', 'O', '510', '485', '-25', '', '19.2279266,73.149389', ''),
(1544, '005', '2019-06-14 20:04:34', '2019-06-14', ' ', '20:04', '2019-06-14 20:04:00', 'O', '510', '559', '49', '', '19.1992354,73.1681458', ''),
(1545, '009', '2019-06-14 20:14:01', '2019-06-14', ' ', '20:15', '2019-06-14 20:15:00', 'O', '510', '440', '-70', '', '19.199657,73.1744459', ''),
(1546, '003', '2019-06-14 20:19:22', '2019-06-14', ' ', '19:29', '2019-06-14 19:29:00', 'O', '510', '520', '10', '', '19.2388181,73.1360498', ''),
(1548, '002', '2019-06-14 21:29:53', '2019-06-14', ' ', '21:29', '2019-06-14 21:29:00', 'O', '510', '357', '-153', '', '19.199657,73.1744459', ''),
(1549, '001', '2019-06-21 18:26:51', '2019-06-15', '11:55', ' ', '2019-06-15 11:55:00', 'I', '', '', '', '19.1996585,73.174484', '', 'NM'),
(1550, '002', '2019-06-15 12:02:58', '2019-06-15', '11:58', ' ', '2019-06-15 11:58:00', 'I', '', '', '', '19.199657,73.1744459', '', 'NM'),
(1551, '003', '2019-06-15 11:37:39', '2019-06-15', '10:45', ' ', '2019-06-15 10:45:00', 'I', '', '', '', '19.1996896,73.1744404', '', 'NM'),
(1552, '004', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1553, '005', '2019-06-15 12:04:14', '2019-06-15', '10:58', ' ', '2019-06-15 10:58:00', 'I', '', '', '', '19.1996868,73.1744868', '', 'NM'),
(1554, '006', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1555, '008', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1556, '009', '2019-06-15 15:44:20', '2019-06-15', '12:42', ' ', '2019-06-15 12:42:00', 'I', '', '', '', '19.1996603,73.174441', '', 'NM'),
(1557, '010', '2019-06-15 13:16:46', '2019-06-15', '12:01', ' ', '2019-06-15 12:01:00', 'I', '', '', '', '', '', 'NM'),
(1558, '011', '2019-06-15 14:37:22', '2019-06-15', '11:51', ' ', '2019-06-15 11:51:00', 'I', '', '', '', '19.1997252,73.1745211', '', 'NM'),
(1559, '012', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1560, '025', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1561, '030', '2019-06-15 00:32:01', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1562, '011', '2019-06-15 12:08:54', '2019-06-11', ' ', '12:03', '2019-06-11 12:03:00', 'O', '540', '12', '-528', '', '19.1997129,73.174512', ''),
(1563, '011', '2019-06-15 12:34:22', '2019-06-12', ' ', '21:07', '2019-06-12 21:07:00', 'O', '540', '548', '8', '', '19.1996711,73.1744549', ''),
(1564, '011', '2019-06-15 12:35:40', '2019-06-13', ' ', '21:04', '2019-06-13 21:04:00', 'O', '540', '584', '44', '', '19.1996909,73.1744361', ''),
(1565, '010', '2019-06-15 13:16:31', '2019-06-14', ' ', '21:00', '2019-06-14 21:00:00', 'O', '540', '535', '-5', '', '', ''),
(1566, '011', '2019-06-15 14:36:48', '2019-06-14', ' ', '21:00', '2019-06-14 21:00:00', 'O', '540', '539', '-1', '', '19.1996849,73.1744643', ''),
(1569, '011', '2019-06-15 21:14:40', '2019-06-15', ' ', '21:14', '2019-06-15 21:14:00', 'O', '540', '563', '23', '', '19.1996797,73.1744898', ''),
(1570, '001', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1571, '002', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1572, '003', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1573, '004', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1574, '005', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1575, '006', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1576, '008', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1577, '009', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1578, '010', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1579, '011', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1580, '012', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1581, '025', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1582, '030', '2019-06-16 00:32:01', '2019-06-16', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1583, '001', '2019-06-21 18:29:16', '2019-06-17', '12:05', ' ', '2019-06-17 12:05:00', 'I', '', '', '', '19.1996471,73.1744701', '', 'NM'),
(1584, '002', '2019-06-17 11:25:16', '2019-06-17', '11:23', ' ', '2019-06-17 11:23:00', 'I', '', '', '', '19.1996746,73.1744505', '', 'NM'),
(1585, '004', '2019-06-21 19:00:08', '2019-06-17', '11:38', ' ', '2019-06-17 11:38:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1586, '005', '2019-06-17 10:45:40', '2019-06-17', '10:42', ' ', '2019-06-17 10:42:00', 'I', '', '', '', '19.1997147,73.1745113', '', 'NM'),
(1587, '006', '2019-06-17 00:32:01', '2019-06-17', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1588, '008', '2019-06-17 00:32:01', '2019-06-17', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1589, '009', '2019-06-19 19:22:12', '2019-06-17', '17:20', ' ', '2019-06-17 17:20:00', 'I', '', '', '', '19.1996991,73.17473', '', 'EM'),
(1590, '010', '2019-06-19 16:00:23', '2019-06-17', '12:03', ' ', '2019-06-17 12:03:00', 'I', '', '', '', '', '', 'NM'),
(1591, '011', '2019-06-18 20:07:15', '2019-06-17', '11:35', ' ', '2019-06-17 11:35:00', 'I', '', '', '', '19.1996787,73.1744532', '', 'NM'),
(1592, '012', '2019-06-17 00:32:01', '2019-06-17', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1593, '025', '2019-06-17 00:32:01', '2019-06-17', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1594, '030', '2019-06-17 00:32:01', '2019-06-17', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1595, '009', '2019-06-17 02:35:26', '2019-06-15', ' ', '21:30', '2019-06-15 21:30:00', 'O', '510', '528', '18', '', '19.2382482,73.1572537', ''),
(1596, '010', '2019-06-17 11:15:25', '2019-06-15', ' ', '21:14', '2019-06-15 21:14:00', 'O', '540', '553', '13', '', '', ''),
(1597, '002', '2019-06-17 20:55:58', '2019-06-17', ' ', '20:55', '2019-06-17 20:55:00', 'O', '510', '572', '62', '', '', ''),
(1598, '005', '2019-06-17 22:46:02', '2019-06-17', ' ', '19:25', '2019-06-17 19:25:00', 'O', '510', '523', '13', '', '19.2005487,73.1690828', ''),
(1599, '001', '2019-06-21 18:29:52', '2019-06-18', '11:59', ' ', '2019-06-18 11:59:00', 'I', '', '', '', '19.1996536,73.174478', '', 'NM'),
(1600, '002', '2019-06-18 18:02:34', '2019-06-18', '11:42', ' ', '2019-06-18 11:42:00', 'I', '', '', '', '19.1996809,73.1744569', '', 'NM'),
(1601, '003', '2019-06-19 14:39:57', '2019-06-18', '10:30', ' ', '2019-06-18 10:30:00', 'I', '', '', '', '19.1996636,73.1744647', '', 'NM'),
(1602, '004', '2019-06-21 19:00:51', '2019-06-18', '11:11', ' ', '2019-06-18 11:11:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1603, '005', '2019-06-18 21:24:05', '2019-06-18', '10:30', ' ', '2019-06-18 10:30:00', 'I', '', '', '', '19.1993441,73.1681457', '', 'NM'),
(1604, '006', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1605, '008', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1606, '009', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1607, '010', '2019-06-19 16:01:34', '2019-06-18', '12:07', ' ', '2019-06-18 12:07:00', 'I', '', '', '', '', '', 'NM'),
(1608, '011', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1609, '012', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1610, '025', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1611, '030', '2019-06-18 00:32:01', '2019-06-18', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1612, '011', '2019-06-18 20:07:37', '2019-06-17', ' ', '18:47', '2019-06-17 18:47:00', 'O', '540', '432', '-108', '', '19.1996931,73.1744679', ''),
(1613, '005', '2019-06-18 21:24:14', '2019-06-18', ' ', '19:40', '2019-06-18 19:40:00', 'O', '510', '550', '40', '', '19.1993437,73.1681461', ''),
(1614, '002', '2019-06-18 23:39:18', '2019-06-18', ' ', '20:35', '2019-06-18 20:35:00', 'O', '510', '533', '23', '', '19.2142683,73.2044697', ''),
(1615, '001', '2019-06-21 18:30:43', '2019-06-19', '11:59', ' ', '2019-06-19 11:59:00', 'I', '', '', '', '19.1996582,73.1744838', '', 'NM'),
(1616, '002', '2019-06-19 12:36:21', '2019-06-19', '12:33', ' ', '2019-06-19 12:33:00', 'I', '', '', '', '19.1996738,73.1744926', '', 'LM'),
(1617, '003', '2019-06-19 14:41:39', '2019-06-19', '12:45', ' ', '2019-06-19 12:45:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'EM'),
(1618, '004', '2019-06-21 19:01:33', '2019-06-19', '11:56', ' ', '2019-06-19 11:56:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1619, '005', '2019-06-19 11:11:04', '2019-06-19', '10:30', ' ', '2019-06-19 10:30:00', 'I', '', '', '', '19.1996648,73.1744934', '', 'NM'),
(1620, '006', '2019-06-19 00:32:01', '2019-06-19', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1621, '008', '2019-06-19 00:32:01', '2019-06-19', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1622, '009', '2019-06-19 19:16:40', '2019-06-19', '12:16', ' ', '2019-06-19 12:16:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1623, '010', '2019-06-19 16:02:05', '2019-06-19', '12:04', ' ', '2019-06-19 12:04:00', 'I', '', '', '', '', '', 'NM'),
(1624, '011', '2019-06-19 12:24:07', '2019-06-19', '12:02', ' ', '2019-06-19 12:02:00', 'I', '', '', '', '19.1996621,73.1744912', '', 'NM'),
(1625, '012', '2019-06-19 00:32:01', '2019-06-19', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1626, '025', '2019-06-19 00:32:01', '2019-06-19', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1627, '030', '2019-06-19 00:32:01', '2019-06-19', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1628, '003', '2019-06-19 14:40:11', '2019-06-18', ' ', '19:00', '2019-06-18 19:00:00', 'O', '510', '510', '0', '', '19.1996636,73.1744647', ''),
(1629, '010', '2019-06-19 16:01:00', '2019-06-17', ' ', '21:00', '2019-06-17 21:00:00', 'O', '540', '537', '-3', '', '', ''),
(1630, '010', '2019-06-19 16:01:46', '2019-06-18', ' ', '21:03', '2019-06-18 21:03:00', 'O', '540', '536', '-4', '', '', ''),
(1631, '003', '2019-06-19 16:57:55', '2019-06-15', ' ', '19:05', '2019-06-15 19:05:00', 'O', '510', '500', '-10', '', '19.1996731,73.1744925', ''),
(1632, '009', '2019-06-19 19:22:33', '2019-06-17', ' ', '20:42', '2019-06-17 20:42:00', 'O', '510', '202', '-308', '', '19.1996991,73.17473', ''),
(1633, '005', '2019-06-19 19:23:40', '2019-06-19', ' ', '19:12', '2019-06-19 19:12:00', 'O', '510', '522', '12', '', '19.1993324,73.1681117', ''),
(1634, '003', '2019-06-19 19:55:26', '2019-06-19', ' ', '19:45', '2019-06-19 19:45:00', 'O', '510', '420', '-90', '', '19.20068,73.1768917', ''),
(1635, '002', '2019-06-19 20:05:05', '2019-06-19', ' ', '20:05', '2019-06-19 20:05:00', 'O', '510', '452', '-58', '', '19.1997352,73.1746876', ''),
(1636, '011', '2019-06-19 21:03:21', '2019-06-19', ' ', '21:02', '2019-06-19 21:02:00', 'O', '540', '540', '0', '', '19.1998555,73.1747266', ''),
(1637, '001', '2019-06-21 18:33:01', '2019-06-20', '12:01', ' ', '2019-06-20 12:01:00', 'I', '', '', '', '19.1996616,73.1744832', '', 'NM'),
(1638, '002', '2019-06-20 12:15:54', '2019-06-20', '12:03', ' ', '2019-06-20 12:03:00', 'I', '', '', '', '19.1996716,73.1744951', '', 'NM'),
(1639, '003', '2019-06-20 19:39:47', '2019-06-20', '10:42', ' ', '2019-06-20 10:42:00', 'I', '', '', '', '19.2005758,73.17867', '', 'NM'),
(1640, '004', '2019-06-21 19:03:06', '2019-06-20', '11:38', ' ', '2019-06-20 11:38:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1641, '005', '2019-06-20 10:49:15', '2019-06-20', '10:38', ' ', '2019-06-20 10:38:00', 'I', '', '', '', '19.1996723,73.1744871', '', 'NM'),
(1642, '006', '2019-06-20 00:32:01', '2019-06-20', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1643, '008', '2019-06-20 00:32:01', '2019-06-20', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1644, '009', '2019-06-20 20:48:49', '2019-06-20', '12:30', ' ', '2019-06-20 12:30:00', 'I', '', '', '', '19.2230467,73.1604888', '', 'NM'),
(1645, '010', '2019-06-20 19:56:28', '2019-06-20', '12:04', ' ', '2019-06-20 12:04:00', 'I', '', '', '', '', '', 'NM'),
(1646, '011', '2019-06-24 19:05:32', '2019-06-20', '12:00', ' ', '2019-06-20 12:00:00', 'I', '', '', '', '19.1998594,73.1747081', '', 'NM'),
(1647, '012', '2019-06-20 00:32:01', '2019-06-20', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1648, '025', '2019-06-20 00:32:01', '2019-06-20', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1649, '030', '2019-06-20 00:32:01', '2019-06-20', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1650, '003', '2019-06-20 19:40:37', '2019-06-20', ' ', '19:32', '2019-06-20 19:32:00', 'O', '510', '530', '20', '', '19.2026325,73.1805453', ''),
(1651, '010', '2019-06-20 19:56:03', '2019-06-19', ' ', '21:01', '2019-06-19 21:01:00', 'O', '540', '537', '-3', '', '', ''),
(1652, '005', '2019-06-20 20:03:25', '2019-06-20', ' ', '19:18', '2019-06-20 19:18:00', 'O', '510', '520', '10', '', '19.199331,73.1681083', ''),
(1653, '002', '2019-06-20 20:31:54', '2019-06-20', ' ', '20:31', '2019-06-20 20:31:00', 'O', '510', '508', '-2', '', '19.1997451,73.1746857', ''),
(1654, '002', '2019-06-20 20:31:57', '2019-06-20', ' ', '20:31', '2019-06-20 20:31:00', 'O', '510', '508', '-2', '', '19.1997451,73.1746857', ''),
(1655, '009', '2019-06-20 20:49:03', '2019-06-20', ' ', '20:30', '2019-06-20 20:30:00', 'O', '510', '480', '-30', '', '19.2230401,73.1604762', ''),
(1656, '009', '2019-06-20 20:49:53', '2019-06-19', ' ', '20:45', '2019-06-19 20:45:00', 'O', '510', '509', '-1', '', '19.223023,73.1603991', ''),
(1657, '001', '2019-06-21 18:34:11', '2019-06-21', '11:57', ' ', '2019-06-21 11:57:00', 'I', '', '', '', '19.1996569,73.1744808', '', 'NM'),
(1658, '002', '2019-06-21 21:21:11', '2019-06-21', '21:21', ' ', '2019-06-21 21:21:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'EM'),
(1659, '003', '2019-06-21 11:12:14', '2019-06-21', '10:55', ' ', '2019-06-21 10:55:00', 'I', '', '', '', '19.1996875,73.1745101', '', 'NM'),
(1660, '004', '2019-06-21 19:04:17', '2019-06-21', '11:47', ' ', '2019-06-21 11:47:00', 'I', '', '', '', '19.1996473,73.1744704', '', 'NM'),
(1661, '005', '2019-06-21 11:35:01', '2019-06-21', '10:41', ' ', '2019-06-21 10:41:00', 'I', '', '', '', '19.1997013,73.1745172', '', 'NM'),
(1662, '006', '2019-06-21 00:32:01', '2019-06-21', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1663, '008', '2019-06-21 00:32:01', '2019-06-21', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1664, '009', '2019-06-22 23:46:02', '2019-06-21', '12:52', ' ', '2019-06-21 12:52:00', 'I', '', '', '', '19.2383647,73.1569362', '', 'NM'),
(1665, '010', '2019-06-21 12:18:47', '2019-06-21', '12:05', ' ', '2019-06-21 12:05:00', 'I', '', '', '', '', '', 'NM'),
(1666, '011', '2019-06-21 21:04:23', '2019-06-21', '12:00', ' ', '2019-06-21 12:00:00', 'I', '', '', '', '19.2001708,73.1746786', '', 'NM'),
(1667, '012', '2019-06-21 00:32:01', '2019-06-21', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1668, '025', '2019-06-21 00:32:01', '2019-06-21', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1669, '030', '2019-06-21 00:32:01', '2019-06-21', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1670, '010', '2019-06-21 12:18:06', '2019-06-20', ' ', '21:17', '2019-06-20 21:17:00', 'O', '540', '553', '13', '', '', ''),
(1671, '001', '2019-06-21 18:25:01', '2019-06-11', ' ', '20:28', '2019-06-11 20:28:00', 'O', '510', '524', '14', '', '19.1996541,73.1744804', ''),
(1672, '001', '2019-06-21 18:25:34', '2019-06-12', ' ', '21:14', '2019-06-12 21:14:00', 'O', '510', '554', '44', '', '19.1996552,73.1744808', ''),
(1673, '001', '2019-06-21 18:26:06', '2019-06-13', ' ', '20:43', '2019-06-13 20:43:00', 'O', '510', '558', '48', '', '19.1996515,73.1744758', ''),
(1674, '001', '2019-06-21 18:26:32', '2019-06-14', ' ', '20:03', '2019-06-14 20:03:00', 'O', '510', '483', '-27', '', '19.1996481,73.1744715', ''),
(1675, '001', '2019-06-21 18:27:00', '2019-06-15', ' ', '20:17', '2019-06-15 20:17:00', 'O', '510', '502', '-8', '', '19.1996558,73.1744808', ''),
(1676, '001', '2019-06-21 18:29:24', '2019-06-17', ' ', '18:21', '2019-06-17 18:21:00', 'O', '510', '376', '-134', '', '19.1996554,73.1744798', ''),
(1677, '001', '2019-06-21 18:30:08', '2019-06-18', ' ', '21:27', '2019-06-18 21:27:00', 'O', '510', '568', '58', '', '19.1996566,73.1744977', ''),
(1678, '001', '2019-06-21 18:33:57', '2019-06-20', ' ', '21:04', '2019-06-20 21:04:00', 'O', '510', '543', '33', '', '19.1996534,73.1744762', ''),
(1679, '004', '2019-06-21 18:57:01', '2019-06-11', ' ', '20:49', '2019-06-11 20:49:00', 'O', '540', '534', '-6', '', '19.1996463,73.1744715', ''),
(1680, '004', '2019-06-21 18:57:58', '2019-06-12', ' ', '21:09', '2019-06-12 21:09:00', 'O', '540', '566', '26', '', '19.1996473,73.1744704', ''),
(1681, '004', '2019-06-21 18:59:09', '2019-06-13', ' ', '20:42', '2019-06-13 20:42:00', 'O', '540', '527', '-13', '', '19.1996473,73.1744704', ''),
(1682, '004', '2019-06-21 18:59:47', '2019-06-14', ' ', '20:42', '2019-06-14 20:42:00', 'O', '540', '527', '-13', '', '19.1996473,73.1744704', ''),
(1683, '004', '2019-06-21 19:00:24', '2019-06-17', ' ', '20:38', '2019-06-17 20:38:00', 'O', '540', '540', '0', '', '19.1996473,73.1744704', ''),
(1684, '004', '2019-06-21 19:01:05', '2019-06-18', ' ', '20:35', '2019-06-18 20:35:00', 'O', '540', '564', '24', '', '19.1996473,73.1744704', ''),
(1685, '004', '2019-06-21 19:01:58', '2019-06-19', ' ', '20:46', '2019-06-19 20:46:00', 'O', '540', '530', '-10', '', '19.1996473,73.1744704', ''),
(1686, '004', '2019-06-21 19:03:22', '2019-06-20', ' ', '20:39', '2019-06-20 20:39:00', 'O', '540', '541', '1', '', '19.1996473,73.1744704', ''),
(1687, '004', '2019-06-21 19:09:33', '2019-06-15', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1688, '005', '2019-06-21 19:54:10', '2019-06-21', ' ', '19:25', '2019-06-21 19:25:00', 'O', '510', '524', '14', '', '19.199331,73.1681083', ''),
(1689, '004', '2019-06-21 20:48:37', '2019-06-21', ' ', '20:48', '2019-06-21 20:48:00', 'O', '540', '541', '1', '', '19.1996473,73.1744704', ''),
(1690, '011', '2019-06-21 21:04:40', '2019-06-21', ' ', '21:03', '2019-06-21 21:03:00', 'O', '540', '543', '3', '', '19.2002912,73.1745873', ''),
(1691, '002', '2019-06-21 21:22:07', '2019-06-21', ' ', '21:21', '2019-06-21 21:21:00', 'O', '510', '0', '-510', '', '19.1996885,73.1747369', ''),
(1692, '003', '2019-06-21 22:35:03', '2019-06-21', ' ', '19:22', '2019-06-21 19:22:00', 'O', '510', '507', '-3', '', '19.25461,73.3895768', ''),
(1693, '010', '2019-06-22 12:05:47', '2019-06-21', ' ', '21:02', '2019-06-21 21:02:00', 'O', '540', '537', '-3', '', '', ''),
(1694, '009', '2019-06-22 23:46:13', '2019-06-21', ' ', '21:30', '2019-06-21 21:30:00', 'O', '510', '518', '8', '', '19.2383718,73.156906', ''),
(1695, '011', '2019-06-24 19:06:21', '2019-06-20', ' ', '21:30', '2019-06-20 21:30:00', 'O', '540', '570', '30', '', '19.1996525,73.1745108', ''),
(1696, '001', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1697, '002', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1698, '003', '2019-07-01 12:30:02', '2019-07-01', '-', '07:44 pm', '0000-00-00 00:00:00', 'O', '540', '522', '-18', '', '19.1997184,73.1744754', 'AB'),
(1699, '004', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1700, '005', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1701, '006', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1702, '008', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1703, '009', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1704, '010', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1705, '011', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1706, '012', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1707, '025', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1708, '030', '2019-07-01 12:30:02', '2019-07-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1709, '030', '2019-07-27 18:04:42', '2019-07-27', '18:04', '2:52', '2019-07-27 18:04:00', 'O', '540', '172', '-368', '19.1996805,73.1744094', '19.1996665,73.1743754', 'EM'),
(1710, '030', '2019-07-27 18:14:14', '2019-07-26', '12:00', '20:45', '2019-07-26 12:00:00', 'O', '540', '1245', '705', '19.1996662,73.1743922', '19.1996687,73.1744109', 'NM'),
(1711, '013', '2019-07-29 10:44:50', '2019-07-29', '10:40', '0:28', '2019-07-29 10:40:00', 'O', '540', '28', '-512', '19.1996824,73.1744119', '19.2206444,73.1610952', 'NM'),
(1712, '005', '2019-07-29 11:26:00', '2019-07-29', '10:55', '6:40', '2019-07-29 10:55:00', 'O', '510', '400', '-110', '19.1995698,73.1747485', '19.199545,73.1747533', 'NM'),
(1713, '005', '2019-07-29 12:28:14', '2019-06-22', '10:38', '16:42', '2019-06-22 10:38:00', 'O', '510', '1002', '492', '19.1995517,73.174752', '19.1995476,73.1747529', 'NM'),
(1714, '005', '2019-07-29 13:04:10', '2019-06-29', '10:44', '', '2019-06-29 10:44:00', 'I', '', '', '', '19.1995617,73.1747462', '', 'NM'),
(1715, '005', '2019-07-30 10:42:59', '2019-07-30', '10:33', '', '2019-07-30 10:33:00', 'I', '', '', '', '19.1996665,73.1743754', '', 'NM'),
(1716, '030', '2019-07-31 15:58:52', '2019-07-31', '10:30', '9:30', '2019-07-31 10:30:00', 'O', '540', '570', '30', '19.1996826,73.1744273', '19.1996797,73.17442', 'NM'),
(1717, '013', '2019-07-31 16:04:32', '2019-07-31', '10:30', '9:34', '2019-07-31 10:30:00', 'O', '540', '574', '34', '19.1996891,73.1744188', '19.1996796,73.174432', 'NM'),
(1718, '003', '2019-07-31 17:04:25', '2019-07-31', '10:38', '', '2019-07-31 10:38:00', 'I', '', '', '', '19.1997331,73.1744598', '', 'NM'),
(1719, '013', '2019-08-01 11:55:39', '2019-08-01', '10:30', '9:1', '2019-08-01 10:30:00', 'O', '540', '541', '1', '19.1997354,73.1744669', '19.1998222,73.1747304', 'NM'),
(1720, '001', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1721, '002', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1722, '003', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1723, '004', '2019-08-01 12:30:02', '2019-08-01', '-', '08:44 pm', '0000-00-00 00:00:00', 'O', '540', '584', '44', '', '19.1996918,73.1744423', 'AB'),
(1724, '005', '2019-08-01 12:30:02', '2019-08-01', '-', '07:12 pm', '0000-00-00 00:00:00', 'O', '510', '522', '12', '', '19.199551,73.1747682', 'AB'),
(1725, '006', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1726, '009', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1727, '010', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1728, '011', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1729, '025', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1730, '030', '2019-08-01 12:30:02', '2019-08-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1731, '013', '2019-08-02 11:44:16', '2019-08-02', '10:30', '10:2', '2019-08-02 10:30:00', 'O', '540', '602', '62', '19.1996833,73.1744304', '19.1997014,73.1744091', 'NM'),
(1732, '013', '2019-08-06 11:49:42', '2019-08-06', '10:30', '07:30 pm', '2019-08-06 10:30:00', 'O', '540', '540', '0', '19.1996977,73.1744068', '19.1996858,73.1743782', 'NM'),
(1733, '030', '2019-08-06 12:21:18', '2019-08-06', '10:30', '07:30 pm', '2019-08-06 10:30:00', 'O', '540', '540', '0', '19.1996951,73.1744052', '19.1996858,73.1743783', 'NM'),
(1734, '030', '2019-08-06 17:52:04', '2019-08-05', '10:30', '07:30 am', '2019-08-05 10:30:00', 'O', '540', '180', '-360', '19.1996858,73.1743782', '19.1996859,73.1743785', 'NM'),
(1735, '030', '2019-08-06 17:53:56', '2019-08-03', '10:30', '07:30 pm', '2019-08-03 10:30:00', 'O', '540', '540', '0', '19.1996817,73.1743768', '19.1996915,73.1743936', 'NM'),
(1736, '003', '2019-08-06 18:04:58', '2019-08-06', '10:55', '07:59 pm', '2019-08-06 10:55:00', 'O', '510', '544', '34', '19.1997009,73.1744233', '19.2094706,73.1859633', 'NM'),
(1737, '013', '2019-08-06 18:26:00', '2019-08-03', '10:35', '08:15 pm', '2019-08-03 10:35:00', 'O', '540', '580', '40', '19.1997018,73.1744019', '19.1996936,73.174398', 'NM'),
(1738, '013', '2019-08-06 18:27:15', '2019-08-05', '10:30', '08:25 pm', '2019-08-05 10:30:00', 'O', '540', '595', '55', '19.1996985,73.1744086', '19.1996858,73.1743783', 'NM'),
(1739, '005', '2019-08-07 13:25:41', '2019-08-07', '10:30', '07:24 pm', '2019-08-07 10:30:00', 'O', '510', '534', '24', '19.1996858,73.1743782', '19.1993283,73.1681404', 'NM'),
(1740, '005', '2019-08-07 21:04:25', '2019-08-01', '10:30', '07:12 pm', '2019-08-01 10:30:00', 'O', '510', '522', '12', '19.1993283,73.1681404', '19.199551,73.1747682', 'NM'),
(1741, '005', '2019-08-07 21:41:09', '2019-08-06', '10:59', '07:45 pm', '2019-08-06 10:59:00', 'O', '510', '526', '16', '19.1993283,73.1681404', '19.1993283,73.1681404', 'NM'),
(1742, '005', '2019-08-08 12:10:35', '2019-08-08', '10:47', '07:18 pm', '2019-08-08 10:47:00', 'O', '510', '511', '1', '19.1996896,73.1744222', '19.2006819,73.1737754', 'NM'),
(1743, '005', '2019-08-08 18:33:30', '2019-08-02', '10:45', '07:39 pm', '2019-08-02 10:45:00', 'O', '510', '534', '24', '19.1995479,73.1747729', '19.1995421,73.1747738', 'NM'),
(1744, '005', '2019-08-08 18:34:36', '2019-08-03', '11:02', '07:39 pm', '2019-08-03 11:02:00', 'O', '510', '517', '7', '19.1995448,73.1747721', '19.1995478,73.1747729', 'NM'),
(1745, '005', '2019-08-08 18:57:03', '2019-08-05', '10:41', '07:15 pm', '2019-08-05 10:41:00', 'O', '510', '514', '4', '19.1995526,73.1747588', '19.1995531,73.1747449', 'NM'),
(1746, '013', '2019-08-08 19:09:44', '2019-08-07', '10:45', '08:12 pm', '2019-08-07 10:45:00', 'O', '540', '567', '27', '19.1997062,73.1744236', '19.1997071,73.1744323', 'NM'),
(1747, '013', '2019-08-08 19:13:12', '2019-08-08', '10:30', '08:05 pm', '2019-08-08 10:30:00', 'O', '540', '575', '35', '19.1997225,73.1744503', '19.199727,73.1745333', 'NM'),
(1748, '005', '2019-08-09 12:31:15', '2019-08-09', '10:41', '07:40 pm', '2019-08-09 10:41:00', 'O', '510', '539', '29', '19.1995473,73.1747699', '19.1993342,73.1681015', 'NM'),
(1749, '013', '2019-08-09 18:21:03', '2019-08-09', '10:30', '08:15 pm', '2019-08-09 10:30:00', 'O', '540', '585', '45', '19.1997034,73.17443', '19.1997225,73.174531', 'NM'),
(1750, '005', '2019-08-10 11:43:09', '2019-08-10', '11:05', '07:39 pm', '2019-08-10 11:05:00', 'O', '510', '514', '4', '19.1995419,73.1747538', '19.1993342,73.1681015', 'NM'),
(1751, '005', '2019-08-12 12:12:03', '2019-08-12', '10:38', '08:09 pm', '2019-08-12 10:38:00', 'O', '510', '571', '61', '19.1995471,73.1747531', '19.1995479,73.1747729', 'NM'),
(1752, '013', '2019-08-13 11:24:53', '2019-08-12', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'S'),
(1753, '013', '2019-08-13 11:26:39', '2019-08-10', '10:55', '07:47 pm', '2019-08-10 10:55:00', 'O', '540', '532', '-8', '19.1996187,73.1746032', '19.1996187,73.1746032', 'NM'),
(1754, '013', '2019-08-13 11:28:14', '2019-08-13', '10:30', '08:06 pm', '2019-08-13 10:30:00', 'O', '540', '576', '36', '19.1996187,73.1746032', '19.1997052,73.1744333', 'NM'),
(1755, '005', '2019-08-13 12:45:10', '2019-08-13', '10:30', '07:11 pm', '2019-08-13 10:30:00', 'O', '510', '521', '11', '19.1995744,73.1747593', '19.1996549,73.168068', 'NM'),
(1756, '005', '2019-08-14 12:31:24', '2019-08-14', '10:43', '07:26 pm', '2019-08-14 10:43:00', 'O', '510', '523', '13', '19.199552,73.1747525', '19.2005704,73.1690102', 'NM'),
(1757, '005', '2019-08-16 11:37:20', '2019-08-16', '10:30', '07:19 pm', '2019-08-16 10:30:00', 'O', '510', '529', '19', '19.1996927,73.1744373', '19.1993493,73.1680831', 'NM'),
(1758, '009', '2019-08-16 18:41:54', '2019-06-12', '17:05', '', '2019-06-12 17:05:00', 'I', '', '', '', '19.1995614,73.1747678', '', 'HM'),
(1759, '009', '2019-08-16 18:59:06', '2019-06-22', '12:40', '09:30 pm', '2019-06-22 12:40:00', 'O', '510', '530', '20', '19.1995633,73.1747404', '19.199575,73.1747281', 'NM'),
(1760, '009', '2019-08-16 19:02:08', '2019-06-24', '12:54', '08:48 pm', '2019-06-24 12:54:00', 'O', '510', '474', '-36', '19.1995695,73.1747518', '19.1995763,73.174744', 'NM'),
(1761, '009', '2019-08-16 19:03:10', '2019-06-25', '12:47', '09:20 pm', '2019-06-25 12:47:00', 'O', '510', '513', '3', '19.1995638,73.1747418', '19.1995637,73.1747418', 'NM'),
(1762, '009', '2019-08-16 19:04:24', '2019-06-26', '12:49', '09:08 pm', '2019-06-26 12:49:00', 'O', '510', '499', '-11', '19.1995657,73.1747394', '19.1995649,73.1747536', 'NM'),
(1763, '009', '2019-08-16 19:05:23', '2019-06-27', '23:44', '08:55 pm', '2019-06-27 23:44:00', 'O', '510', '169', '-341', '19.1995632,73.1747422', '19.1995632,73.1747422', 'HM'),
(1764, '009', '2019-08-16 19:06:49', '2019-06-28', '21:15', '09:15 pm', '2019-06-28 21:15:00', 'O', '510', '0', '-510', '19.1995659,73.1747427', '19.1995655,73.1747428', 'HM'),
(1765, '009', '2019-08-16 19:08:38', '2019-06-29', '23:44', '09:30 pm', '2019-06-29 23:44:00', 'O', '510', '134', '-376', '19.1995667,73.1747545', '19.1995646,73.1747536', 'HM'),
(1766, '005', '2019-08-17 11:26:07', '2019-08-17', '11:01', '07:45 pm', '2019-08-17 11:01:00', 'O', '510', '524', '14', '19.1996881,73.1746799', '19.1993493,73.1680831', 'NM'),
(1767, '005', '2019-08-19 10:59:04', '2019-08-19', '10:47', '07:19 pm', '2019-08-19 10:47:00', 'O', '510', '512', '2', '19.1995497,73.1747621', '19.199594,73.1747557', 'NM'),
(1768, '005', '2019-08-20 10:56:30', '2019-08-20', '10:41', '07:28 pm', '2019-08-20 10:41:00', 'O', '510', '527', '17', '19.1995641,73.1747416', '19.2017056,73.1679044', 'NM'),
(1769, '005', '2019-08-21 10:51:34', '2019-08-21', '10:39', '07:32 pm', '2019-08-21 10:39:00', 'O', '510', '533', '23', '19.1984887,73.1676173', '19.1993439,73.1681429', 'NM'),
(1770, '005', '2019-08-22 10:41:13', '2019-08-22', '10:30', '07:42 pm', '2019-08-22 10:30:00', 'O', '510', '552', '42', '19.1997281,73.1744322', '19.1993646,73.1681412', 'NM'),
(1771, '005', '2019-08-23 10:47:39', '2019-08-23', '10:34', '07:21 pm', '2019-08-23 10:34:00', 'O', '510', '527', '17', '19.1995559,73.1747335', '19.199562,73.1747362', 'NM'),
(1772, '005', '2019-08-24 10:37:03', '2019-08-24', '10:34', '07:17 pm', '2019-08-24 10:34:00', 'O', '510', '523', '13', '19.2021717,73.174972', '19.2003539,73.1745408', 'NM'),
(1773, '005', '2019-08-26 10:42:05', '2019-08-26', '10:38', '08:35 pm', '2019-08-26 10:38:00', 'O', '510', '597', '87', '19.1995778,73.1747258', '19.2095155,73.1861893', 'NM'),
(1774, '005', '2019-08-27 10:50:57', '2019-08-27', '10:41', '09:16 pm', '2019-08-27 10:41:00', 'O', '510', '635', '125', '19.1995609,73.1747246', '19.2005879,73.1689614', 'NM'),
(1775, '005', '2019-08-28 20:29:41', '2019-08-28', '10:32', '08:16 pm', '2019-08-28 10:32:00', 'O', '510', '584', '74', '19.1993368,73.1681483', '19.1993368,73.1681483', 'NM'),
(1776, '005', '2019-08-29 19:39:47', '2019-08-29', '10:39', '07:37 pm', '2019-08-29 10:39:00', 'O', '510', '538', '28', '19.1993368,73.1681483', '19.1993368,73.1681483', 'NM'),
(1777, '005', '2019-08-30 12:22:24', '2019-08-30', '10:40', '06:00 pm', '2019-08-30 10:40:00', 'O', '510', '440', '-70', '19.1995128,73.1747232', '19.1993368,73.1681483', 'NM'),
(1778, '005', '2019-08-31 12:17:41', '2019-08-31', '10:43', '06:15 pm', '2019-08-31 10:43:00', 'O', '510', '452', '-58', '19.1995636,73.1747273', '19.2041815,73.1816204', 'NM'),
(1779, '001', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1780, '002', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1781, '003', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1782, '004', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1783, '005', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1784, '006', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1785, '009', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1786, '010', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1787, '011', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1788, '013', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1789, '025', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1790, '030', '2019-09-01 12:30:11', '2019-09-01', '-', '-', '0000-00-00 00:00:00', 'H', '', '', '', '', '', 'SUN'),
(1791, '005', '2019-09-03 11:00:36', '2019-09-03', '10:36', '07:13 pm', '2019-09-03 10:36:00', 'O', '510', '517', '7', '19.1995657,73.1747169', '19.1993368,73.1681483', 'NM'),
(1792, '009', '2019-09-03 12:59:15', '2019-09-03', '12:57', '', '2019-09-03 12:57:00', 'I', '', '', '', '19.1995673,73.1747267', '', 'NM'),
(1793, '005', '2019-09-04 11:09:01', '2019-09-04', '10:45', '07:20 pm', '2019-09-04 10:45:00', 'O', '510', '515', '5', '19.1995796,73.1747191', '19.1992799,73.1680025', 'NM'),
(1794, '005', '2019-09-05 11:12:08', '2019-09-05', '11:01', '07:12 pm', '2019-09-05 11:01:00', 'O', '510', '491', '-19', '19.1995851,73.1747131', '19.1996801,73.1675971', 'NM'),
(1796, '013', '2019-09-07 13:00:30', '2019-09-07', '10:35', '07:10 pm', '2019-09-07 10:35:00', 'O', '540', '515', '-25', '19.1997353,73.1745237', '19.1997622,73.1744891', 'NM'),
(1865, '005', '2019-09-20 11:15:05', '2019-09-06', '10:30', '07:00 pm', '2019-09-06 10:30:00', 'O', '510', '510', '0', '19.1996144,73.1747007', '19.199615,73.1746964', 'NM'),
(1797, '005', '2019-09-09 10:52:32', '2019-09-09', '10:40', '07:22 pm', '2019-09-09 10:40:00', 'O', '510', '522', '12', '19.1995918,73.1747064', '19.2005654,73.1689415', 'NM'),
(1798, '030', '2019-09-09 15:28:26', '2019-08-01', '10:30', '', '2019-08-01 10:30:00', 'I', '', '', '', '19.1997222,73.1745237', '', 'NM'),
(1800, '004', '2019-09-09 16:30:52', '2019-08-01', '11:00', '08:44 pm', '2019-08-01 11:00:00', 'O', '540', '584', '44', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1801, '004', '2019-09-09 16:32:51', '2019-08-02', '12:02', '08:39 pm', '2019-08-02 12:02:00', 'O', '540', '517', '-23', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1802, '004', '2019-09-09 16:33:53', '2019-08-03', '11:40', '08:36 pm', '2019-08-03 11:40:00', 'O', '540', '536', '-4', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1803, '004', '2019-09-09 16:35:05', '2019-08-05', '11:47', '08:40 pm', '2019-08-05 11:47:00', 'O', '540', '533', '-7', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1804, '004', '2019-09-09 16:36:14', '2019-08-06', '11:30', '08:45 pm', '2019-08-06 11:30:00', 'O', '540', '555', '15', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1805, '004', '2019-09-09 16:38:31', '2019-08-07', '11:10', '08:15 pm', '2019-08-07 11:10:00', 'O', '540', '545', '5', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1806, '004', '2019-09-09 16:39:30', '2019-08-08', '14:10', '08:41 pm', '2019-08-08 14:10:00', 'O', '540', '391', '-149', '19.1996918,73.1744423', '19.1996918,73.1744423', 'EM');
INSERT INTO `j_atendance` (`id`, `emp_id`, `c_date`, `login_date`, `login_time`, `logout_time`, `login_date_time`, `tag`, `total_minut`, `work_time`, `bal_minut`, `location_in`, `location_out`, `status`) VALUES
(1807, '004', '2019-09-09 16:40:01', '2019-08-09', '11:45', '09:19 pm', '2019-08-09 11:45:00', 'O', '540', '574', '34', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1808, '004', '2019-09-09 16:43:04', '2019-08-10', '12:04', '09:00 pm', '2019-08-10 12:04:00', 'O', '540', '536', '-4', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1809, '004', '2019-09-09 16:45:37', '2019-08-12', '13:30', '09:00 pm', '2019-08-12 13:30:00', 'O', '540', '450', '-90', '19.1996918,73.1744423', '19.1996918,73.1744423', 'EM'),
(1814, '004', '2019-09-09 17:44:42', '2019-08-14', '11:53', '08:39 pm', '2019-08-14 11:53:00', 'O', '540', '526', '-14', '19.1997079,73.1744883', '19.1996918,73.1744423', 'NM'),
(1813, '004', '2019-09-09 17:42:31', '2019-08-13', '12:05', '08:43 pm', '2019-08-13 12:05:00', 'O', '540', '518', '-22', '19.1997573,73.1745347', '19.1997402,73.1745191', 'NM'),
(1812, '004', '2019-09-09 17:11:32', '2019-08-16', '11:24', '09:30 pm', '2019-08-16 11:24:00', 'O', '540', '606', '66', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1815, '004', '2019-09-09 17:50:55', '2019-08-17', '11:00', '08:10 pm', '2019-08-17 11:00:00', 'O', '540', '550', '10', '19.1997146,73.1744879', '19.1997564,73.1745323', 'NM'),
(1816, '004', '2019-09-09 17:53:29', '2019-08-19', '11:58', '08:35 pm', '2019-08-19 11:58:00', 'O', '540', '517', '-23', '19.199761,73.1745561', '19.199761,73.1745561', 'NM'),
(1817, '004', '2019-09-09 17:55:18', '2019-08-20', '11:36', '08:15 pm', '2019-08-20 11:36:00', 'O', '540', '519', '-21', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1818, '004', '2019-09-09 17:56:02', '2019-08-21', '11:59', '08:39 pm', '2019-08-21 11:59:00', 'O', '540', '520', '-20', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1819, '004', '2019-09-09 17:56:54', '2019-08-22', '11:30', '07:27 pm', '2019-08-22 11:30:00', 'O', '540', '477', '-63', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1820, '004', '2019-09-09 17:58:19', '2019-08-26', '11:25', '08:25 pm', '2019-08-26 11:25:00', 'O', '540', '540', '0', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1821, '004', '2019-09-09 17:59:12', '2019-08-27', '11:25', '08:25 pm', '2019-08-27 11:25:00', 'O', '540', '540', '0', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1822, '004', '2019-09-09 18:02:36', '2019-08-28', '11:53', '08:40 pm', '2019-08-28 11:53:00', 'O', '540', '527', '-13', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1823, '004', '2019-09-09 18:03:26', '2019-08-29', '11:53', '08:22 pm', '2019-08-29 11:53:00', 'O', '540', '509', '-31', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1824, '004', '2019-09-09 18:04:19', '2019-08-31', '11:00', '08:31 pm', '2019-08-31 11:00:00', 'O', '540', '571', '31', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1825, '004', '2019-09-09 18:05:59', '2019-08-30', '11:47', '08:26 pm', '2019-08-30 11:47:00', 'O', '540', '519', '-21', '19.1996918,73.1744423', '19.1996918,73.1744423', 'NM'),
(1826, '005', '2019-09-10 18:57:55', '2019-09-10', '10:38', '07:22 pm', '2019-09-10 10:38:00', 'O', '510', '524', '14', '19.1995959,73.1747074', '19.1992979,73.1680014', 'NM'),
(1827, '005', '2019-09-11 17:32:45', '2019-09-11', '10:40', '07:41 pm', '2019-09-11 10:40:00', 'O', '510', '541', '31', '19.1995634,73.1746915', '19.1993064,73.1680342', 'NM'),
(1828, '030', '2019-09-12 12:55:25', '2019-09-12', '10:45', '', '2019-09-12 10:45:00', 'I', '', '', '', '19.19975,73.1744962', '', 'NM'),
(1829, '013', '2019-09-12 12:56:03', '2019-09-12', '10:45', '08:35 pm', '2019-09-12 10:45:00', 'O', '540', '590', '50', '19.1997453,73.1744967', '19.2092923,73.1856651', 'NM'),
(1830, '013', '2019-09-12 13:00:29', '2019-09-04', '12:19', '08:04 pm', '2019-09-04 12:19:00', 'O', '540', '465', '-75', '19.1997663,73.1744981', '19.199763,73.1744975', 'EM'),
(1831, '013', '2019-09-12 13:02:02', '2019-09-05', '10:30', '08:07 pm', '2019-09-05 10:30:00', 'O', '540', '577', '37', '19.1997622,73.1744891', '19.1997622,73.1744891', 'NM'),
(1832, '013', '2019-09-12 13:04:15', '2019-09-06', '10:30', '07:53 pm', '2019-09-06 10:30:00', 'O', '540', '563', '23', '19.1997732,73.1745182', '19.1997623,73.1744893', 'NM'),
(1833, '013', '2019-09-12 13:06:16', '2019-09-09', '10:55', '08:15 pm', '2019-09-09 10:55:00', 'O', '540', '560', '20', '19.1997803,73.1745509', '19.1997668,73.1745032', 'NM'),
(1834, '013', '2019-09-12 13:07:21', '2019-09-10', '10:30', '07:45 pm', '2019-09-10 10:30:00', 'O', '540', '555', '15', '19.1997762,73.1745199', '19.1997647,73.174508', 'NM'),
(1835, '013', '2019-09-12 13:10:24', '2019-09-11', '10:45', '08:38 pm', '2019-09-11 10:45:00', 'O', '540', '593', '53', '19.1997622,73.1744891', '19.199798,73.1745766', 'NM'),
(1836, '003', '2019-09-12 21:06:47', '2019-09-04', '11:35', '08:02 pm', '2019-09-04 11:35:00', 'O', '510', '507', '-3', '19.2204572,73.1929307', '19.2048124,73.1728987', 'NM'),
(1837, '005', '2019-09-13 11:03:39', '2019-09-13', '10:31', '07:21 pm', '2019-09-13 10:31:00', 'O', '510', '530', '20', '19.1995709,73.1746955', '19.1993064,73.1680342', 'NM'),
(1838, '003', '2019-09-13 11:52:30', '2019-09-13', '11:00', '08:05 pm', '2019-09-13 11:00:00', 'O', '510', '545', '35', '19.2009539,73.173497', '19.2004535,73.1744009', 'NM'),
(1839, '013', '2019-09-13 12:26:20', '2019-09-13', '10:30', '08:05 pm', '2019-09-13 10:30:00', 'O', '540', '575', '35', '19.199765,73.1745078', '19.1998171,73.1746327', 'NM'),
(1840, '013', '2019-09-14 10:46:18', '2019-09-14', '10:40', '08:30 pm', '2019-09-14 10:40:00', 'O', '540', '590', '50', '19.1997652,73.1745049', '19.2000326,73.1746459', 'NM'),
(1841, '005', '2019-09-14 10:48:20', '2019-09-14', '10:41', '07:21 pm', '2019-09-14 10:41:00', 'O', '510', '520', '10', '19.1995634,73.1746915', '19.1993064,73.1680342', 'NM'),
(1842, '005', '2019-09-16 11:00:57', '2019-09-16', '10:48', '07:39 pm', '2019-09-16 10:48:00', 'O', '510', '531', '21', '19.1994198,73.1748883', '19.2004952,73.168869', 'NM'),
(1843, '013', '2019-09-16 11:27:56', '2019-09-16', '11:00', '08:04 pm', '2019-09-16 11:00:00', 'O', '540', '544', '4', '19.1997635,73.1745019', '19.2095188,73.1858252', 'NM'),
(1844, '005', '2019-09-17 11:17:48', '2019-09-17', '10:36', '07:22 pm', '2019-09-17 10:36:00', 'O', '510', '526', '16', '19.1996076,73.174707', '', 'NM'),
(1847, '013', '2019-09-18 11:11:07', '2019-09-17', '10:40', '08:55 pm', '2019-09-17 10:40:00', 'O', '540', '615', '75', '19.1997333,73.1745357', '19.1997347,73.1745362', 'NM'),
(1846, '005', '2019-09-18 10:57:05', '2019-09-18', '10:53', '07:21 pm', '2019-09-18 10:53:00', 'O', '510', '508', '-2', '19.1996777,73.1746742', '19.1992866,73.16801', 'NM'),
(1848, '013', '2019-09-18 11:38:23', '2019-09-18', '11:00', '08:59 pm', '2019-09-18 11:00:00', 'O', '540', '599', '59', '19.1997367,73.1745244', '19.2357153,73.129931', 'NM'),
(1849, '003', '2019-09-18 21:58:46', '2019-09-05', '13:30', '08:07 pm', '2019-09-05 13:30:00', 'O', '510', '397', '-113', '19.2387298,73.1359649', '19.2389516,73.1364247', 'EM'),
(1850, '003', '2019-09-18 22:00:04', '2019-09-06', '11:00', '08:00 pm', '2019-09-06 11:00:00', 'O', '510', '540', '30', '19.2395358,73.1387733', '19.2395484,73.1388727', 'NM'),
(1851, '003', '2019-09-18 22:01:24', '2019-09-07', '10:50', '07:10 pm', '2019-09-07 10:50:00', 'O', '510', '500', '-10', '19.2402396,73.1431282', '19.2404877,73.1437207', 'NM'),
(1852, '003', '2019-09-18 22:02:33', '2019-09-10', '11:33', '08:21 pm', '2019-09-10 11:33:00', 'O', '510', '528', '18', '19.2413292,73.1468758', '19.2415577,73.1478154', 'NM'),
(1853, '003', '2019-09-18 22:03:41', '2019-09-11', '11:05', '08:40 pm', '2019-09-11 11:05:00', 'O', '510', '575', '65', '19.2426736,73.1497784', '19.247892,73.179096', 'NM'),
(1854, '003', '2019-09-18 22:15:11', '2019-09-12', '11:35', '08:34 pm', '2019-09-12 11:35:00', 'O', '510', '539', '29', '19.2482459,73.1810452', '19.2484459,73.1820605', 'NM'),
(1855, '003', '2019-09-19 10:44:06', '2019-09-14', '11:05', '07:55 pm', '2019-09-14 11:05:00', 'O', '510', '530', '20', '19.2386712,73.1542665', '19.2384799,73.1542211', 'NM'),
(1856, '003', '2019-09-19 10:45:55', '2019-09-16', '10:55', '08:14 pm', '2019-09-16 10:55:00', 'O', '510', '559', '49', '19.2348062,73.1540231', '19.2345498,73.1540774', 'NM'),
(1857, '003', '2019-09-19 10:47:54', '2019-09-17', '11:05', '08:55 pm', '2019-09-17 11:05:00', 'O', '510', '590', '80', '19.2319456,73.156774', '19.2317097,73.1572208', 'NM'),
(1860, '013', '2019-09-19 11:38:08', '2019-09-19', '10:30', '08:00 pm', '2019-09-19 10:30:00', 'O', '540', '570', '30', '19.1997367,73.1745244', '19.19976,73.1745642', 'NM'),
(1859, '003', '2019-09-19 11:36:03', '2019-09-19', '11:05', '08:28 pm', '2019-09-19 11:05:00', 'O', '510', '563', '53', '19.1997232,73.1744962', '19.1997452,73.1745276', 'NM'),
(1861, '003', '2019-09-19 11:38:44', '2019-09-18', '11:52', '08:59 pm', '2019-09-18 11:52:00', 'O', '510', '547', '37', '19.1997367,73.1745246', '19.1997356,73.1745332', 'NM'),
(1864, '005', '2019-09-20 11:08:57', '2019-09-19', '10:38', '08:10 pm', '2019-09-19 10:38:00', 'O', '510', '572', '62', '19.1997362,73.1745323', '19.1997357,73.1745373', 'NM'),
(1863, '005', '2019-09-20 10:52:13', '2019-09-20', '10:36', '07:18 pm', '2019-09-20 10:36:00', 'O', '510', '522', '12', '19.2018179,73.1675698', '19.1992866,73.16801', 'NM'),
(1866, '013', '2019-09-20 11:33:52', '2019-09-20', '10:45', '08:00 pm', '2019-09-20 10:45:00', 'O', '540', '555', '15', '19.1997367,73.1745244', '19.1997367,73.1745244', 'NM'),
(1867, '003', '2019-09-20 11:59:08', '2019-09-20', '11:00', '08:00 pm', '2019-09-20 11:00:00', 'O', '510', '540', '30', '19.1997366,73.1745419', '19.1997367,73.1745244', 'NM'),
(1868, '003', '2019-09-20 12:04:14', '2019-08-31', '10:49', '07:34 pm', '2019-08-31 10:49:00', 'O', '510', '525', '15', '19.1997593,73.1745567', '19.1997465,73.1745537', 'NM'),
(1869, '003', '2019-09-20 12:36:42', '2019-08-29', '12:00', '07:56 pm', '2019-08-29 12:00:00', 'O', '510', '476', '-34', '19.1997554,73.1745487', '19.1997367,73.1745244', 'NM'),
(1870, '003', '2019-09-20 12:38:08', '2019-08-28', '11:35', '07:56 pm', '2019-08-28 11:35:00', 'O', '510', '501', '-9', '19.1997369,73.1745247', '19.1997977,73.1746324', 'NM'),
(1871, '013', '2019-09-21 11:00:32', '2019-09-21', '10:55', '08:00 pm', '2019-09-21 10:55:00', 'O', '540', '545', '5', '19.1997344,73.1745358', '19.1997313,73.1745243', 'NM'),
(1872, '005', '2019-09-21 11:05:31', '2019-09-21', '10:43', '07:23 pm', '2019-09-21 10:43:00', 'O', '510', '520', '10', '19.1995938,73.1747051', '', 'NM'),
(1873, '003', '2019-09-21 23:20:24', '2019-09-21', '11:00', '08:10 pm', '2019-09-21 11:00:00', 'O', '510', '550', '40', '19.2547427,73.3894321', '19.2546444,73.389354', 'NM'),
(1874, '013', '2019-09-23 11:00:52', '2019-09-23', '11:00', '08:19 pm', '2019-09-23 11:00:00', 'O', '540', '559', '19', '19.1997118,73.1745072', '19.2001582,73.1782528', 'NM'),
(1875, '005', '2019-09-24 17:03:54', '2019-09-24', '10:30', '08:45 pm', '2019-09-24 10:30:00', 'O', '510', '615', '105', '19.1997343,73.1747485', '19.2017489,73.1678356', 'NM'),
(1876, '003', '2019-09-24 17:19:52', '2019-09-23', '11:02', '08:19 pm', '2019-09-23 11:02:00', 'O', '510', '557', '47', '19.1997193,73.1744799', '19.1997178,73.1744799', 'NM'),
(1877, '013', '2019-09-24 20:20:23', '2019-09-24', '10:30', '08:00 pm', '2019-09-24 10:30:00', 'O', '540', '570', '30', '19.2095392,73.1857302', '19.2095862,73.1857649', 'NM'),
(1878, '013', '2019-09-25 12:26:32', '2019-09-25', '10:30', '08:00 pm', '2019-09-25 10:30:00', 'O', '540', '570', '30', '19.1997158,73.1744559', '19.199716,73.1744603', 'NM'),
(1879, '003', '2019-09-25 15:12:21', '2019-09-24', '11:00', '08:02 pm', '2019-09-24 11:00:00', 'O', '510', '542', '32', '19.1997161,73.1744602', '19.1997184,73.1744627', 'NM'),
(1880, '003', '2019-09-25 16:22:53', '2019-06-17', '10:30', '07:24 pm', '2019-06-17 10:30:00', 'O', '510', '534', '24', '19.1997148,73.1744572', '19.1997173,73.174468', 'NM'),
(1881, '003', '2019-09-25 16:36:15', '2019-06-24', '10:55', '07:56 pm', '2019-06-24 10:55:00', 'O', '510', '541', '31', '19.199716,73.1744603', '19.1997167,73.1744616', 'NM'),
(1886, '003', '2019-09-25 16:54:56', '2019-06-25', '11:22', '08:36 pm', '2019-06-25 11:22:00', 'O', '510', '554', '44', '19.199713,73.1744634', '19.1997132,73.1744631', 'NM'),
(1883, '003', '2019-09-25 16:44:35', '2019-06-26', '10:47', '07:15 pm', '2019-06-26 10:47:00', 'O', '510', '508', '-2', '19.1997173,73.1744682', '19.1997164,73.1744621', 'NM'),
(1884, '003', '2019-09-25 16:45:28', '2019-06-27', '10:45', '07:15 pm', '2019-06-27 10:45:00', 'O', '510', '510', '0', '19.1997171,73.1744687', '19.1997169,73.174468', 'NM'),
(1885, '003', '2019-09-25 16:46:29', '2019-06-29', '10:55', '07:37 pm', '2019-06-29 10:55:00', 'O', '510', '522', '12', '19.199716,73.1744604', '19.1997159,73.1744605', 'NM'),
(1887, '005', '2019-09-25 19:35:51', '2019-09-25', '10:30', '07:25 pm', '2019-09-25 10:30:00', 'O', '510', '535', '25', '19.1992663,73.1681119', '19.1992663,73.1681119', 'NM'),
(1888, '013', '2019-09-26 19:35:50', '2019-09-26', '11:00', '08:00 pm', '2019-09-26 11:00:00', 'O', '540', '540', '0', '19.1997174,73.1744616', '19.2145187,73.1750443', 'NM'),
(1889, '005', '2019-09-26 22:03:58', '2019-09-26', '10:30', '08:40 pm', '2019-09-26 10:30:00', 'O', '510', '610', '100', '19.1992663,73.1681119', '19.1992657,73.1681123', 'NM'),
(1890, '005', '2019-09-27 10:29:10', '2019-09-27', '10:30', '06:35 pm', '2019-09-27 10:30:00', 'O', '510', '485', '-25', '19.2005656,73.1709218', '19.2004617,73.1744666', 'NM'),
(1891, '013', '2019-09-27 20:23:08', '2019-09-27', '11:00', '08:00 pm', '2019-09-27 11:00:00', 'O', '540', '540', '0', '19.199715,73.1744497', '19.1997145,73.174446', 'NM'),
(1892, '003', '2019-09-28 12:40:08', '2019-09-28', '11:05', '08:18 pm', '2019-09-28 11:05:00', 'O', '540', '553', '13', '19.1996648,73.1744908', '19.1997438,73.1745079', 'NM'),
(1893, '003', '2019-09-28 12:41:05', '2019-09-25', '10:45', '05:17 pm', '2019-09-25 10:45:00', 'O', '510', '392', '-118', '19.1997185,73.1744739', '19.1997173,73.1744651', 'NM'),
(1895, '003', '2019-09-28 12:52:23', '2019-09-27', '11:05', '08:25 pm', '2019-09-27 11:05:00', 'O', '540', '560', '20', '19.1997174,73.1744661', '19.1997188,73.1744664', 'NM'),
(1896, '013', '2019-09-28 15:56:54', '2019-09-28', '10:38', '08:19 pm', '2019-09-28 10:38:00', 'O', '540', '581', '41', '19.1997016,73.1744652', '19.2008215,73.175225', 'NM'),
(1897, '005', '2019-09-28 16:06:12', '2019-09-28', '10:32', '07:35 pm', '2019-09-28 10:32:00', 'O', '510', '543', '33', '19.1995785,73.174703', '19.1992663,73.1681119', 'NM'),
(1898, '003', '2019-09-28 17:33:56', '2019-07-01', '11:02', '07:44 pm', '2019-07-01 11:02:00', 'O', '540', '522', '-18', '19.1997174,73.17447', '19.1997184,73.1744754', 'NM'),
(1899, '003', '2019-09-28 17:34:46', '2019-07-02', '10:51', '07:54 pm', '2019-07-02 10:51:00', 'O', '540', '543', '3', '19.1997199,73.1744736', '19.1997171,73.1744643', 'NM'),
(1900, '003', '2019-09-28 17:35:43', '2019-07-03', '10:52', '07:05 pm', '2019-07-03 10:52:00', 'O', '540', '493', '-47', '19.1997183,73.1744663', '19.1997166,73.1744556', 'NM'),
(1901, '003', '2019-09-28 17:38:12', '2019-07-05', '10:30', '07:30 pm', '2019-07-05 10:30:00', 'O', '540', '540', '0', '19.1997186,73.1744713', '19.1997171,73.1744713', 'NM'),
(1902, '003', '2019-09-28 17:42:14', '2019-07-08', '11:05', '07:51 pm', '2019-07-08 11:05:00', 'O', '540', '526', '-14', '19.1997182,73.1744742', '19.1997183,73.1744778', 'NM'),
(1903, '003', '2019-09-28 17:42:50', '2019-07-09', '10:44', '08:21 pm', '2019-07-09 10:44:00', 'O', '540', '577', '37', '19.1997124,73.1744847', '19.1997183,73.1744785', 'NM'),
(1904, '003', '2019-09-28 17:43:32', '2019-07-10', '10:56', '08:09 pm', '2019-07-10 10:56:00', 'O', '540', '553', '13', '19.19972,73.1744957', '19.1997185,73.1744828', 'NM'),
(1905, '005', '2019-09-30 11:36:30', '2019-09-30', '10:36', '07:07 pm', '2019-09-30 10:36:00', 'O', '510', '511', '1', '19.2169992,73.1673843', '19.2005426,73.1689852', 'NM'),
(1906, '003', '2019-09-30 20:02:03', '2019-09-30', '11:03', '', '2019-09-30 11:03:00', 'I', '', '', '', '19.1997291,73.174477', '', 'NM'),
(1907, '013', '2019-09-30 20:21:08', '2019-09-30', '10:50', '08:05 pm', '2019-09-30 10:50:00', 'O', '540', '555', '15', '19.2008341,73.1751815', '19.2007774,73.1751899', 'NM'),
(1908, '001', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1909, '002', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1910, '003', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1911, '004', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1912, '005', '2019-10-01 12:30:03', '2019-10-01', '-', '07:15 pm', '0000-00-00 00:00:00', 'O', '510', '521', '11', '', '19.1992797,73.1680943', 'AB'),
(1913, '006', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1914, '009', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1915, '010', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1916, '011', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1917, '013', '2019-10-01 12:30:03', '2019-10-01', '-', '06:33 pm', '0000-00-00 00:00:00', 'O', '540', '478', '-62', '', '19.1997798,73.1745043', 'AB'),
(1918, '025', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1919, '030', '2019-10-01 12:30:03', '2019-10-01', '-', '-', '0000-00-00 00:00:00', 'A', '', '', '', '', '', 'AB'),
(1920, '013', '2019-10-01 18:08:12', '2019-10-01', '10:35', '06:33 pm', '2019-10-01 10:35:00', 'O', '540', '478', '-62', '19.1997119,73.1744851', '19.1997798,73.1745043', 'NM'),
(1921, '005', '2019-10-01 21:49:47', '2019-10-01', '10:34', '07:15 pm', '2019-10-01 10:34:00', 'O', '510', '521', '11', '19.1992797,73.1680943', '19.1992797,73.1680943', 'NM'),
(1922, '013', '2019-10-02 10:38:54', '2019-10-02', '10:30', '', '2019-10-02 10:30:00', 'I', '', '', '', '19.1996686,73.174502', '', 'NM'),
(1923, '003', '2019-10-02 12:01:23', '2019-10-02', '11:05', '', '2019-10-02 11:05:00', 'I', '', '', '', '19.1997504,73.1744917', '', 'NM');

-- --------------------------------------------------------

--
-- Table structure for table `j_designation`
--

CREATE TABLE `j_designation` (
  `id` int(11) NOT NULL,
  `designation` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_designation`
--

INSERT INTO `j_designation` (`id`, `designation`) VALUES
(1, 'Software Developer'),
(2, 'Software Suppoter');

-- --------------------------------------------------------

--
-- Table structure for table `j_emp`
--

CREATE TABLE `j_emp` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `mobile_no` varchar(12) NOT NULL,
  `time_slot` varchar(100) NOT NULL,
  `daily_w_minut` varchar(50) NOT NULL,
  `normal_mark` varchar(100) NOT NULL,
  `late_mark` varchar(100) NOT NULL,
  `no_late_mk` int(11) NOT NULL,
  `emrgency` varchar(100) NOT NULL,
  `paid_leave` int(11) NOT NULL,
  `casual_leave` int(11) NOT NULL,
  `sick_leave` int(11) NOT NULL,
  `salary` double NOT NULL,
  `image` text NOT NULL,
  `extra_leave` int(11) NOT NULL,
  `designation` varchar(250) NOT NULL,
  `status` varchar(100) NOT NULL,
  `imei_no` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_emp`
--

INSERT INTO `j_emp` (`id`, `emp_id`, `first_name`, `last_name`, `address`, `mobile_no`, `time_slot`, `daily_w_minut`, `normal_mark`, `late_mark`, `no_late_mk`, `emrgency`, `paid_leave`, `casual_leave`, `sick_leave`, `salary`, `image`, `extra_leave`, `designation`, `status`, `imei_no`) VALUES
(39, '003', 'KAMLESH', 'BAIRAGI', '    MURBAD', '9890700809', '10:30,19:30', '540', '10:30,11:5', '11:6,11:35', 3, '2', 1, 6, 5, 19000, 'http://mezyapps.com/attendance/images/Kamlesh.jpg', 0, '1', 'active', ''),
(37, '001', 'PANKAJ', 'KHANDAGLE', 'MURBAD', '7744026625', '11:30,20:00', '510', '11:30,12:05', '12:06,12:35', 3, '2', 1, 6, 5, 20000, 'http://mezyapps.com/attendance/images/Hydrangeas.jpg', 0, '1', 'active', ''),
(38, '002', 'SHAILENDRA', 'SHARMA', ' AMBERNATH', '9987015721', '11:30,20:00', '510', '11:30,12:05', '12:06,12:35', 3, '2', 1, 6, 5, 20000, 'http://mezyapps.com/attendance/images/Hydrangeas.jpg', 0, '1', 'active', ''),
(40, '004', 'Tarun', 'Chainani', ' ULHASNAGAR - 2', '9561481827', '11:30,20:30', '540', '11:30,12:05', '12:06,12:35', 3, '2', 1, 6, 5, 10000, 'http://mezyapps.com/attendance/images/Lighthouse.jpg', 0, '1', 'active', ''),
(41, '005', 'Rajesh', 'Shetty', ' ULHASNAGAR - 5', '7798182213', '10:30,19:00', '510', '10:30,11:05', '11:06,11:35', 3, '2', 1, 5, 5, 19000, 'http://mezyapps.com/attendance/images/ad8ad9e9-458c-4cdf-8018-bb67047ff16a.jpg', 0, '1', 'active', ''),
(42, '006', 'SANAM', 'SYED', ' ULHASNAGAR - 5', '9146555346', '11:00,20:00', '540', '11:00,11:35', '11:36,12:05', 3, '2', 1, 6, 5, 8000, 'http://mezyapps.com/attendance/images/Lighthouse.jpg', 0, '2', 'deactive', ''),
(47, '009', 'Dipin', 'Gwalani', 'unr - 1', '9011120399', '12:30,21:00', '510', '12:30,13:05', '13:06,13:35', 3, '2', 1, 6, 5, 9000, 'http://mezyapps.com/attendance/images/Desert.jpg', 0, '1', 'active', ''),
(48, '010', 'Vinay', 'Gaur', '  Unr - 5', '9049249443', '12:00,21:00', '540', '12:00,12:35', '12:36,13:05', 3, '2', 1, 6, 5, 7000, 'http://mezyapps.com/attendance/images/Chrysanthemum.jpg', 0, '1', 'active', ''),
(49, '011', 'Mohit', 'Sharma', 'unr - 5', '8605381800', '11:30,20:30', '540', '11:30,12:05', '12:06,12:35', 3, '2', 0, 0, 0, 10000, 'http://mezyapps.com/attendance/images/Lighthouse.jpg', 0, '1', 'active', ''),
(56, '013', 'Nehal ', 'Jathar', ' Kalyan', '9503873045', '10:30,19:30', '540', '10:30,11:05', '11:06,11:35', 3, '2', 0, 0, 0, 10000, 'http://mezyapps.com/attendance/images/1531803686754.jpg', 0, '1', 'active', ''),
(53, '025', 'NARESH', 'GWALANI', 'UNR-5', '9890322940', '11:00,20:00', '540', '11:00,11:35', '11:36,12:05', 3, '2', 1, 6, 5, 100000, 'http://mezyapps.com/attendance/images/app_icon.png', 0, '1', 'active', ''),
(54, '030', 'DEMO', 'TEST', 'TEST', '0123456789', '11:30,20:30', '540', '11:30,12:05', '12:06,12:35', 3, '2', 1, 6, 5, 10000, 'http://mezyapps.com/attendance/images/app_icon.png', 0, '1', 'active', '');

-- --------------------------------------------------------

--
-- Table structure for table `j_extra_and_less_minut`
--

CREATE TABLE `j_extra_and_less_minut` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `c_date` date NOT NULL,
  `extra_less_work_date` date NOT NULL,
  `from_time` time NOT NULL,
  `to_time` time NOT NULL,
  `add_minut` varchar(50) NOT NULL,
  `less_minut` varchar(50) NOT NULL,
  `remarks` text NOT NULL,
  `tag` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_extra_and_less_minut`
--

INSERT INTO `j_extra_and_less_minut` (`id`, `emp_id`, `c_date`, `extra_less_work_date`, `from_time`, `to_time`, `add_minut`, `less_minut`, `remarks`, `tag`) VALUES
(14, '009', '2019-05-22', '2019-05-14', '19:30:00', '20:00:00', '0', '30', '-', 'L'),
(13, '003', '2019-05-22', '2019-05-05', '09:30:00', '10:00:00', '30', '0', 'SvS Enterprises', 'A'),
(12, '003', '2019-05-22', '2019-05-01', '09:15:00', '09:45:00', '30', '0', 'support for vertex sale and satish Khemani', 'A'),
(8, '009', '2019-05-22', '2019-05-07', '18:10:00', '19:30:00', '0', '80', '-', 'L'),
(9, '009', '2019-05-22', '2019-05-07', '13:30:00', '14:00:00', '0', '30', '-', 'L'),
(10, '009', '2019-05-22', '2019-05-12', '18:00:00', '19:15:00', '75', '0', 'Collected Amc from Manish Trader', 'A'),
(15, '009', '2019-05-26', '2019-05-23', '21:30:00', '21:59:00', '29', '0', '-', 'A'),
(16, '009', '2019-05-26', '2019-05-25', '21:30:00', '22:07:00', '37', '0', 'goen for demo', 'A'),
(17, '009', '2019-05-26', '2019-05-26', '15:11:00', '16:51:00', '100', '0', '-', 'A'),
(18, '005', '2019-05-26', '2019-05-26', '11:59:00', '12:25:00', '26', '0', 'extra support', 'A'),
(19, '005', '2019-05-26', '2019-05-19', '18:30:00', '19:20:00', '50', '0', 'extra support', 'A'),
(20, '005', '2019-05-26', '2019-05-12', '13:00:00', '13:40:00', '40', '0', 'extra support', 'A'),
(31, '001', '2019-05-28', '2019-05-03', '21:30:00', '22:15:00', '45', '0', 'extra work', 'A'),
(32, '009', '2019-05-29', '2019-05-27', '22:30:00', '22:48:00', '18', '0', 'logout from axis bank', 'A'),
(23, '005', '2019-05-27', '2019-05-08', '10:03:00', '10:30:00', '27', '0', 'extra minute', 'A'),
(24, '005', '2019-05-27', '2019-05-09', '09:35:00', '10:30:00', '55', '0', 'extra minute going to mumbai', 'A'),
(25, '005', '2019-05-27', '2019-05-17', '09:59:00', '10:30:00', '31', '0', 'extra minute', 'A'),
(26, '002', '2019-05-27', '2019-05-09', '21:30:00', '22:00:00', '30', '0', '30 min extra work from office', 'A'),
(27, '002', '2019-05-27', '2019-05-22', '11:50:00', '15:30:00', '220', '0', 'work from home', 'A'),
(28, '002', '2019-05-27', '2019-05-27', '21:30:00', '21:55:00', '25', '0', 'Demo for Topandas Ahuja', 'A'),
(30, '008', '2019-05-28', '2019-05-23', '21:30:00', '21:35:00', '5', '0', 'after 9:30 not allowed for logout', 'A'),
(33, '009', '2019-05-29', '2019-05-27', '22:00:00', '22:15:00', '0', '15', '-', 'L'),
(34, '009', '2019-05-29', '2019-05-27', '21:30:00', '22:30:00', '60', '0', '-', 'A'),
(35, '009', '2019-05-29', '2019-05-27', '23:00:00', '23:25:00', '25', '0', 'paent given to tarun', 'A'),
(36, '009', '2019-05-29', '2019-05-28', '07:25:00', '10:30:00', '185', '0', '-', 'A'),
(37, '009', '2019-05-29', '2019-05-28', '21:30:00', '22:56:00', '86', '0', '-', 'A'),
(38, '005', '2019-05-29', '2019-05-29', '10:19:00', '10:30:00', '11', '0', 'login from amb', 'A'),
(39, '001', '2019-05-30', '2019-05-29', '21:30:00', '22:15:00', '45', '0', 'karjat', 'A'),
(40, '005', '2019-05-30', '2019-05-30', '10:05:00', '10:30:00', '25', '0', 'login from amb', 'A'),
(41, '005', '2019-05-31', '2019-05-31', '10:15:00', '10:30:00', '15', '0', 'login from Jammudevi', 'A'),
(42, '009', '2019-05-31', '2019-05-31', '15:50:00', '16:05:00', '0', '15', '-', 'L'),
(43, '005', '2019-06-02', '2019-06-02', '11:55:00', '12:34:00', '39', '0', 'for Jammudevi collection', 'A'),
(44, '005', '2019-06-02', '2019-06-02', '14:30:00', '15:00:00', '30', '0', 'Mahalaxmi trader taro', 'A'),
(45, '005', '2019-06-02', '2019-06-02', '10:55:00', '12:34:00', '99', '0', 'extra work for jammudevi collection', 'A'),
(46, '005', '2019-06-02', '2019-06-02', '14:30:00', '15:00:00', '30', '0', 'Mahalaxmi traders', 'A'),
(47, '009', '2019-06-03', '2019-06-02', '15:00:00', '17:00:00', '120', '0', '-', 'A'),
(48, '004', '2019-06-03', '2019-05-26', '16:00:00', '16:20:00', '20', '0', 'support given', 'A'),
(49, '001', '2019-06-03', '2019-06-02', '20:45:00', '21:35:00', '50', '0', 'bhushan', 'A'),
(50, '004', '2019-06-03', '2019-05-27', '20:46:00', '20:48:00', '2', '0', 'support', 'A'),
(53, '005', '2019-06-06', '2019-06-02', '12:00:00', '13:08:00', '0', '68', 'less from 169-68', 'L'),
(52, '005', '2019-06-04', '2019-06-04', '09:59:00', '10:30:00', '31', '0', 'login from amb going to Santacruz', 'A'),
(54, '002', '2019-06-09', '2019-06-09', '13:00:00', '13:40:00', '40', '0', 'Support to Parmeshwar Garment and Laxmi Packaging', 'A'),
(55, '009', '2019-06-09', '2019-06-09', '15:50:00', '18:00:00', '130', '0', 'for rr kids and brozil', 'A'),
(58, '001', '2019-06-11', '2019-06-09', '19:15:00', '21:42:00', '147', '0', 'new kolkata installation', 'A'),
(57, '001', '2019-06-10', '2019-06-08', '09:00:00', '09:30:00', '30', '0', 'sweta', 'A'),
(59, '001', '2019-06-11', '2019-06-10', '20:18:00', '21:30:00', '72', '0', 'for ds kalyan amc collection and some points', 'A'),
(60, '001', '2019-06-15', '2019-06-15', '22:35:00', '23:13:00', '38', '0', 'sonu electrical', 'A'),
(61, '009', '2019-06-17', '2019-06-15', '21:30:00', '22:15:00', '45', '0', '-', 'A'),
(62, '009', '2019-06-17', '2019-06-16', '20:20:00', '21:35:00', '75', '0', '-', 'A'),
(63, '003', '2019-06-17', '2019-06-17', '09:45:00', '10:30:00', '45', '0', 'DMT Agency', 'A'),
(64, '005', '2019-06-17', '2019-06-16', '12:05:00', '12:35:00', '30', '0', 'Laxmi garment', 'A'),
(65, '011', '2019-06-18', '2019-06-18', '13:29:00', '21:01:00', '452', '0', 'minutes', 'A'),
(66, '005', '2019-06-18', '2019-06-18', '10:04:00', '10:30:00', '26', '0', 'Santacruz goregaon', 'A'),
(67, '003', '2019-06-19', '2019-06-18', '10:00:00', '10:30:00', '30', '0', 'going to santacruze', 'A'),
(68, '009', '2019-06-19', '2019-06-18', '19:00:00', '20:30:00', '90', '0', 'jai bhole', 'A'),
(69, '003', '2019-06-21', '2019-06-18', '10:04:00', '10:30:00', '26', '0', 'going to santacruze', 'A'),
(70, '001', '2019-06-21', '2019-06-15', '22:35:00', '23:13:00', '38', '0', 'sonu', 'A'),
(71, '001', '2019-06-21', '2019-06-16', '14:00:00', '14:50:00', '50', '0', 'jbd', 'A'),
(72, '001', '2019-06-21', '2019-06-16', '15:55:00', '17:17:00', '82', '0', 'manish trader', 'A'),
(73, '009', '2019-06-22', '2019-06-21', '21:30:00', '22:45:00', '75', '0', '-', 'A'),
(74, '003', '2019-06-23', '2019-06-22', '15:00:00', '15:30:00', '30', '0', 'Malad Agency Pawan Mehta', 'A'),
(75, '003', '2019-06-23', '2019-06-22', '21:00:00', '21:15:00', '15', '0', 'Shiv Ganesh Confectionery', 'A'),
(76, '011', '2019-06-24', '2019-06-24', '16:40:00', '18:20:00', '0', '100', 'personal use', 'L'),
(77, '003', '2019-06-25', '2019-06-24', '19:56:00', '20:26:00', '30', '0', 'sir discussion', 'A'),
(78, '030', '2019-07-19', '2019-07-19', '19:00:00', '21:06:00', '0', '126', 'add', 'A'),
(79, '013', '2019-08-01', '2019-08-01', '10:10:00', '10:30:00', '20', '0', 'extra work in morning', 'A'),
(80, '013', '2019-08-06', '2019-08-06', '10:10:00', '10:30:00', '20', '0', 'Extra Time For Biz Protect', 'A'),
(81, '013', '2019-08-06', '2019-08-02', '10:10:00', '10:30:00', '20', '0', 'Extra Time', 'A'),
(82, '030', '2019-08-06', '2019-08-06', '10:00:00', '10:30:00', '30', '0', 'extra minutes', 'A'),
(83, '005', '2019-08-08', '2019-08-04', '13:00:00', '14:30:00', '90', '0', 'daksh creation', 'A'),
(84, '005', '2019-08-09', '2019-08-09', '16:48:00', '17:40:00', '0', '52', 'personal use', 'L'),
(85, '005', '2019-08-13', '2019-08-13', '10:10:00', '10:30:00', '20', '0', 'login from amb', 'A'),
(86, '005', '2019-08-13', '2019-08-12', '14:30:00', '15:45:00', '0', '75', 'personal use', 'L'),
(87, '009', '2019-08-16', '2019-06-10', '18:39:00', '18:49:00', '0', '10', '/', 'L'),
(88, '009', '2019-08-16', '2019-06-12', '17:05:00', '22:03:00', '298', '0', '-', 'A'),
(89, '009', '2019-08-16', '2019-06-17', '17:20:00', '20:42:00', '202', '0', '-', 'A'),
(90, '009', '2019-08-16', '2019-06-19', '18:55:00', '19:05:00', '0', '10', '-', 'L'),
(91, '009', '2019-08-16', '2019-06-22', '21:30:00', '22:32:00', '62', '0', '-', 'A'),
(92, '009', '2019-08-16', '2019-08-23', '18:00:00', '21:30:00', '210', '0', '-', 'A'),
(93, '009', '2019-08-16', '2019-08-16', '21:30:00', '22:00:00', '30', '0', '-', 'A'),
(94, '005', '2019-08-19', '2019-08-18', '15:03:00', '15:33:00', '30', '0', 'nilesh gms', 'A'),
(95, '005', '2019-08-22', '2019-08-22', '10:26:00', '10:30:00', '4', '0', 'login early', 'A'),
(96, '005', '2019-08-24', '2019-08-24', '18:00:00', '18:30:00', '0', '30', 'personla use', 'L'),
(97, '005', '2019-08-24', '2019-08-24', '20:45:00', '21:00:00', '15', '0', 'annu gms support', 'A'),
(98, '005', '2019-09-06', '2019-09-06', '11:05:00', '11:20:00', '0', '15', 'late remark 1', 'L'),
(99, '005', '2019-09-09', '2019-09-08', '18:00:00', '18:30:00', '30', '0', 'for annu gms', 'A'),
(100, '005', '2019-09-09', '2019-09-08', '13:30:00', '14:30:00', '60', '0', 'for rv jeans', 'A'),
(101, '013', '2019-09-12', '2019-09-05', '09:49:00', '10:30:00', '41', '0', 'Extra Work', 'A'),
(102, '013', '2019-09-12', '2019-09-10', '10:00:00', '10:30:00', '30', '0', 'extra work', 'A'),
(103, '005', '2019-09-12', '2019-09-12', '13:30:00', '15:30:00', '120', '0', 'support to mmm gms', 'A'),
(104, '005', '2019-09-20', '2019-09-06', '16:27:00', '19:00:00', '0', '153', 'half day on ganesh festival', 'L'),
(105, '013', '2019-09-24', '2019-09-24', '10:15:00', '10:30:00', '15', '0', 'Extra Work', 'A'),
(106, '005', '2019-09-24', '2019-09-24', '10:30:00', '11:21:00', '0', '51', 'late remark 2', 'L'),
(107, '003', '2019-09-25', '2019-06-17', '09:45:00', '10:30:00', '45', '0', 'DMt Agency updating', 'A'),
(108, '003', '2019-09-25', '2019-06-23', '14:34:00', '15:04:00', '30', '0', 'Shiv Gensh Agency Vittalwadi', 'A'),
(109, '005', '2019-09-25', '2019-09-25', '10:10:00', '10:30:00', '20', '0', 'login from amb', 'A'),
(110, '005', '2019-09-26', '2019-09-26', '10:25:00', '10:30:00', '5', '0', 'early login', 'A'),
(111, '005', '2019-09-27', '2019-09-27', '10:28:00', '10:30:00', '2', '0', 'early login going to sagar bags', 'A'),
(112, '003', '2019-09-28', '2019-07-07', '11:00:00', '11:45:00', '45', '0', 'Mukesh Foam Vishal Agency  DMT agency', 'A'),
(113, '005', '2019-09-30', '2019-09-29', '10:20:00', '10:45:00', '25', '0', 'sagar bags', 'A'),
(114, '005', '2019-09-30', '2019-09-29', '18:15:00', '18:30:00', '15', '0', 'guru kripa cretion', 'A'),
(115, '005', '2019-09-30', '2019-09-29', '20:10:00', '20:30:00', '20', '0', 'daksh creation', 'A'),
(116, '005', '2019-10-01', '2019-10-01', '21:00:00', '21:15:00', '15', '0', 'sagar bags', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `j_feedback`
--

CREATE TABLE `j_feedback` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(15) NOT NULL,
  `c_date` date NOT NULL,
  `companyname` varchar(250) NOT NULL,
  `rating` int(11) NOT NULL,
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_feedback`
--

INSERT INTO `j_feedback` (`id`, `emp_id`, `c_date`, `companyname`, `rating`, `message`) VALUES
(1, '008', '2019-06-01', 'test', 5, 'tetsin'),
(2, '008', '2019-06-01', 'j_leave', 7, 'tetstin'),
(3, '008', '2019-06-01', 'bni_give_ask', 8, 'asa'),
(4, '008', '2019-06-01', 'j_leave', 8, 'test'),
(5, '008', '2019-06-01', 'bni_give_ask', 6, 'aa'),
(6, '004', '2019-06-01', 'jmd-infotech', 10, 'testing'),
(7, '010', '2019-06-01', 'tetsv', 7, 'asfdg'),
(8, '010', '2019-06-01', 'ew', 9, 'waes');

-- --------------------------------------------------------

--
-- Table structure for table `j_holiday`
--

CREATE TABLE `j_holiday` (
  `id` int(11) NOT NULL,
  `h_date` date NOT NULL,
  `h_reason` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_holiday`
--

INSERT INTO `j_holiday` (`id`, `h_date`, `h_reason`) VALUES
(8, '2020-01-01', 'NEW YEAR'),
(14, '2020-01-26', 'REPUBLIC DAY'),
(11, '2019-08-15', 'INDEPENDENCE DAY');

-- --------------------------------------------------------

--
-- Table structure for table `j_leave`
--

CREATE TABLE `j_leave` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `c_date` datetime NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `leave_days` varchar(5) NOT NULL,
  `leave_type` varchar(200) NOT NULL,
  `remarks` varchar(250) NOT NULL,
  `dr_prescription` text NOT NULL,
  `leave_status` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_leave`
--

INSERT INTO `j_leave` (`id`, `emp_id`, `c_date`, `from_date`, `to_date`, `leave_days`, `leave_type`, `remarks`, `dr_prescription`, `leave_status`) VALUES
(94, '001', '2019-05-28 20:55:19', '2019-05-18', '2019-05-18', '1', 'S', 'a', '/uploads/201905282055191018547577.jpg', 'approve'),
(90, '005', '2019-05-28 18:20:30', '2019-05-27', '2019-05-27', '1', 'P', 'paid leave', '', 'approve'),
(89, '008', '2019-05-28 18:07:01', '2019-05-13', '2019-05-13', '1', 'S', 'sick leave for Dr follow up', '/uploads/201905281807011790045042.jpg', 'approve'),
(88, '008', '2019-05-28 18:04:25', '2019-05-07', '2019-05-08', '2', 'S', 'sick leave for face paralysis', '/uploads/201905281804251938741961.jpg', 'approve'),
(93, '011', '2019-05-28 18:30:52', '2019-05-01', '2019-05-10', '10', 'E', 'Exams', '', 'approve'),
(95, '001', '2019-05-28 20:57:26', '2019-05-22', '2019-05-22', '1', 'S', 'a', '/uploads/20190528205726452231803.jpg', 'approve'),
(96, '001', '2019-05-28 20:59:17', '2019-05-24', '2019-05-24', '1', 'P', 's', '', 'approve'),
(97, '002', '2019-05-29 12:14:00', '2019-05-07', '2019-05-07', '1', 'P', '-', '', 'approve'),
(98, '002', '2019-05-29 12:15:33', '2019-05-08', '2019-05-08', '1', 'C', '-', '', 'approve'),
(99, '002', '2019-05-29 12:16:43', '2019-05-20', '2019-05-22', '3', 'C', '-', '', 'approve'),
(100, '012', '2019-05-29 13:48:37', '2019-05-14', '2019-05-17', '4', 'E', 'Sick Leave', '', 'approve'),
(101, '012', '2019-05-29 13:50:09', '2019-05-27', '2019-05-29', '3', 'E', '-', '', 'approve'),
(102, '003', '2019-05-30 19:00:23', '2019-05-08', '2019-05-08', '1', 'S', 'food poisoning', '/uploads/201905301900231416574038.jpg', 'approve'),
(103, '005', '2019-06-07 17:18:15', '2019-06-10', '2019-06-10', '1', 'P', 'on leave', '', 'approve'),
(104, '002', '2019-06-09 01:44:17', '2019-06-11', '2019-06-12', '2', 'C', 'Going to Ratlam', '', 'approve'),
(105, '003', '2019-06-14 20:20:27', '2019-06-17', '2019-06-17', '1', 'C', 'personal work', '', 'approve'),
(106, '004', '2019-06-21 19:09:33', '2019-06-15', '2019-06-15', '1', 'S', 'Diaherrea', '/uploads/20190621190933901632300.jpg', 'approve'),
(107, '013', '2019-08-13 11:24:53', '2019-08-12', '2019-08-12', '1', 'S', 'Sick leave', '/uploads/20190813112453173755630.jpg', 'approve');

-- --------------------------------------------------------

--
-- Table structure for table `j_penalty`
--

CREATE TABLE `j_penalty` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `penalty_date` date NOT NULL,
  `penalty_amt` varchar(100) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `j_penalty`
--

INSERT INTO `j_penalty` (`id`, `emp_id`, `penalty_date`, `penalty_amt`, `remarks`) VALUES
(2, '030', '2019-03-10', '500', 'test'),
(3, '030', '2019-07-19', '600', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `query_answer`
--

CREATE TABLE `query_answer` (
  `id` int(11) NOT NULL,
  `que_id` int(11) NOT NULL,
  `step` int(11) NOT NULL,
  `answer` text NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `query_answer`
--

INSERT INTO `query_answer` (`id`, `que_id`, `step`, `answer`, `image`) VALUES
(50, 3137, 1, 'SQL INSTALLATION:\r\n search for PRE REQUEST in pc/laptop, it will be in jmd infotech folder. In that folder you will find sql (size 261 mb),right click that sql & run as administration > mostly you have to do just next, but at some point you have to select client components, mixed mode (password sa123) >next ..next... & sql will be installed.\r\n', ''),
(51, 3137, 2, 'CRREDIS:\r\n just double click & it will be installed.\r\n', ''),
(52, 3137, 3, '\r\nREPORT VIEWER:\r\n(double click) next ..next & finish.\r\n', ''),
(53, 3137, 4, '9.0(CRYSTAL REPORT):\r\n(double click) >set up>next>tick(I acceptâ€¦)>copy seriel key from 9.0 and paste it to product key code>nextâ€¦next>tick(I alreadyâ€¦) copy registration code from  9.0 & paste it to registration no. â€¦..finsh it will be registered.\r\n', ''),
(153, 3898, 1, 'OPEN SQL, THEN OPEN EMPTY DATA QUERY, SELECT DATABASE NAME (EG MASTER), WRITE USE & DATABASE NAME (EG: use KENAN_GMS) & THEN EXCUTE QUERY, IT WILL BE WRITTEN AS QUERY COMPLETED  SUCCESFULLY.', ''),
(62, 8453, 1, '1 you must require pin code no and city name on costumers account\r\n2 transport gst no  is most important and create new file on desk top\r\n3 then come to google chrome and open the gst online website\r\n4 then click the e way bill and generate bulk\r\n5 then choose file then upload  then generate file and \r\n6 then you get the e way bill no then copy e way no and pest in bill \r\ndone \r\nnote: enter the company address pin code, city name and account limitin series .	\r\n', ''),
(61, 3885, 1, 'sql has stopped! search sql configuration open it>go to sql service> right click to automatic & start both', 'http://mezyapps.com/query/admin/uploads/20190516151824364462190.jpg'),
(57, 9723, 4, ' SETTING IN CLIENT PC: turn off windows firewall & in anti virus too share the drives and give security> go to network and search for main pc search where the software is! \r\n', ''),
(58, 9723, 5, 'NOTE: INSTALL CRREDISTS & REPORT VIEWER. \r\n', ''),
(59, 7950, 1, ' when printer is not set \r\n', 'http://mezyapps.com/query/admin/uploads/20190516133034702815707.jpg'),
(54, 9723, 1, 'a)SETTING IN MAIN PC :\r\nGO TO SQL CONFUGRATION MANAGER>PROTOCAL>ENABLE ALL PROTOCALS>RESTART BOTH SQL SERVER.\r\n', ''),
(55, 9723, 2, 'WE HAVE TO GIVE RIGHTS & SHARE THAT DRIVE:- RIGHT CLICK THT DRIVE >PROPERTIES>SHARING> ADVANCE SHARING>TICK ON SHARE THIS FOLDER>GO TO PERMISSIONS>ALLOW FULL CONTROL(TICK ALL PERMISSIONS) THEN OK & CANCEL.\r\n', ''),
(56, 9723, 3, 'turn windows firewall off & from anti virues too.\r\n', ''),
(173, 6456, 0, 'This happens cos there is no format in report folder or it might be renamed. so just add that format or rename it.', 'http://mezyapps.com/query/admin/uploads/20190520141920523710961.jpg'),
(90, 6777, 1, 'vdjhm', ''),
(89, 6777, 2, 'zzdfg', ''),
(172, 851, 1, 'get a query > open sql > write database name> execute it, it will done successfully /query completed with errors.', ''),
(169, 3687, 1, 'TAKE LATEST BACKUP', ''),
(170, 3687, 2, 'GO TO SQL>  RIGHT CLICK TO DATABASE > RESTORE DATABASE', ''),
(171, 3687, 3, 'WRITE DATABASE NAME EG: IF  SOFTWARE IS OF GARMENTS SO KENAN_GMS_PX >SOURCE OF BACKUP (TICK FROM DEVICE) & SELECT BACKUP FROM DEVICE>TICK THE BOX ', ''),
(168, 4797, 2, ' GO TO CONTROL PANEL CLICK ON THE TURNS WINDOWS FEATURE ON OR OFF THEN EXPAND THE MICROSOFTNETFRAME.WORK  THEN  DO TICK ON THE BOTH THE COLUMNS  THEN CLICK OK  THEN INSTALL THE SQL.', ''),
(167, 4797, 1, ' GO TO COMPUTER  RIGHT CLICK ON IT THEN  GO TO MANAGE  THEN CLICK ON SERVICES THEN SERVICES AND APPLICATIONS THEN FIND THE WINDOWS UPDATE FROM THE LIST THEN ENABLE THE WINDOWS UPDATE AND MAKE IT AUTOMATIC.\r\n', ''),
(176, 2660, 1, 'go to sql open it>there will server name copy it. ', 'http://mezyapps.com/query/admin/uploads/201905201513141120493398.jpg'),
(177, 2660, 2, 'right click to software open files location> database> info> open it >compinfo> server exe  folder path (paste the path )  ctrl+s it will be saved, and software will run properly..', ''),
(178, 6315, 1, 'MASTER->OTHER   ->SERIES MASTER\r\nPRESS ENTER\r\nTHEN SELECT DEFAULT Y SERIES THEN CHANGE TO DATE\r\nTHEN SAVE ', 'http://mezyapps.com/query/admin/uploads/201905230755131579046685.jpg'),
(185, 7229, 1, '183      1000        63   REMARKS _COLUMN_DISPLAY_SETTING          Y          Y  1', ''),
(180, 5605, 1, 'OPEN SERIES MASTER \r\nTHEN SELECT SERIES \r\nPRESS ALT+ CTRL + SHIFT +I', ''),
(181, 6555, 1, 'MY COMPUTER -RIGHT CLICK\r\n-->MANAGE-->DISK MANAGEMENT\r\nSELECT YOUR CURRENT LOCATION-> RIGHT CLICK-->CHNGE DRIVE LETTER AND PATH--> CHANGE DRIVE\r\nEX :YOUR LAST LOCATION WAS IN F:DRIVE BUT NOW ITS SHOWING GDRIVE:\r\nSO PLZ CHANGE DRIVE G TO F\r\n ', ''),
(182, 2127, 1, 'MAKE A ONE LINE IN SQL MANAGEMENT\r\n524      29         61      BILL_CASH_AND_CHEQUE _AMT_DISPLAY _SETTING     Y       Y     1', ''),
(183, 2766, 1, '1) PUT\r\n@@@@NO_CHECK@@@@ \r\nIN NARRATION\r\n2)OPEN VOUCHER THEN DELETE', ''),
(184, 9837, 1, 'EX:CHANGE 5% TO  0.1% GST\r\nPUT 0.1%GST  IN NARRATION', ''),
(186, 8269, 1, '534         1000      251        SERIES_WISE_PRODUCTION_STOCK_HELP_SETTING       Y          Y                1', ''),
(187, 9392, 1, 'THIS ISSUE OF ANTI  VIRUS\r\nSO RIGHT CLICK ON YOUR ANTI  VIRUS--->CLICK ON PROTECTION--->APPLICATION  AND CONTROL---->ENABLE APPLICATION &CONTROL\r\nTHEN APPLY AND CLOSE', ''),
(195, 2890, 2, 'INSERT THT OBJECT TO ANOTHER PC/LAPTOP TO WHICH YOU WANT TO TRANSFER THE SOFTWARE &  YOU SHOULD INSTALL THE NECESSARY FILES LIKE SQL, CRR, REPORT VIEWER & CRYSTAL REPORT.\r\nAND ATTACH THE DATABASE TO SQL ,RESTART SQL CONFURGATION, CHANGE THE PATH IN INFO FILE THATS IT :)', ''),
(194, 2890, 1, 'FIRST YOU HAVE TO DEATTACH THE DATABASE  FROM SQL THEN COPY IT IN ANY OBJECT LIKE HARD DISK OR PENDRIVE.', ''),
(190, 3125, 1, 'SOLUTION:\r\nSQL SERVER MANAGEMENT ---->TABLE--->VCH SETT--->OPEN TABLE--->STOCK CHECKING=11', ''),
(209, 3150, 0, 'THIS ERROR OCCURS BECAUSE THE ENTRY YOU ARE TRYING TO MODIFY IS ALREADY USED IN SOME ENTRY, YOU CAN CREATE NEW MASTER INSTEAD OF MODIFYING THAT NAME :)', 'http://mezyapps.com/query/admin/uploads/20190524072235346823418.jpg'),
(200, 7108, 1, 'GO TO SQL CONFIGURATION', 'http://mezyapps.com/query/admin/uploads/201905240758171401787577.jpg'),
(201, 7108, 2, 'CLICK TO SQL SERVER 2005 SERVICES> RIGHT CLICK TO (RUNNING ) & RESTART. \r\nDO THE SAME WITH BOTH.', 'http://mezyapps.com/query/admin/uploads/20190524075817697142647.jpg'),
(202, 8314, 0, 'this error occur when there is same name accounts exist. you have modiy/rename one account & error will be solved.', 'http://mezyapps.com/query/admin/uploads/20190524085102462056761.jpg'),
(203, 8015, 1, 'INSTALL THE REPORT VIEWER AND CRREDIST.', ''),
(204, 4977, 1, 'OPEN SQL MANAGEMENT STUDIO ', ''),
(205, 4977, 2, 'SELECT THE DATABASE YOU WANT TO DEATTACH (RIGHT CLICK >TASK>DEATTACH >OK)', ''),
(206, 5134, 1, 'GO TO SQL RIGHT CLICK ON DATABASE THEN  CLICK ON ATTACH THEN CLICK ON ADD THEN GO TO LOCATION OF DATABASE.', ''),
(208, 3962, 0, '1) restart sql \r\n   or \r\nrestore latest backupp', 'http://mezyapps.com/query/admin/uploads/201905291258281357458943.jpg'),
(210, 3150, 2, 'ANOTHER REASON IS UH R TRYING TO OPEN SOFTWARE IN CLIENT & IN MAIN PC PATH IS NOT THERE.', ''),
(211, 2544, 0, 'search SERVICES in START >> WINDOWS UPDATE(right click)>> turn DISABLE to MANUAL>> APPLY... ', ''),
(212, 9022, 0, 'INSTALL ALL BARCODE FONTS', 'http://mezyapps.com/query/admin/uploads/20190927080649126810676.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `query_question`
--

CREATE TABLE `query_question` (
  `id` int(11) NOT NULL,
  `que_id` int(11) NOT NULL,
  `question` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `query_question`
--

INSERT INTO `query_question` (`id`, `que_id`, `question`) VALUES
(1, 3885, 'network related instance specific error?\r\n\r\n\r\n'),
(2, 8453, ' how to generate e way bill'),
(3, 9723, 'MULTI USERâ€™S STEPS?'),
(4, 7950, ' default printer issue ?'),
(5, 3137, 'FILES SHOULD BE INSTALLED TO RUN KENAN SOFTWARE?'),
(6, 3898, ' HOW TO EMPTY DATA FROM SOFTWARE? '),
(22, 3687, 'HOW TO RESTORE DATABASE ?'),
(23, 851, 'how to solve suspected database?'),
(21, 4797, 'WHILE INSTALLING THE SQL IF IT ASK FOR NET.FRAMEWORK VERSION 2.0 OR 3.0 ?'),
(24, 6456, 'PREVIEW IS NOT SHOWING load report failed? '),
(27, 2660, 'server path issue? '),
(28, 6315, 'MIN AND MAX DATE ISSUE'),
(35, 7229, 'REMARKS COLUMN  DISPLAY SETTING IN SALE '),
(30, 5605, 'COMPANY DELETION SETTING IN SERIES MASTER'),
(31, 6555, 'DRIVE LOCATION ISSUE'),
(32, 2127, 'CASH N CHEQUE  AMOUNT COLUMN DISPLAY IN SALES READYMADE :-'),
(33, 2766, 'FOR  SYNTAX ERROR IN GMS AND TXT'),
(34, 9837, 'FOR ITEMWISE GST CHANGE SETTING'),
(36, 8269, 'SERIES WISE  PRODUCTION STOCK DISPLAY SETTING'),
(37, 9392, 'PROVIDER LOAD REPORT FAILD'),
(44, 7108, 'HOW TO RESTART SQL ? '),
(45, 8314, 'subquery returned more than 1 value error!'),
(43, 2890, 'HOW TO TRANSFER SOFTWARE FROM ONE PC TO ANOTHER WHICH IS ON SERVER? '),
(40, 3125, 'YOU DO NOT HAVE A SUFFICIENT STOCK TO CONTINUE AVI QTY IS :165ENTER QTY IS 223'),
(46, 8015, 'IF SOME REPORT IS NOT GENERATING WHILE CLICKING ON THE PREVIEW ?'),
(42, 3150, 'OBJECT REFERENCE NOT SET TO AN INSTANCE OF AN OBJECT! '),
(47, 4977, 'HOW TO DEATTECH DATABASE?'),
(48, 5134, 'HOW TO ATTACH DATABASE  ?'),
(49, 3962, 'OPERATING SYSTEM RETURNED  ERROR! '),
(50, 2544, 'WINDOWS 3.5 NET FRAMEWORK IS NOT INSTALLIN.'),
(51, 9022, 'BARCODE FONT IS NOT COMING ');

-- --------------------------------------------------------

--
-- Table structure for table `query_que_ans`
--

CREATE TABLE `query_que_ans` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `query_user`
--

CREATE TABLE `query_user` (
  `user_id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `userpassword` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `name`, `mobile`, `password`) VALUES
(1, 'TEST', '8423073490', '12345'),
(2, 'ESRAFIL ANSARI', '8707598547', '12345'),
(3, 'TEST', '1234567890', '1234567890');

-- --------------------------------------------------------

--
-- Structure for view `date_wise_emp_details`
--
DROP TABLE IF EXISTS `date_wise_emp_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mezyapp`@`localhost` SQL SECURITY DEFINER VIEW `date_wise_emp_details`  AS  select `j_atendance`.`emp_id` AS `emp_id`,`j_atendance`.`login_date` AS `login_date`,max(`j_atendance`.`login_time`) AS `login`,max(`j_atendance`.`logout_time`) AS `logout`,max(`j_atendance`.`total_minut`) AS `day_min`,max(`j_atendance`.`work_time`) AS `work_min`,max(`j_atendance`.`location_in`) AS `location_in`,max(`j_atendance`.`location_out`) AS `location_out`,max(`j_atendance`.`status`) AS `status`,0 AS `add_min`,0 AS `less_min` from `j_atendance` group by `j_atendance`.`emp_id`,`j_atendance`.`login_date` union all select `j_extra_and_less_minut`.`emp_id` AS `emp_id`,`j_extra_and_less_minut`.`extra_less_work_date` AS `login_date`,0 AS `login`,0 AS `logout`,0 AS `day_min`,0 AS `work_min`,0 AS `location_in`,0 AS `location_out`,'' AS `status`,sum(`j_extra_and_less_minut`.`add_minut`) AS `add_min`,sum(`j_extra_and_less_minut`.`less_minut`) AS `less_min` from `j_extra_and_less_minut` group by `j_extra_and_less_minut`.`emp_id`,`j_extra_and_less_minut`.`extra_less_work_date` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ast_data`
--
ALTER TABLE `ast_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ast_user`
--
ALTER TABLE `ast_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atask`
--
ALTER TABLE `atask`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bni_chapter`
--
ALTER TABLE `bni_chapter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bni_give_ask`
--
ALTER TABLE `bni_give_ask`
  ADD PRIMARY KEY (`g_a_id`);

--
-- Indexes for table `bni_like_detail`
--
ALTER TABLE `bni_like_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bni_user`
--
ALTER TABLE `bni_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `enquiry_user`
--
ALTER TABLE `enquiry_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_admin_user`
--
ALTER TABLE `j_admin_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_atendance`
--
ALTER TABLE `j_atendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_designation`
--
ALTER TABLE `j_designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_emp`
--
ALTER TABLE `j_emp`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `j_extra_and_less_minut`
--
ALTER TABLE `j_extra_and_less_minut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_feedback`
--
ALTER TABLE `j_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_holiday`
--
ALTER TABLE `j_holiday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_leave`
--
ALTER TABLE `j_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_penalty`
--
ALTER TABLE `j_penalty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `query_answer`
--
ALTER TABLE `query_answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `query_question`
--
ALTER TABLE `query_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ast_data`
--
ALTER TABLE `ast_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ast_user`
--
ALTER TABLE `ast_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `atask`
--
ALTER TABLE `atask`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bni_chapter`
--
ALTER TABLE `bni_chapter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bni_give_ask`
--
ALTER TABLE `bni_give_ask`
  MODIFY `g_a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `bni_like_detail`
--
ALTER TABLE `bni_like_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=228;

--
-- AUTO_INCREMENT for table `bni_user`
--
ALTER TABLE `bni_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `enquiry_user`
--
ALTER TABLE `enquiry_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `j_admin_user`
--
ALTER TABLE `j_admin_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `j_atendance`
--
ALTER TABLE `j_atendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1924;

--
-- AUTO_INCREMENT for table `j_designation`
--
ALTER TABLE `j_designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `j_emp`
--
ALTER TABLE `j_emp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `j_extra_and_less_minut`
--
ALTER TABLE `j_extra_and_less_minut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `j_feedback`
--
ALTER TABLE `j_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `j_holiday`
--
ALTER TABLE `j_holiday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `j_leave`
--
ALTER TABLE `j_leave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `j_penalty`
--
ALTER TABLE `j_penalty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `query_answer`
--
ALTER TABLE `query_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `query_question`
--
ALTER TABLE `query_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 19, 2019 at 12:17 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mezyapps`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_admin`
--

CREATE TABLE `app_admin` (
  `admin_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_img` varchar(255) NOT NULL DEFAULT 'https://www.smashusmle.com/wp-content/uploads/2015/01/User-icon.png',
  `image_handel` int(255) NOT NULL DEFAULT '10',
  `currency` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tax` varchar(255) NOT NULL DEFAULT '0.0',
  `shipping` varchar(255) NOT NULL,
  `compney` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_admin`
--

INSERT INTO `app_admin` (`admin_id`, `name`, `email`, `password`, `user_img`, `image_handel`, `currency`, `tax`, `shipping`, `compney`, `address`, `phone`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin123', 'admin.png', 5, 'INR   ', '9.99', '40', '            Jmd Infotech', 'Kailash Colony Ulhasnagar', '8423073490');

-- --------------------------------------------------------

--
-- Table structure for table `app_category`
--

CREATE TABLE `app_category` (
  `cat_id` int(255) NOT NULL,
  `category_name` varchar(300) NOT NULL,
  `category_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_category`
--

INSERT INTO `app_category` (`cat_id`, `category_name`, `category_image`) VALUES
(2, 'atta sooji flours', 'http://mezyapps.com/app_dashboard/uploads/category/165ATAA.jpg'),
(3, 'all purpose cleaners (1)', 'http://mezyapps.com/app_dashboard/uploads/category/421DisinfectantSurfaceCleaner-Neem.jpg'),
(4, 'dairy bread cake milk', 'http://mezyapps.com/app_dashboard/uploads/category/898dairybreadcakemilk.jpg'),
(5, 'detergent and dishwash', 'http://mezyapps.com/app_dashboard/uploads/category/595detergentanddishwash.jpg'),
(6, 'disposables kitchen toilet tissue silver paper', 'http://mezyapps.com/app_dashboard/uploads/category/898disposableskitchentoilettissuesilverpaper.jpg'),
(7, 'dry fruits tong garden more to be added', 'http://mezyapps.com/app_dashboard/uploads/category/406dryfruitstonggardenmoretobeadded.jpg'),
(8, 'KURTI', 'http://mezyapps.com/app_dashboard/uploads/category/192IMG-20190222-WA0007.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `app_products`
--

CREATE TABLE `app_products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(300) NOT NULL,
  `product_id` int(250) NOT NULL,
  `cat_id` varchar(250) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `sellprice` varchar(255) NOT NULL DEFAULT '0',
  `color` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `product_status` varchar(11) NOT NULL DEFAULT 'In-stock',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `date` varchar(255) NOT NULL,
  `plimit` int(255) NOT NULL DEFAULT '10'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_products`
--

INSERT INTO `app_products` (`id`, `product_name`, `product_id`, `cat_id`, `description`, `price`, `sellprice`, `color`, `size`, `product_status`, `quantity`, `date`, `plimit`) VALUES
(2, 'Aashirvaad  Atta  Whole Wheat', 3187, '2', '&lt;p&gt;Aashirvaad &amp;nbsp;Atta - Whole Wheat&lt;/p&gt;\r\n', '368', '440', 'white', 'kg', 'Instock', 8, '18/02/2019', 2),
(5, 'Dettol  Disinfectant Hygiene Liquid  MultiUse, Lime Fresh', 1400, '3', '&lt;p&gt;Dettol &amp;nbsp;Disinfectant Hygiene Liquid - Multi-Use, Lime Fresh&lt;/p&gt;\r\n', '175', '157', 'white', 'ml', 'Instock', 500, '18/02/2019', 2),
(6, 'Nestle A+ Toned Milk', 9330, '4', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Nestle A+&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100011680/nestle-a-toned-milk-1-l/?nc=bakery-cakes-dairy&amp;amp;t_pg=l1-bakery-cakes-dairy&amp;amp;t_p=bakery-cakes-dairy&amp;amp;t_s=bakery-cakes-dairy&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Toned Milk&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '75', '73.50', 'white', ' L Carton', 'Instock', 1, '18/02/2019', 2),
(7, 'Yakult Probiotic Health Drink', 8595, '4', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Yakult&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/292620/yakult-probiotic-health-drink-325-ml/?nc=bakery-cakes-dairy&amp;amp;t_pg=l1-bakery-cakes-dairy&amp;amp;t_p=bakery-cakes-dairy&amp;amp;t_s=bakery-cakes-dairy&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Probiotic Health Drink&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '60', '60', 'white', 'ml Pack of 5', 'Instock', 325, '18/02/2019', 2),
(8, 'Vim Dishwash Gel  Lemon', 2175, '5', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Vim&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/307195/vim-dishwash-gel-lemon-750-ml/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Dishwash Gel - Lemon&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '155', '130', 'white', 'ml', 'Instock', 750, '18/02/2019', 2),
(9, 'Surf Excel Easy Wash Detergent Powder', 5979, '5', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Surf Excel&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/266945/surf-excel-easy-wash-detergent-powder-1-5-kg/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Easy Wash Detergent Powder&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '174', '158', 'white', 'kg', 'Instock', 2, '20/02/2019', 2),
(10, 'Premier Kitchen Towel Kitchen Towel', 6884, '6', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100006306/premier-kitchen-towel-120-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:10.0pt&quot;&gt;&lt;span style=&quot;color:blue&quot;&gt;Premier Kitchen Towel&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100006306/premier-kitchen-towel-120-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Kitchen Towel&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '130', '117', 'white', 'nos Pouch', 'Instock', 120, '20/02/2019', 2),
(11, 'Premier Toilet Tissue Roll', 8053, '6', '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Premier&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/40006963/premier-toilet-tissue-roll-190-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Toilet Tissue Roll&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '140', '140', 'white', 'nos Pack of 4', 'Instock', 190, '20/02/2019', 2),
(19, 'KURTI6066', 3778, '8', '&lt;p&gt;PINK KURTI -&amp;nbsp;&lt;/p&gt;\r\n', '300', '199', 'RED,BLACK,PINCK', 'S,M,L,XL,XXL', 'Instock', 10, '22/02/2019', 2),
(23, 'KURTI6058B', 3993, '8', '&lt;p&gt;KURTI&amp;nbsp;&lt;/p&gt;\r\n', '600', '399', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL', 'Instock', 51, '22/02/2019', 5),
(24, 'KURTI6014', 1795, '8', '&lt;p&gt;KURTIIIII&lt;/p&gt;\r\n', '800', '499', 'RED,BLACK,PINK,YELLOW', 'S,M,L,XL,XXL', 'Instock', 20, '22/02/2019', 5),
(25, 'kURTI6004', 6434, '8', '&lt;p&gt;KURTI&lt;/p&gt;\r\n', '599', '299', 'RED,BLACK,PINK,YELLOW,BLUE,', 'S,M,L,XL,XXL.XXXL', 'Instock', 10, '22/02/2019', 10),
(26, 'KURTI6048', 5285, '8', '&lt;p&gt;KURTUI&lt;/p&gt;\r\n', '1000', '599', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL.XXXL', 'Instock', 19, '22/02/2019', 2),
(27, 'KURTI6043', 9370, '8', '&lt;p&gt;KURTI&lt;/p&gt;\r\n', '399', '199', 'RED,BLACK,PINK,YELLOW,BLUE,', 'S,M,L,XL,XXL.XXXL', 'Instock', 20, '22/02/2019', 1),
(29, 'test', 4521, '2', '&lt;p&gt;testt&lt;/p&gt;\r\n', '500', '450', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL', 'Instock', 2, '20/06/2019', 5),
(30, 'Lizol Disinfectant Surface Cleaner  Neem', 5716, '3', '&lt;p&gt;Lizol Disinfectant Surface Cleaner - Neem&lt;/p&gt;\r\n', '344', '309', 'white', 'lt Bottle', 'Instock', 50, '20/06/2019', 2);

-- --------------------------------------------------------

--
-- Table structure for table `app_productsmain`
--

CREATE TABLE `app_productsmain` (
  `id` int(11) NOT NULL,
  `product_name` varchar(300) NOT NULL,
  `product_id` int(250) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(255) NOT NULL,
  `sellprice` varchar(255) NOT NULL DEFAULT '0',
  `color` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `product_status` varchar(11) NOT NULL DEFAULT 'In-stock',
  `quantity` int(255) NOT NULL DEFAULT '0',
  `date` varchar(255) NOT NULL,
  `plimit` int(255) NOT NULL DEFAULT '10'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_productsmain`
--

INSERT INTO `app_productsmain` (`id`, `product_name`, `product_id`, `description`, `price`, `sellprice`, `color`, `size`, `product_status`, `quantity`, `date`, `plimit`) VALUES
(2, 'Aashirvaad  Atta  Whole Wheat', 3187, '&lt;p&gt;Aashirvaad &amp;nbsp;Atta - Whole Wheat&lt;/p&gt;\r\n', '368', '440', 'white', 'kg', 'Instock', 8, '18/02/2019', 2),
(4, 'Lizol Disinfectant Surface Cleaner  Neem', 5716, '&lt;p&gt;Lizol Disinfectant Surface Cleaner - Neem&lt;/p&gt;\r\n', '344', '309', 'white', 'lt Bottle', 'Instock', 50, '20/06/2019', 2),
(5, 'Dettol  Disinfectant Hygiene Liquid  MultiUse, Lime Fresh', 1400, '&lt;p&gt;Dettol &amp;nbsp;Disinfectant Hygiene Liquid - Multi-Use, Lime Fresh&lt;/p&gt;\r\n', '175', '157', 'white', 'ml', 'Instock', 500, '18/02/2019', 2),
(6, 'Nestle A+ Toned Milk', 9330, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Nestle A+&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100011680/nestle-a-toned-milk-1-l/?nc=bakery-cakes-dairy&amp;amp;t_pg=l1-bakery-cakes-dairy&amp;amp;t_p=bakery-cakes-dairy&amp;amp;t_s=bakery-cakes-dairy&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Toned Milk&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '75', '73.50', 'white', ' L Carton', 'Instock', 1, '18/02/2019', 2),
(7, 'Yakult Probiotic Health Drink', 8595, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Yakult&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/292620/yakult-probiotic-health-drink-325-ml/?nc=bakery-cakes-dairy&amp;amp;t_pg=l1-bakery-cakes-dairy&amp;amp;t_p=bakery-cakes-dairy&amp;amp;t_s=bakery-cakes-dairy&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Probiotic Health Drink&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '60', '60', 'white', 'ml Pack of 5', 'Instock', 325, '18/02/2019', 2),
(8, 'Vim Dishwash Gel  Lemon', 2175, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Vim&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/307195/vim-dishwash-gel-lemon-750-ml/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Dishwash Gel - Lemon&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '155', '130', 'white', 'ml', 'Instock', 750, '18/02/2019', 2),
(9, 'Surf Excel Easy Wash Detergent Powder', 5979, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Surf Excel&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/266945/surf-excel-easy-wash-detergent-powder-1-5-kg/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Easy Wash Detergent Powder&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '174', '158', 'white', 'kg', 'Instock', 2, '20/02/2019', 2),
(10, 'Premier Kitchen Towel Kitchen Towel', 6884, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100006306/premier-kitchen-towel-120-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:10.0pt&quot;&gt;&lt;span style=&quot;color:blue&quot;&gt;Premier Kitchen Towel&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/100006306/premier-kitchen-towel-120-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Kitchen Towel&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '130', '117', 'white', 'nos Pouch', 'Instock', 120, '20/02/2019', 2),
(11, 'Premier Toilet Tissue Roll', 8053, '&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size:8.5pt&quot;&gt;&lt;span style=&quot;color:#999999&quot;&gt;Premier&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-left:0in; margin-right:0in&quot;&gt;&lt;span style=&quot;font-size:11pt&quot;&gt;&lt;span style=&quot;background-color:white&quot;&gt;&lt;a href=&quot;https://www.bigbasket.com/pd/40006963/premier-toilet-tissue-roll-190-nos/?nc=L2Category&amp;amp;t_pg=L2Cagegory&amp;amp;t_p=L2Category&amp;amp;t_s=L2Category&amp;amp;t_pos=3&amp;amp;t_ch=desktop&quot;&gt;&lt;span style=&quot;font-size:9.0pt&quot;&gt;&lt;span style=&quot;color:black&quot;&gt;Toilet Tissue Roll&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\r\n', '140', '140', 'white', 'nos Pack of 4', 'Instock', 190, '20/02/2019', 2),
(12, 'KURTI6066', 3778, '&lt;p&gt;PINK KURTI -&amp;nbsp;&lt;/p&gt;\r\n', '300', '199', 'RED,BLACK,PINCK', 'S,M,L,XL,XXL', 'Instock', 10, '22/02/2019', 2),
(13, 'KURTI6014', 1795, '&lt;p&gt;KURTIIIII&lt;/p&gt;\r\n', '800', '499', 'RED,BLACK,PINK,YELLOW', 'S,M,L,XL,XXL', 'Instock', 20, '22/02/2019', 5),
(14, 'KURTI6058B', 3993, '&lt;p&gt;KURTI&amp;nbsp;&lt;/p&gt;\r\n', '600', '399', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL', 'Instock', 51, '22/02/2019', 5),
(15, 'kURTI6004', 6434, '&lt;p&gt;KURTI&lt;/p&gt;\r\n', '599', '299', 'RED,BLACK,PINK,YELLOW,BLUE,', 'S,M,L,XL,XXL.XXXL', 'Instock', 10, '22/02/2019', 10),
(16, 'KURTI6043', 9370, '&lt;p&gt;KURTI&lt;/p&gt;\r\n', '399', '199', 'RED,BLACK,PINK,YELLOW,BLUE,', 'S,M,L,XL,XXL.XXXL', 'Instock', 20, '22/02/2019', 1),
(17, 'KURTI6048', 5285, '&lt;p&gt;KURTUI&lt;/p&gt;\r\n', '1000', '599', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL.XXXL', 'Instock', 19, '22/02/2019', 2),
(18, 'test', 4521, '&lt;p&gt;testt&lt;/p&gt;\r\n', '500', '450', 'RED,BLACK,PINK,YELLOW,BLUE', 'S,M,L,XL,XXL', 'Instock', 2, '20/06/2019', 5);

-- --------------------------------------------------------

--
-- Table structure for table `app_slider`
--

CREATE TABLE `app_slider` (
  `product_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `app_slider`
--

INSERT INTO `app_slider` (`product_id`, `id`, `image`, `product_name`) VALUES
('3778', 5, 'http://mezyapps.com/app_dashboard/uploads/slider/487IMG-20190222-WA0006.jpg', 'KURTI6066'),
('3993', 6, 'http://mezyapps.com/app_dashboard/uploads/slider/869IMG-20190222-WA0008.jpg', 'kURTI6058B');

-- --------------------------------------------------------

--
-- Table structure for table `AREA_MST`
--

CREATE TABLE `AREA_MST` (
  `AREAID` int(11) NOT NULL,
  `AREA` varchar(250) NOT NULL,
  `CITY` varchar(250) NOT NULL,
  `DISTRICT` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AREA_MST`
--

INSERT INTO `AREA_MST` (`AREAID`, `AREA`, `CITY`, `DISTRICT`) VALUES
(1, 'kailas', 'ulhasnagar', 'thane'),
(2, 'ulahsanagar5', 'amabarnath', 'thane'),
(3, 'ambarrnath', 'kalyan', 'cst'),
(4, 'Sathe Wada', 'Kalyan', 'Thane'),
(5, 'Neharu Chowk', 'Ulhasnagr', 'Thane'),
(6, 'mumbai', 'cst mumbai', 'thane');

-- --------------------------------------------------------

--
-- Table structure for table `CATEGORYMASTER`
--

CREATE TABLE `CATEGORYMASTER` (
  `CATEGORYID` int(11) NOT NULL,
  `CATEGORYNAME` varchar(200) DEFAULT NULL,
  `CATEGORYCODE` varchar(200) DEFAULT NULL,
  `SCHEEM` double DEFAULT NULL,
  `MARGINPER1` double DEFAULT NULL,
  `MARGINPER2` double DEFAULT NULL,
  `MARGINPER3` double DEFAULT NULL,
  `MARGINPER4` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CATEGORYMASTER`
--

INSERT INTO `CATEGORYMASTER` (`CATEGORYID`, `CATEGORYNAME`, `CATEGORYCODE`, `SCHEEM`, `MARGINPER1`, `MARGINPER2`, `MARGINPER3`, `MARGINPER4`) VALUES
(1, 'jmdinfotech', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'KENAN_SOFTWARE', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company_table`
--

CREATE TABLE `company_table` (
  `cmp_id` int(11) NOT NULL,
  `companyname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_01` varchar(12) NOT NULL,
  `contact_02` varchar(12) NOT NULL,
  `license` varchar(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_table`
--

INSERT INTO `company_table` (`cmp_id`, `companyname`, `address`, `contact_01`, `contact_02`, `license`) VALUES
(17, 'SaiPrinters', 'press bazaar ulhasnagar 5', '9168820272', '', '15'),
(20, 'JAI AMBE GMS', 'unr', '2335468799', '', 'M560300114');

-- --------------------------------------------------------

--
-- Table structure for table `customer_table`
--

CREATE TABLE `customer_table` (
  `cust_id` int(11) NOT NULL,
  `cust_code` varchar(15) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `contact_01` varchar(10) NOT NULL,
  `contact_02` varchar(10) NOT NULL,
  `cust_address` varchar(100) NOT NULL,
  `gst_no` varchar(20) NOT NULL,
  `license` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_table`
--

INSERT INTO `customer_table` (`cust_id`, `cust_code`, `cust_name`, `contact_01`, `contact_02`, `cust_address`, `gst_no`, `license`) VALUES
(58, '', 'JAY-SHANKER', '7709655245', '', '', '', ''),
(57, '', 'RAMDEV', '6532487954', '', '', '', ''),
(56, '', 'KERSHNA', '8546329845', '', '', '', ''),
(55, '', 'ASHOK-BADLAPUR', '8956555585', '', '', '', ''),
(54, '', 'SUNIL-AMBERNATH', '8988898998', '', '', '', ''),
(53, '', 'SAI', '9658885522', '', '', '', ''),
(52, '', 'SREE-E', '7851236489', '', '', '', ''),
(51, '', 'NARESH-GWALANI', '9890322940', '', '', '', ''),
(59, '', 'NARESJ', '9890322940', '', '', '', ''),
(60, '', 'MAHAVIR', '9890322940', '', '', '', ''),
(61, '', 'brijesh-vishwakarma', '8446569209', '9076959070', 'kalyan', 'A27578iy588', ''),
(62, '', 'NATH-MOTORS', '98287828', '', 'Badlapur', '', ''),
(63, '', 'CUSTOMER-ONE', '8423073490', '', '', '', 'M560300114'),
(64, '', 'CUSTOMER-TWO', '8707598547', '', '', '', 'M560300114'),
(65, '', 'THAKRA', '9224265574', '', '', '', ''),
(66, '', 'SUSHIL', '8650050050', '', 'Murbad', '', 'M560300114'),
(67, '', 'KAMLESH', '1234567', '', 'murad', '', 'M560300114'),
(68, '', 'KAMLEDH-GMS', '123549094', '', 'une', '', 'M560300114');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `token` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `token`) VALUES
(1, 'cs_iAdZZN18:APA91bGzL_MeXvKOjC80GKnpAhKxp6mt7kKeegqvFSOv8LY5PRLA8vSLNO23w9Yu_sIqtGZ8M37IBCgBqhpI2DLhtapQ9hgi1U0AE85nl37_BSnpGp7qdmm8HjX1bM217QtWCuwpptfK'),
(2, 'cs_iAdZZN18:APA91bFzwGJ4d08z-axRr4f9ipbyYE4cZncqCcX8Iob7o9B-v7LhNO7K_O7J8tTUqJA14lgfzQwrPU4pGmcstBX2_A-_l5zzM7yOP_BSdj4EVWtGTJlsfE8Irw1r_kp9WM-VAkOlW8xe'),
(3, 'cvKEoki4rZg:APA91bG5RJDsCxsha6lbIUn1JltkOo_WiUr4t_ICPmy4PktfHD015yKyf6N5D41BdfkPblo24E8IZn-Dq8EP6xJ-hcHYxeuTKMrtAZjEnvF-zCKD6JwVlfoLQiY-04WJC90fNkcjY6fO'),
(4, 'ddYzgFJkSlI:APA91bEO6Uvh5k8oK7K4GmOJwKbWil14LcvI_emQNKvIm1F3pY70e6RNkn-edq87ZeuKTWruDf0mtq2gmBVGf6NksBglFRsabJffVNsToMxjjAh2Ae3NMc-R7WOrS5PkE_pNGHgUdynh'),
(5, 'd42uqhRjsSU:APA91bGLvNISRtHNDHx5KOrvTcuTwQF4Q31eBE_xgt6u5uJbyySMfiln3O6_jDzLkOxFRJwJ_V9PoDVdWl5OqJCv17hZjWQUTDwEw5jrHntd1tLNFVNeZ_hWMkwdXWb-V1KYR3Z1eiJ5'),
(6, 'eNmleqdljzE:APA91bGpVI4IQKg_LU9NcM6n0ZdpNynkFVCGfdDzz3yDWz9yvjzdxIIW_MqcdV3zct_yD4_Mw7OoRfyuigKAgGjbcoxdqFzVff_KZMAnaqg0nvzgVV_bNVg-dQjWIDG-XyYU2RXLOlQ_'),
(7, 'ciHHUDPS1Cg:APA91bG9X_sGtgWj_yHw_SE--PVAVsKkC23eO_wJbEikVyG3M1VL5m1v7274eLh6viR1Mylgk7t9Tds5cENEeihVUEioCzwL6jq5w7p_CXj8Yg3VErtLACf0TVh4HrCHdGxaWuYnx9HC'),
(8, 'BLACKLISTED'),
(9, 'dGe0BZevQCw:APA91bHcs8QWZxyESrt1PW7I7SZ5JWhiKtW4ryZdHTxC-1Zdhehi45gE21SPHPRgXmvcHfrDCRsjBj8hjkmMvX6Ak4pyHBOMOIc_KhuyUDcys4HgJacxNN9loCuZaHfjDhqzq__--APB'),
(10, 'BLACKLISTED'),
(11, 'fV42Pf9Vz6A:APA91bGtEodvF8XE7rATF_QvH5OesfUo66TXlwcRx_kVopQfmy8akTebfRcitWbzIQAaW2wDJWb_TtDot4pPbzK6fyfYDx8gQ5bMfvh1x-QaLrvT8DegJssqt41OoXJ40zOPJ1jcLbwx'),
(12, 'fQrQjso4Pmw:APA91bG-x3JoLNyU4t_w-zNVjV6LXrOdTI961vEX_fSlrjcbIryA6C05b9fJLWVr7OwlML7bVxs-nTaS9XGVgOdUWTKdRPoh2QkQ_grmF4rFXQgZDlXk5kM87PaTzJBi0DSpYXOg7uiu'),
(13, 'cxBCqYuSpUo:APA91bFDYKwI9OeOOSQbyygEcOmdaJfoF9WdvvkC_1Un-x7q7vegZTis-7QZjdKvqYMqt9qNm7Tg0Yl3ngOcVRwP8GUa_NLeKACdOnVYiqndVteLvlum2s9K-UfaxNFyV7623d_n6IjE'),
(14, 'fM0aPdoPvpU:APA91bGUFBFCJCB8vhda6dYNFUB78ploZGSbQ2gQRveQCOLNelKBkb4mdtsiTUrx_nWIdTbdcXZbWL99V_CFQlWICsWBgWc0L4xGNWHR9QCoYcUL8TnIMdL_v44S8qbIF2ZieJdWhXfG'),
(15, 'eZ0BFNS6loU:APA91bGR0bWU9ceD3bKwcfd0pyIVZCY-MYa4kkJ22JlT-mH-CtkMGYI5ID3sepqZbKvbqIuvx7bAHf9RwzZcrFpccjZMCvh2jJMuoh83z58iCtYfZfI7FdSMmsZfBU00JRNr-tFj5Eg_'),
(16, 'dt7jPb-PxIA:APA91bFO-GkESsEI8LPzTvq9iZkXz4Jc0WfNYxdTbVO235z8KbEDBClJOwWOCB5HQ2hxYMrxtQHiT7thAV1xonVDTDCK7JbF6dfw4B4fLJxgV6KsW53TsclgK_eXtH6rbqJ3DR65nTNN'),
(17, 'cF1T_gdtfBc:APA91bGeSS2tSQGQCn9rpaANiFAcV465MzsKCgjIBDZ-Vju-h1ku3aFVcfxWI8W4SzTWQCpdrUJFHgq6xawWZaqSY-bh0M8m5roRgt6iIXRDeMWDD3PeQadYLUZOPYgRCQ1Pue9emftj'),
(18, 'ev6rdv5-Ok8:APA91bFmeEbu98sg2e7UVyDCAHT_EsoD5EYNp3sdBWdnYdDKWyjgs7MVQMNmfzPFsEsOY-VFJPpcT64OZRiGgezZuMM1mdsLB4V8WQMluGC2FmZPc8k_uae5eOZGJK26zwtF-FB5tPSh'),
(19, 'e14UC0h4QUA:APA91bEGpovRcj1Jnn3vkW2rsVJ4YBu7bq3TqDLCGU1LGrznnWZM3G9wXS5cvGxjomPB1c_-bo4BZfGxBvcNO_tDxWDtqe6Qu0gPLcA0OCC2vcV3qGI9o3NtygajynNvNgfQ3bcpKNdQ'),
(20, 'BLACKLISTED'),
(21, 'BLACKLISTED'),
(22, 'fnKAELV6fuY:APA91bF5qiuL4Cvi-xy4ghA1IhzNsmtHp6sGPKX8hfUdgYv994DsSaF9Qng6KqBb4PHYOZBDrf4_7ANqMiD8XRAxCp79PdAA2KWzg4c4ru8xwq4FobqPsynGD1-ACLhV-v9S2iea8Cph'),
(23, 'ew1LLnYw1ws:APA91bFH6kNMHJ-86M9XU0vajgGqPm7JhRTDbTTpnj6F9NQpbKD1lEnC1widpB6DoMnty3M4aJ1IJW6p5LPo_fj8IkgkAPzvDi_lEC5hqkvL-1N5-Dg0r-OeZwt2xcgmTLgslEzGdp-y'),
(24, 'BLACKLISTED'),
(25, 'ePpnDMwsIGM:APA91bGEbFmG4jV8wc92HuLKMXrM4kazUnbllCBnqkasrnKeUIGd9hqFUbv7p45YspZkZRa9-eqGxiiXKiiLOjBJzHJV209e6JQS7d4WcsqWdvupwR1gJa9y_4h01Dan9vJlzmwXjisH'),
(26, 'eX1oMCBfOv4:APA91bENtddlj8p5j4PiBNjRUlsvIwvRG_fqpsOqSWH0PpIW2JhVIwuFYQliNfCwi55RjFikl1bk4aUba_BfSO_JF4_wbnA-7SyD22MPZTG7HJknK-BZTSJu2r2cyXMqJQlSO3d7esvf'),
(27, 'dtNhhRoThW0:APA91bG982asJ3dqXkwtZkSK7RUcjM8y2trpxrzGWhnnDPteZg8RTXcZ6luGRNp4Jt83IegAmT3aRZtP1w0oapyuaPlJjnNyYuKDq0a_DC7_lq9XlKnjIax4tQ1qrtRRCOsmNepXgpNQ'),
(28, 'BLACKLISTED'),
(29, 'eic--c2B3wA:APA91bFfs-1ul2CLDTmtPnzsABPxiL91bjLT1b2ivdfvp1knKrsa8kQsRWYjm7dbEM11jPZ0ehbQz_6_W9Ky7gRGlAushccSyVmzU5jEgOV2jUcrCwPKDcb7z-5_z9dXdjJfwFiEwAUQ'),
(30, 'fXqjdgSEBpE:APA91bFt6oCMw5gRMUGPTdMPFzI7Jg_nT34ZM5pmXoV_E73E-oHidklq6k5RNis4x_-O3wij5nCLfljj_b8Kz6zguRT-jaiiZOE0D74I7UxhZ9YHvfLHFZ8PE9V4IuhO6nVp2ryjJP1N'),
(31, 'BLACKLISTED'),
(32, 'dBlTxdXwDqc:APA91bFOJbYjKJ0dMTHPIi6e-ZYKqffYWzpU2M3kp4lxHji4oqkP0jjprc6qjbgs808TBM2HOSyo0VoAqwqXc12y1TFDc_nU4A--CMnJnUVmNUqXWnTw-_FU3Dyl-t33Ww4SzC0YXxsp'),
(33, 'cG4urcOQ_aw:APA91bHT5CpVloXRGkjAJHvgEXDfjN-uERVPE-TL3Tgzrm_9cid8CTq6XEN2SluEFQhde_bwdVgWiDEUiL_h7N7MZ5rIG6jsa_jQGd7smE3ldWdduRycHYK7l59Io9Po4rZqGtFZkWC4'),
(34, 'cAPzENHb__4:APA91bFbCYmdMmGLPJhJhVfD17q2iFelpAjQg8HWQiaXF28UH1XaQ2Orq_etb9QZQ23zAskw9oWXN5FWXTB16APOLwfkUMEpZ9mnANtRcD1ANcurOSvpInIOwRKx8Skxx0eRpebJsjGd'),
(35, 'fHZeQv_6pJg:APA91bHIvFvg5_TZ1sKlS3xNFqmdUAFumUSUAGx1YZoXkLjjBBc3tEeDBvlLpPkoUzqNJJ9ZGc_Kw2IWKvg5lNhVCO_hkcrUkHI0UTlGQVsBNDupkF-sdN1sJGNv6uZv_6brnVzO5t6B'),
(36, 'BLACKLISTED'),
(37, 'BLACKLISTED'),
(38, 'eI3t-ZqQk3Y:APA91bHUYL5A-qPOFTENl4BD0k5CJMVDyjoZOYsNC5DIxDAUU4c2pfJxdvKeZIhJcVVQdLYFFOcYkZEcKNiophv2nWMZcFWCDu0VheToUWOpKdUSzflmW4Xd-nyI_A09TbNS-YvnFaHy'),
(39, 'BLACKLISTED'),
(40, 'dOBIgqrEids:APA91bEREU0AnXyFe3J1H9ZG4A8YR-bcX3Exp9Q2MAlkFsy7C-vkS8ZVhRbcqZQjvZvcgI2TxBADJyhdzzHNtGWMW0MAOCtItZlY_QXqHIlrGZjIaicZa44HeWLxRebZFJRUZdWIxKWI'),
(41, 'cFPhhQ4jIvM:APA91bHcXC1wnY1Epzoue1YkKZQn1ZC7FE4AgBEt19flK0cqHGsv-6fDnszk94EFThExNvhj5m7YIkaJyppDOxKQxL8bJTebwKS-rYgeXhgL127x9agLQGIZRNtxCkOM6LdJ6fRhxDIn'),
(42, 'fgxQZWRb72o:APA91bEgt_dC-B_vfSPnjchnTGa0NdJqVvN_iuBGT7N_XbSXCnbuUhZ09J9P3nLx1ymTM49k0Dnc_WD4BIwdoDRy81KyHbjEYZbiUtHD6a-_BbhZgmv654s6J5hmw7rXpd_ix4zOTRMx'),
(43, 'cgccsv_NEy0:APA91bEbNZoMGzqyUVA69Hl-agP30bIs0tfYDXTpqNQSU7htw0yLVr0Xkn8zOaWAG95NHEd10Y4AfixoMBAWXUBoVym7x29Tz1-3ASWQZOLLXGQ6ViUMQMyrEdZN5K5BMLZELd6989cl');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `address`, `gender`, `designation`, `age`) VALUES
(1, 'John Smith', '656 Edsel Road\r\nSherman Oaks, CA 91403', 'Male', 'Manager', 40),
(5, 'Clara Berry', '63 Woodridge Lane\r\nMemphis, TN 38138', 'Male', 'Programmer', 22),
(6, 'Barbra K. Hurley', '1241 Canis Heights Drive\r\nLos Angeles, CA 90017', 'Female', 'Service technician', 26),
(7, 'Antonio J. Forbes', '403 Snyder Avenue\r\nCharlotte, NC 28208', 'Male', 'Falling', 32),
(8, 'Charles D. Horst', '1636 Walnut Hill Drive\r\nCincinnati, OH 45202', 'Male', 'Financial investigator', 29),
(9, 'Beau L. Clayton', '3588 Karen Lane\r\nLouisville, KY 40223', 'Male', 'Extractive metallurgical engin', 33),
(10, 'Ramona W. Burns', '2170 Ocala Street\r\nOrlando, FL 32801', 'Female', 'Electronic typesetting machine operator', 27),
(11, 'Jennifer A. Morrison', '2135 Lakeland Terrace\r\nPlymouth, MI 48170', 'Female', 'Rigging chaser', 29),
(12, 'Susan Juarez', '3177 Horseshoe Lane\r\nNorristown, PA 19403', 'Male', 'Control and valve installe', 52),
(13, 'Ellan D. Downie', '384 Flynn Street\r\nStrongsville, OH 44136', 'Female', 'Education and training manager', 26),
(14, 'Larry T. Williamson', '1424 Andell Road\r\nBrentwood, TN 37027', 'Male', 'Teaching assistant', 30),
(15, 'Lauren M. Reynolds', '4798 Echo Lane\r\nKentwood, MI 49512', 'Female', 'Internet developer', 22),
(16, 'Joseph L. Judge', '3717 Junkins Avenue\r\nMoultrie, GA 31768', 'Male', 'Refrigeration mechanic', 35),
(17, 'Eric C. Lavelle', '1120 Whitetail Lane\r\nDallas, TX 75207', 'Male', 'Model', 21),
(18, 'Cheryl T. Smithers', '1203 Abia Martin Drive\r\nCommack, NY 11725', 'Female', 'Personal banker', 23),
(19, 'Tonia Diaz', '4724 Rocky Road\r\nPhiladelphia, PA 19107', 'Female', 'Facilitator', 29),
(20, 'Stephanie P. Lederman', '2117 Larry Street\r\nWaukesha, WI 53186', 'Female', 'Mental health aide', 27),
(21, 'Edward F. Sanchez', '2313 Elliott Street\r\nManchester, NH 03101', 'Male', 'Marine oilerp', 28),
(25, 'Peter Parker', '403 Snyder Avenue Charlotte, NC 28208', 'Male', 'Programmer', 28),
(27, 'John Smith', '384 Flynn Street Strongsville, OH 44136', 'Male', 'Web Developer', 25),
(28, 'Mark Boucher', '256, Olive Street, NY', 'Male', 'Techbical Assistance', 23);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(10000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `title`, `description`) VALUES
(1, 'FAQ', '&lt;p&gt;Please&amp;nbsp;write your FAQ(Frequently asked questions) here.hii&lt;/p&gt;\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `GROUPS_PER`
--

CREATE TABLE `GROUPS_PER` (
  `SERIESID` int(11) DEFAULT NULL,
  `GROUPID` int(11) NOT NULL,
  `GROUPCODE` varchar(200) DEFAULT NULL,
  `GROUPNAME` varchar(200) DEFAULT NULL,
  `MAINGRPID` int(11) DEFAULT NULL,
  `GRP_INFO` varchar(200) DEFAULT NULL,
  `MAINFLG` varchar(200) DEFAULT NULL,
  `CONT_PERSON` varchar(200) DEFAULT NULL,
  `ADD1` varchar(200) DEFAULT NULL,
  `ADD2` varchar(200) DEFAULT NULL,
  `ADD3` varchar(200) DEFAULT NULL,
  `ADD4` varchar(200) DEFAULT NULL,
  `AREAID` int(11) DEFAULT NULL,
  `TRANSPORTID` int(11) DEFAULT NULL,
  `SPRATETYPE` varchar(200) DEFAULT NULL,
  `SALERATEID` int(11) DEFAULT NULL,
  `SALERATEVALUE` int(11) DEFAULT NULL,
  `ECC1` varchar(200) DEFAULT NULL,
  `ECC2` varchar(200) DEFAULT NULL,
  `ECC3` varchar(200) DEFAULT NULL,
  `VATNO` varchar(200) DEFAULT NULL,
  `CSTNO` varchar(200) DEFAULT NULL,
  `TELNO_R` varchar(200) DEFAULT NULL,
  `TELNO_O` varchar(200) DEFAULT NULL,
  `FAXNO` varchar(200) DEFAULT NULL,
  `MOBILENO` varchar(200) DEFAULT NULL,
  `BANKACCNO` varchar(200) DEFAULT NULL,
  `BANKACCNAME` varchar(200) DEFAULT NULL,
  `E_MAIL` varchar(200) DEFAULT NULL,
  `AC_LIMIT` varchar(200) DEFAULT NULL,
  `CRDAYS` varchar(200) DEFAULT NULL,
  `OS_DAYS` varchar(200) DEFAULT NULL,
  `PANNO` varchar(200) DEFAULT NULL,
  `DLNO` varchar(200) DEFAULT NULL,
  `LBTNO` varchar(200) DEFAULT NULL,
  `REMARKS` varchar(200) DEFAULT NULL,
  `GROUPCODEPREFIX` varchar(200) DEFAULT NULL,
  `RESERVED` varchar(200) DEFAULT NULL,
  `SEND_SMS` varchar(200) DEFAULT NULL,
  `IS_MAIN` varchar(200) DEFAULT NULL,
  `IFSC_CODE` varchar(200) DEFAULT NULL,
  `SHOW_IN_SALE` varchar(200) DEFAULT NULL,
  `HISSAB_DT` varchar(200) DEFAULT NULL,
  `HISSABDT_Y_M_D` varchar(200) DEFAULT NULL,
  `LOCATIONID` int(11) DEFAULT NULL,
  `SALESMAN_ID` int(11) DEFAULT NULL,
  `IND_DROP_CLASS` varchar(200) DEFAULT NULL,
  `SERIAL_NO` varchar(200) DEFAULT NULL,
  `DLNO1` varchar(200) DEFAULT NULL,
  `DLNO2` varchar(200) DEFAULT NULL,
  `DLNO3` varchar(200) DEFAULT NULL,
  `CD_PER` varchar(200) DEFAULT NULL,
  `DISC_ID` int(11) DEFAULT NULL,
  `INTEREST_PER` double DEFAULT NULL,
  `TAXID` int(11) DEFAULT NULL,
  `SHOW_PUCH_SALE` varchar(200) DEFAULT NULL,
  `LOCK_AC` varchar(200) DEFAULT NULL,
  `FORM_TYPE` varchar(200) DEFAULT NULL,
  `GROUPCODEINT` int(11) DEFAULT NULL,
  `STATEID` int(11) DEFAULT NULL,
  `GST_TYPE` varchar(200) DEFAULT NULL,
  `GST_TYPE_ID` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `GROUPS_PER`
--

INSERT INTO `GROUPS_PER` (`SERIESID`, `GROUPID`, `GROUPCODE`, `GROUPNAME`, `MAINGRPID`, `GRP_INFO`, `MAINFLG`, `CONT_PERSON`, `ADD1`, `ADD2`, `ADD3`, `ADD4`, `AREAID`, `TRANSPORTID`, `SPRATETYPE`, `SALERATEID`, `SALERATEVALUE`, `ECC1`, `ECC2`, `ECC3`, `VATNO`, `CSTNO`, `TELNO_R`, `TELNO_O`, `FAXNO`, `MOBILENO`, `BANKACCNO`, `BANKACCNAME`, `E_MAIL`, `AC_LIMIT`, `CRDAYS`, `OS_DAYS`, `PANNO`, `DLNO`, `LBTNO`, `REMARKS`, `GROUPCODEPREFIX`, `RESERVED`, `SEND_SMS`, `IS_MAIN`, `IFSC_CODE`, `SHOW_IN_SALE`, `HISSAB_DT`, `HISSABDT_Y_M_D`, `LOCATIONID`, `SALESMAN_ID`, `IND_DROP_CLASS`, `SERIAL_NO`, `DLNO1`, `DLNO2`, `DLNO3`, `CD_PER`, `DISC_ID`, `INTEREST_PER`, `TAXID`, `SHOW_PUCH_SALE`, `LOCK_AC`, `FORM_TYPE`, `GROUPCODEINT`, `STATEID`, `GST_TYPE`, `GST_TYPE_ID`, `CREATED_BY`, `CREATED_ON`) VALUES
(NULL, 20, '001', 'Pankaj Sir', NULL, 'sund_cr', NULL, NULL, 'Moorbad', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1234567890', NULL, NULL, 'pankaj@gmai.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 21, '002', 'Tarun', NULL, 'sund_cr', NULL, NULL, 'Khemani', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '963258741', NULL, NULL, 'tarun@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 22, '001', 'Esrafil Ansari', NULL, 'sund_sr', NULL, NULL, 'Ulahasnagar', NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '8423073490', NULL, NULL, 'esrafil@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 23, '002', 'Kamlesh Bairagi', NULL, 'sund_sr', NULL, NULL, 'Murbad', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '842301492', NULL, NULL, 'kamlesh@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 24, '003', 'Dipin', NULL, 'sund_sr', NULL, NULL, 'c block', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '325841652', NULL, NULL, 'dipin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 25, 'MK', 'MK ENTERPRISES', NULL, 'sund_sr', NULL, NULL, '505', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '9890322940', NULL, NULL, 'nareshgwalani.g@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 26, 'MN', 'MANISH', NULL, 'sund_cr', NULL, NULL, '505, AS', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '9890322940', NULL, NULL, 'nareshgwal ani.g@g mail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 27, '003', 'Dipin', NULL, 'sund_cr', NULL, NULL, 'c block', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '325841652', NULL, NULL, 'dipin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 28, 'MK', 'MK ENTERPRISES', NULL, 'sund_cr', NULL, NULL, '505', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '9890322940', NULL, NULL, 'nareshgwalani.g@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 29, '', '', NULL, 'sund_cr', NULL, NULL, '', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jmd_user`
--

CREATE TABLE `jmd_user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `license` varchar(11) NOT NULL,
  `status` varchar(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jmd_user`
--

INSERT INTO `jmd_user` (`user_id`, `username`, `pass`, `mobile`, `license`, `status`) VALUES
(1, 'esrafil', '12345', '8423073490', '12@12', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `ks_fcm`
--

CREATE TABLE `ks_fcm` (
  `id` int(11) NOT NULL,
  `token_key` text NOT NULL,
  `token_for` varchar(10) NOT NULL,
  `for_id` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ks_fcm`
--

INSERT INTO `ks_fcm` (`id`, `token_key`, `token_for`, `for_id`) VALUES
(7, '', '', ''),
(6, 'cJUkx4OJbZc:APA91bGyjeVJmsADXfM0RWjn5voeXRYr34xHOVbq9jNG9aaOWlk1fvgyUFEzZlFnyaDqyEFMEBnnSlklVQjfw2H5tW2uMNrSOinAr6sVNZWmDJcGab3klqK-I0Zp1ad82n2_ZK2huSSg', 'E', 'ku1');

-- --------------------------------------------------------

--
-- Table structure for table `M_USER`
--

CREATE TABLE `M_USER` (
  `USER_ID` int(11) NOT NULL,
  `PROFILE_FOR` varchar(250) NOT NULL,
  `NAME` varchar(250) NOT NULL,
  `GENDER` varchar(250) NOT NULL,
  `DOB` varchar(250) NOT NULL,
  `RELIGION` varchar(250) NOT NULL,
  `MOTHER_TONGUE` varchar(250) NOT NULL,
  `CAST_DIVISION` varchar(250) NOT NULL,
  `COUNTRY` varchar(250) NOT NULL,
  `MOBILE` varchar(250) NOT NULL,
  `EMAIL` varchar(250) NOT NULL,
  `PASSWORD` varchar(250) NOT NULL,
  `MATRIMONY_ID` varchar(250) NOT NULL,
  `OTP` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `M_USER`
--

INSERT INTO `M_USER` (`USER_ID`, `PROFILE_FOR`, `NAME`, `GENDER`, `DOB`, `RELIGION`, `MOTHER_TONGUE`, `CAST_DIVISION`, `COUNTRY`, `MOBILE`, `EMAIL`, `PASSWORD`, `MATRIMONY_ID`, `OTP`) VALUES
(27, '8', 'Esrrra', 'M', '1-1-1995', '1', '45', '0', '98', '8423073490', 'ansari0551@gmail.com', '', 'S1027', '186723');

-- --------------------------------------------------------

--
-- Table structure for table `M_USER_DET`
--

CREATE TABLE `M_USER_DET` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `CASTE` varchar(250) NOT NULL,
  `SUBCASTE` varchar(250) NOT NULL,
  `GOTHRA` varchar(250) NOT NULL,
  `DOSH` varchar(250) NOT NULL,
  `MARITAL_STATUS` varchar(250) NOT NULL,
  `HEIGHT` varchar(250) NOT NULL,
  `FAMILY_STATUS` varchar(250) NOT NULL,
  `NO_OF_CHILD` varchar(250) NOT NULL,
  `FAMILY_VALUE` varchar(250) NOT NULL,
  `ANY_DISABILITY` varchar(250) NOT NULL,
  `HIGH_EDUCATION` varchar(250) NOT NULL,
  `EMPLOYED_IN` varchar(250) NOT NULL,
  `OCCUPATION` varchar(250) NOT NULL,
  `ANNUAL_INCOME` varchar(250) NOT NULL,
  `COUNTRY` varchar(250) NOT NULL,
  `STATE` varchar(250) NOT NULL,
  `CITY` varchar(250) NOT NULL,
  `ABOUT_ME` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `M_USER_DET`
--

INSERT INTO `M_USER_DET` (`ID`, `USER_ID`, `CASTE`, `SUBCASTE`, `GOTHRA`, `DOSH`, `MARITAL_STATUS`, `HEIGHT`, `FAMILY_STATUS`, `NO_OF_CHILD`, `FAMILY_VALUE`, `ANY_DISABILITY`, `HIGH_EDUCATION`, `EMPLOYED_IN`, `OCCUPATION`, `ANNUAL_INCOME`, `COUNTRY`, `STATE`, `CITY`, `ABOUT_ME`) VALUES
(74, 27, 'Advani', '', 'Amils', '', '1', '4-7', '1', '', '1', '0', '8', '3', '	AttachÃ©	', '98', '98', '', '0', 'sdfghjk  sdfghjk  dfdcvbnm dzfghjk dfghjk  dfffghj  ');

-- --------------------------------------------------------

--
-- Table structure for table `ordered_product`
--

CREATE TABLE `ordered_product` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sellprice` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ordered_product`
--

INSERT INTO `ordered_product` (`id`, `order_id`, `product_name`, `product_id`, `quantity`, `size`, `color`, `sellprice`, `status`, `product_image`) VALUES
(1, 'OD2786019081970', 'Lizol Disinfectant Surface Cleaner  Neem', '5716', '1', 'lt Bottle', 'white', '309', 'Instock', 'uploads/products/1550502046-disinfectant-surface-cleaner---neem.jpg'),
(5, 'OD5510149649792', 'KURTI6048', '5285', '1', 'XL', 'YELLOW', '599', 'Instock', 'uploads/products/1550836513-img-20190222-wa0014.jpg'),
(4, 'OD5510149649792', 'Aashirvaad  Atta  Multigrains', '8674', '1', 'kg pouch', 'white', '55', 'Instock', 'uploads/order/1550501265-atta.jpg'),
(6, 'OD357413460532', 'Aashirvaad  Atta  Whole Wheat', '3187', '2', 'kg', 'white', '440', 'Instock', 'uploads/products/1550500481-ataa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `license` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_id`, `product_id`, `quantity`, `rate`, `amount`, `user_id`, `license`) VALUES
(122, 102, '10', '240.0', '2400.0', '35', 'M560300114'),
(121, 95, '54', '100.0', '5400.0', '32', 'M560300114'),
(121, 96, '54', '22.5', '1215.0', '32', 'M560300114'),
(121, 94, '25', '154.0', '3850.0', '32', 'M560300114'),
(120, 96, '2', '22.5', '45.0', '31', 'M560300114'),
(120, 95, '2', '100.0', '200.0', '31', 'M560300114'),
(120, 94, '1', '154.0', '154.0', '31', 'M560300114');

-- --------------------------------------------------------

--
-- Table structure for table `order_head`
--

CREATE TABLE `order_head` (
  `order_id` int(11) NOT NULL,
  `ord_dt` varchar(15) NOT NULL,
  `ord_date` varchar(15) NOT NULL,
  `ord_time` varchar(15) NOT NULL,
  `del_dt` varchar(15) NOT NULL,
  `del_date` date NOT NULL,
  `del_time` varchar(15) NOT NULL,
  `cust_id` varchar(15) NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `total_quantity` varchar(50) NOT NULL,
  `bill_amount` varchar(50) NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `paid_amount` varchar(50) NOT NULL,
  `balance_amount` varchar(50) NOT NULL,
  `license` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_head`
--

INSERT INTO `order_head` (`order_id`, `ord_dt`, `ord_date`, `ord_time`, `del_dt`, `del_date`, `del_time`, `cust_id`, `user_id`, `total_quantity`, `bill_amount`, `order_status`, `paid_amount`, `balance_amount`, `license`) VALUES
(122, '06-02-2019', '2019-06-02', '18:10:0', '6-2-2019', '2019-02-06', '', '66', '35', '10', '2400.0', 'done', '2400', '0.0', 'M560300114'),
(121, '30-01-2019', '2019-30-01', '12:33:56', '30-1-2019', '2019-01-30', '', '64', '32', '133', '10465.0', 'done', '10465', '0.0', 'M560300114'),
(120, '30-01-2019', '2019-30-01', '12:22:30', '31-1-2019', '2019-01-31', '', '63', '31', '5', '399.0', 'pending', '', '', 'M560300114');

-- --------------------------------------------------------

--
-- Table structure for table `PGMST`
--

CREATE TABLE `PGMST` (
  `PGMSTID` int(11) NOT NULL,
  `PGMSTNAME` varchar(200) DEFAULT NULL,
  `PGMSTCODE` varchar(200) DEFAULT NULL,
  `UNDERPGID` int(11) DEFAULT NULL,
  `PGMSTPKGINCASE` varchar(200) DEFAULT NULL,
  `PGMSTCONVERSION` varchar(200) DEFAULT NULL,
  `PREFIXCODE` varchar(200) DEFAULT NULL,
  `RESERVED` varchar(200) DEFAULT NULL,
  `GROUPDISCOUNT` varchar(200) DEFAULT NULL,
  `VALUE_CHBOX` varchar(200) DEFAULT NULL,
  `VALUE_TXT` double DEFAULT NULL,
  `VALUE_POINT` double DEFAULT NULL,
  `CASE_CHBOX` varchar(200) DEFAULT NULL,
  `CASE_TXT` double DEFAULT NULL,
  `CASE_POINT` double DEFAULT NULL,
  `QTY_CHBOX` varchar(200) DEFAULT NULL,
  `QTY_TXT` double DEFAULT NULL,
  `QTY_POINT` double DEFAULT NULL,
  `SHOW_Y_N` varchar(200) DEFAULT NULL,
  `CUTTING_SHOW` varchar(200) DEFAULT NULL,
  `CUTTING_ORDER` int(11) DEFAULT NULL,
  `PRINTING_SHOW` varchar(200) DEFAULT NULL,
  `PRINTING_ORDER` int(11) DEFAULT NULL,
  `JOBWORK_SHOW` varchar(200) DEFAULT NULL,
  `JOBWORK_ORDER` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PGMST`
--

INSERT INTO `PGMST` (`PGMSTID`, `PGMSTNAME`, `PGMSTCODE`, `UNDERPGID`, `PGMSTPKGINCASE`, `PGMSTCONVERSION`, `PREFIXCODE`, `RESERVED`, `GROUPDISCOUNT`, `VALUE_CHBOX`, `VALUE_TXT`, `VALUE_POINT`, `CASE_CHBOX`, `CASE_TXT`, `CASE_POINT`, `QTY_CHBOX`, `QTY_TXT`, `QTY_POINT`, `SHOW_Y_N`, `CUTTING_SHOW`, `CUTTING_ORDER`, `PRINTING_SHOW`, `PRINTING_ORDER`, `JOBWORK_SHOW`, `JOBWORK_ORDER`) VALUES
(1, 'mobile', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'abc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'laptop', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'jeans', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Bottle', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Adapter', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Shirt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Chair', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Table', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Pen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Watch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'TABLET', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PMST`
--

CREATE TABLE `PMST` (
  `PRODID` int(11) NOT NULL,
  `PMSTCODE` varchar(200) DEFAULT NULL,
  `PMSTNAME` varchar(200) DEFAULT NULL,
  `PGMSTID` int(11) DEFAULT NULL,
  `CATEGORYID` int(11) DEFAULT NULL,
  `PRODPKGINCASE` varchar(200) DEFAULT NULL,
  `SUPPLIERID` int(11) DEFAULT NULL,
  `GROUPID` int(11) DEFAULT NULL,
  `COSTPRICE` int(11) DEFAULT NULL,
  `SALERATE1` int(11) DEFAULT NULL,
  `MRP` int(11) DEFAULT NULL,
  `TAXPERLOCAL` double DEFAULT NULL,
  `TAXPERCENTRAL` double DEFAULT NULL,
  `BARCODE` varchar(200) DEFAULT NULL,
  `BARCODETYPE` varchar(200) DEFAULT NULL,
  `LOCATIONWISESTOCK` varchar(200) DEFAULT NULL,
  `REMINDBEFORE` double DEFAULT NULL,
  `SETREMINDER` varchar(200) DEFAULT NULL,
  `OPBAL` double DEFAULT NULL,
  `CAL_TYPE` varchar(200) DEFAULT NULL,
  `SHORTNAME` varchar(200) DEFAULT NULL,
  `PRODUCTTYPE` varchar(200) DEFAULT NULL,
  `OPQTY` double DEFAULT NULL,
  `PURCPACKING` double DEFAULT NULL,
  `SALEPACKING` double DEFAULT NULL,
  `PRODCONVERSION` varchar(200) DEFAULT NULL,
  `IMAGE_LINK` varchar(200) DEFAULT NULL,
  `LAST_PUR_RATE` double DEFAULT NULL,
  `PROD_TYPE_ID` int(11) DEFAULT NULL,
  `TYPE` varchar(200) DEFAULT NULL,
  `WEIGHT_PER_PCS` double DEFAULT NULL,
  `INCL_EXCL` varchar(200) DEFAULT NULL,
  `PURCH_DISC1` double DEFAULT NULL,
  `SALE_DISC1` double DEFAULT NULL,
  `PURCH_DISC2` double DEFAULT NULL,
  `SALE_DISC2` double DEFAULT NULL,
  `PROD_COLOUR` varchar(200) DEFAULT NULL,
  `PROD_SIZE` varchar(200) DEFAULT NULL,
  `TEAR_RATE` double DEFAULT NULL,
  `COLOR_ID` int(11) DEFAULT NULL,
  `PRODPKGINCARTOON` varchar(200) DEFAULT NULL,
  `BORDER_SIZE` varchar(200) DEFAULT NULL,
  `COVERING` varchar(200) DEFAULT NULL,
  `CHAIN_LENGTH` varchar(200) DEFAULT NULL,
  `PACKING` varchar(200) DEFAULT NULL,
  `COMPOSITION` varchar(200) DEFAULT NULL,
  `RIM_QTY` varchar(200) DEFAULT NULL,
  `SALERATE2` double DEFAULT NULL,
  `SALERATE3` double DEFAULT NULL,
  `CUST_DISC` varchar(200) DEFAULT NULL,
  `PAGE_ID` int(11) DEFAULT NULL,
  `EXTRA_CHR` double DEFAULT NULL,
  `SALEPACKING1` int(11) DEFAULT NULL,
  `SALEPACKING2` int(11) DEFAULT NULL,
  `SALEPACKING3` int(11) DEFAULT NULL,
  `DROP_BARCODE` int(11) DEFAULT NULL,
  `DEFAULT_BARCODE` varchar(200) DEFAULT NULL,
  `MRP2` double DEFAULT NULL,
  `MRP3` double DEFAULT NULL,
  `SALE_TD2` double DEFAULT NULL,
  `SALE_TD3` double DEFAULT NULL,
  `COMM_PER` double DEFAULT NULL,
  `EFFECT_PRODID` int(11) DEFAULT NULL,
  `PROD_SIZEID` int(11) DEFAULT NULL,
  `INCLU_EXCLU` int(11) DEFAULT NULL,
  `EXP_BEFORE` double DEFAULT NULL,
  `HIDE_Y_N` varchar(200) DEFAULT NULL,
  `MARGIN_PER` double DEFAULT NULL,
  `PRODCODEINT` int(11) DEFAULT NULL,
  `MARBLE_KOTA` varchar(200) DEFAULT NULL,
  `SALERATE4` double DEFAULT NULL,
  `SALEPACKING4` int(11) DEFAULT NULL,
  `MRP4` double DEFAULT NULL,
  `SALE_TD4` double DEFAULT NULL,
  `HSNCODEID` int(11) DEFAULT NULL,
  `CESS_PER` double DEFAULT NULL,
  `ADD_LESS` varchar(200) DEFAULT NULL,
  `TAXABLE_NILL` varchar(200) DEFAULT NULL,
  `MARGIN1` double DEFAULT NULL,
  `MARGIN2` double DEFAULT NULL,
  `MARGIN3` double DEFAULT NULL,
  `MARGIN4` double DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(200) DEFAULT NULL,
  `MATATHI_TXT` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PMST`
--

INSERT INTO `PMST` (`PRODID`, `PMSTCODE`, `PMSTNAME`, `PGMSTID`, `CATEGORYID`, `PRODPKGINCASE`, `SUPPLIERID`, `GROUPID`, `COSTPRICE`, `SALERATE1`, `MRP`, `TAXPERLOCAL`, `TAXPERCENTRAL`, `BARCODE`, `BARCODETYPE`, `LOCATIONWISESTOCK`, `REMINDBEFORE`, `SETREMINDER`, `OPBAL`, `CAL_TYPE`, `SHORTNAME`, `PRODUCTTYPE`, `OPQTY`, `PURCPACKING`, `SALEPACKING`, `PRODCONVERSION`, `IMAGE_LINK`, `LAST_PUR_RATE`, `PROD_TYPE_ID`, `TYPE`, `WEIGHT_PER_PCS`, `INCL_EXCL`, `PURCH_DISC1`, `SALE_DISC1`, `PURCH_DISC2`, `SALE_DISC2`, `PROD_COLOUR`, `PROD_SIZE`, `TEAR_RATE`, `COLOR_ID`, `PRODPKGINCARTOON`, `BORDER_SIZE`, `COVERING`, `CHAIN_LENGTH`, `PACKING`, `COMPOSITION`, `RIM_QTY`, `SALERATE2`, `SALERATE3`, `CUST_DISC`, `PAGE_ID`, `EXTRA_CHR`, `SALEPACKING1`, `SALEPACKING2`, `SALEPACKING3`, `DROP_BARCODE`, `DEFAULT_BARCODE`, `MRP2`, `MRP3`, `SALE_TD2`, `SALE_TD3`, `COMM_PER`, `EFFECT_PRODID`, `PROD_SIZEID`, `INCLU_EXCLU`, `EXP_BEFORE`, `HIDE_Y_N`, `MARGIN_PER`, `PRODCODEINT`, `MARBLE_KOTA`, `SALERATE4`, `SALEPACKING4`, `MRP4`, `SALE_TD4`, `HSNCODEID`, `CESS_PER`, `ADD_LESS`, `TAXABLE_NILL`, `MARGIN1`, `MARGIN2`, `MARGIN3`, `MARGIN4`, `CREATED_BY`, `CREATED_ON`, `MATATHI_TXT`) VALUES
(7, '01', 'Jeans', 3, NULL, NULL, NULL, NULL, 550, 700, 700, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, '02', 'i phone', 1, NULL, NULL, NULL, NULL, 5000, 6000, 6000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, '03', 'Dell Laptop', 4, NULL, NULL, NULL, NULL, 100000, 110000, 110000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'tb', 'table', 9, NULL, NULL, NULL, NULL, 200, 500, 500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `policy`
--

CREATE TABLE `policy` (
  `terms` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `policy`
--

INSERT INTO `policy` (`terms`) VALUES
('&lt;p&gt;Please write your App privacy policy, terms and conditions here.hiii&lt;/p&gt;\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image`) VALUES
(6, '5716', 'uploads/products/1550502046-disinfectant-surface-cleaner---neem.jpg'),
(4, '3187', 'uploads/products/1550500481-ataa.jpg'),
(7, '1400', 'uploads/products/1550502242-dettol--disinfectant-hygiene-liquid---multi-use,-lime-fresh.jpg'),
(8, '9330', 'uploads/products/1550502663-nestle-a+-toned-milk.jpg'),
(9, '8595', 'uploads/products/1550503238-yakult-probiotic-health-drink.jpg'),
(10, '2175', 'uploads/products/1550504326-vim-dishwash-gel---lemon.jpg'),
(11, '5979', 'uploads/products/1550652347-easy-wash-detergent-powder.jpg'),
(12, '6884', 'uploads/products/1550656186-premier-kitchen-towel.jpg'),
(13, '8053', 'uploads/products/1550656453-toilet-tissue-roll.jpg'),
(14, '3778', 'uploads/products/1550835422-img-20190222-wa0006.jpg'),
(15, '1795', 'uploads/products/1550835676-img-20190222-wa0007.jpg'),
(16, '3993', 'uploads/products/1550835799-img-20190222-wa0008.jpg'),
(17, '6434', 'uploads/products/1550836069-img-20190222-wa0009.jpg'),
(18, '9370', 'uploads/products/1550836402-img-20190222-wa0010.jpg'),
(19, '5285', 'uploads/products/1550836513-img-20190222-wa0014.jpg'),
(23, '4521', 'uploads/products/1561027938-download.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_table`
--

CREATE TABLE `product_table` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(10) NOT NULL,
  `product_name` varchar(15) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `product_photo` varchar(100) NOT NULL,
  `license` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_table`
--

INSERT INTO `product_table` (`product_id`, `product_code`, `product_name`, `product_quantity`, `product_price`, `product_photo`, `license`) VALUES
(102, '', 'Jeans', 1, 240, 'http://jmd-infotech.com/Delivery/uploads/.jpg', 'M560300114'),
(101, '', 'V-CARD-NT', 1000, 1.2, 'http://jmd-infotech.com/Delivery/uploads/.jpg', ''),
(100, '', 'V-CARD-Art-card', 1000, 0.7, 'http://jmd-infotech.com/Delivery/uploads/.jpg', ''),
(99, '', '1/5-Book', 10, 1800, 'http://jmd-infotech.com/Delivery/uploads/.jpg', ''),
(98, '', '1/6-Book', 10, 1600, 'http://jmd-infotech.com/Delivery/uploads/.jpg', ''),
(97, '', '1/8-Book', 10, 1300, 'http://jmd-infotech.com/Delivery/uploads/.jpg', ''),
(94, '', 'product-one', 150, 154, 'http://jmd-infotech.com/Delivery/uploads/.jpg', 'M560300114'),
(95, '', 'product--two', 50, 100, 'http://jmd-infotech.com/Delivery/uploads/.jpg', 'M560300114'),
(96, '', 'product-three', 1000, 22.5, 'http://jmd-infotech.com/Delivery/uploads/.jpg', 'M560300114');

-- --------------------------------------------------------

--
-- Table structure for table `PROD_BAL`
--

CREATE TABLE `PROD_BAL` (
  `TRUID` int(11) NOT NULL,
  `DTRUID` int(11) NOT NULL,
  `SERIESID` int(11) NOT NULL,
  `ENTRYID` int(11) NOT NULL,
  `TRANSTYP_ID` int(11) NOT NULL,
  `GROUPID` int(11) NOT NULL,
  `SRNO` int(11) DEFAULT NULL,
  `VCHNO` varchar(200) DEFAULT NULL,
  `VCHDT` varchar(200) DEFAULT NULL,
  `VCH_DT_Y_M_D` varchar(200) DEFAULT NULL,
  `BCD_ID` varchar(200) DEFAULT NULL,
  `BATCH_NO` varchar(200) DEFAULT NULL,
  `PRODID` int(11) NOT NULL,
  `PROD_REMARKS` varchar(200) DEFAULT NULL,
  `PRODSIZEID` int(11) DEFAULT NULL,
  `PRODCASE` double DEFAULT NULL,
  `PRODPKGINCASE` double DEFAULT NULL,
  `OPQTY` double DEFAULT NULL,
  `ISSUEQTY` double DEFAULT NULL,
  `RECEIVEDQTY` double DEFAULT NULL,
  `PURQTY` double DEFAULT NULL,
  `SALQTY` double DEFAULT NULL,
  `BALQTY` double DEFAULT NULL,
  `PRODMRP` double DEFAULT NULL,
  `PUR_RATE` double DEFAULT NULL,
  `FINAL_COST_RATE` double DEFAULT NULL,
  `EST_SALE_RATE` double DEFAULT NULL,
  `SALE_RATE` double DEFAULT NULL,
  `PRODAMT` double DEFAULT NULL,
  `BATCH_STATUS` varchar(200) DEFAULT NULL,
  `BEST_BEFORE` varchar(200) DEFAULT NULL,
  `PRINT_NO` varchar(200) DEFAULT NULL,
  `LOCATIONID` int(11) DEFAULT NULL,
  `LAST_LOCATIONID` int(11) DEFAULT NULL,
  `SALEBOOKRATE` varchar(200) DEFAULT NULL,
  `DISBOOKRATE` varchar(200) DEFAULT NULL,
  `COMMBOOKRATE` varchar(200) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(200) DEFAULT NULL,
  `IS_OPENING` varchar(200) DEFAULT NULL,
  `PRODBAGES` double DEFAULT NULL,
  `COLOR_ID` int(11) DEFAULT NULL,
  `FREE_QTY` double DEFAULT NULL,
  `BILLNO` varchar(200) DEFAULT NULL,
  `BILLDT` varchar(200) DEFAULT NULL,
  `BILLDT_Y_M_D` varchar(200) DEFAULT NULL,
  `BASIC_RATE` double DEFAULT NULL,
  `WS_SALERATE` double DEFAULT NULL,
  `RATE_FOR_SHOW` double DEFAULT NULL,
  `SIZEID` int(11) DEFAULT NULL,
  `MM` int(11) DEFAULT NULL,
  `CARTON` double DEFAULT NULL,
  `CARTON_PKG` double DEFAULT NULL,
  `EX_DT` varchar(200) DEFAULT NULL,
  `EX_DT_Y_M_D` varchar(200) DEFAULT NULL,
  `REP_QTY` double DEFAULT NULL,
  `TD_PER` double DEFAULT NULL,
  `TD_AMT` double DEFAULT NULL,
  `SP_PER` double DEFAULT NULL,
  `SP_AMT` double DEFAULT NULL,
  `LABOURID` int(11) DEFAULT NULL,
  `LOOSE_QTY` double DEFAULT NULL,
  `IS_DELETE` varchar(200) DEFAULT NULL,
  `PROD_REMARKS2` varchar(200) DEFAULT NULL,
  `PREFIXID` int(11) DEFAULT NULL,
  `PREFIXNO` int(11) DEFAULT NULL,
  `NARRATION` varchar(200) DEFAULT NULL,
  `TOTAL_MTR` double DEFAULT NULL,
  `BCDID_PRODID` varchar(200) DEFAULT NULL,
  `KORI` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PROD_BAL`
--

INSERT INTO `PROD_BAL` (`TRUID`, `DTRUID`, `SERIESID`, `ENTRYID`, `TRANSTYP_ID`, `GROUPID`, `SRNO`, `VCHNO`, `VCHDT`, `VCH_DT_Y_M_D`, `BCD_ID`, `BATCH_NO`, `PRODID`, `PROD_REMARKS`, `PRODSIZEID`, `PRODCASE`, `PRODPKGINCASE`, `OPQTY`, `ISSUEQTY`, `RECEIVEDQTY`, `PURQTY`, `SALQTY`, `BALQTY`, `PRODMRP`, `PUR_RATE`, `FINAL_COST_RATE`, `EST_SALE_RATE`, `SALE_RATE`, `PRODAMT`, `BATCH_STATUS`, `BEST_BEFORE`, `PRINT_NO`, `LOCATIONID`, `LAST_LOCATIONID`, `SALEBOOKRATE`, `DISBOOKRATE`, `COMMBOOKRATE`, `CREATED_BY`, `CREATED_ON`, `IS_OPENING`, `PRODBAGES`, `COLOR_ID`, `FREE_QTY`, `BILLNO`, `BILLDT`, `BILLDT_Y_M_D`, `BASIC_RATE`, `WS_SALERATE`, `RATE_FOR_SHOW`, `SIZEID`, `MM`, `CARTON`, `CARTON_PKG`, `EX_DT`, `EX_DT_Y_M_D`, `REP_QTY`, `TD_PER`, `TD_AMT`, `SP_PER`, `SP_AMT`, `LABOURID`, `LOOSE_QTY`, `IS_DELETE`, `PROD_REMARKS2`, `PREFIXID`, `PREFIXNO`, `NARRATION`, `TOTAL_MTR`, `BCDID_PRODID`, `KORI`) VALUES
(23, 0, 0, 1, 36, 22, NULL, NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, 110000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:04 PM', NULL, NULL, NULL, NULL, '2018-12-26', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 0, 0, 1, 36, 22, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, 700, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:08 PM', NULL, NULL, NULL, NULL, '2018-12-26', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 0, 0, 1, 36, 22, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, 6000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:09 PM', NULL, NULL, NULL, NULL, '2018-12-26', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 0, 0, 1, 29, 21, NULL, NULL, NULL, '2018-12-26', NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -25, NULL, NULL, NULL, 700, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 0, 0, 1, 29, 21, NULL, NULL, NULL, '2018-12-26', NULL, NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -25, NULL, NULL, NULL, 6000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 0, 0, 1, 29, 21, NULL, NULL, NULL, '2018-12-26', NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -50, NULL, NULL, NULL, 110000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PURDET`
--

CREATE TABLE `PURDET` (
  `DTRUID` int(11) NOT NULL,
  `BCD_ID` varchar(200) DEFAULT NULL,
  `BATCH_NO` varchar(200) DEFAULT NULL,
  `ENTRYID` int(11) NOT NULL,
  `TRANSTYP_ID` double DEFAULT NULL,
  `WONO` varchar(200) DEFAULT NULL,
  `SRNO` int(11) DEFAULT NULL,
  `PRODID` int(11) DEFAULT NULL,
  `PROD_REMARKS` varchar(200) DEFAULT NULL,
  `PRODSIZEID` int(11) DEFAULT NULL,
  `INCLU_EXCLU` varchar(200) DEFAULT NULL,
  `PRODCASE` double DEFAULT NULL,
  `PRODPKGINCASE` double DEFAULT NULL,
  `PRODQTY` double DEFAULT NULL,
  `FREE_QTY` double DEFAULT NULL,
  `MRP` double DEFAULT NULL,
  `COSTRATE` double DEFAULT NULL,
  `UNITID` int(11) DEFAULT NULL,
  `UNITCONVERSION_VAL` int(11) DEFAULT NULL,
  `PRODRATE` double DEFAULT NULL,
  `VAT_RATE` double DEFAULT NULL,
  `PRODGROSSAMT` double DEFAULT NULL,
  `CD_PER` double DEFAULT NULL,
  `CD_AMT` double DEFAULT NULL,
  `TD_PER` double DEFAULT NULL,
  `TD_AMT` double DEFAULT NULL,
  `SP_PER` double DEFAULT NULL,
  `SP_AMT` double DEFAULT NULL,
  `PRODNETAMT` double DEFAULT NULL,
  `PRODTAX` double DEFAULT NULL,
  `PRODTAXAMT` double DEFAULT NULL,
  `PRODTAXABLEAMT` double DEFAULT NULL,
  `DISC_PER` double DEFAULT NULL,
  `DISC_AMT` double DEFAULT NULL,
  `FINAL_AMT` double DEFAULT NULL,
  `PRODDISS_PER` double DEFAULT NULL,
  `PRODDISS_AMT` double DEFAULT NULL,
  `LBT_PER` double DEFAULT NULL,
  `LBT_AMT` double DEFAULT NULL,
  `BROK_Q_PER` varchar(200) DEFAULT NULL,
  `BROK_PER_QTY` double DEFAULT NULL,
  `BROK_PER_QTY_DIV` double DEFAULT NULL,
  `BROK_AMT` double DEFAULT NULL,
  `TPT_Q_PER` varchar(200) DEFAULT NULL,
  `TPT_PER_QTY` double DEFAULT NULL,
  `TPT_PER_QTY_DIV` double DEFAULT NULL,
  `TPT_AMT` double DEFAULT NULL,
  `PKG_Q_PER` varchar(200) DEFAULT NULL,
  `PKG_PER_QTY` double DEFAULT NULL,
  `PKG_PER_QTY_DIV` double DEFAULT NULL,
  `PKG_AMT` double DEFAULT NULL,
  `WEIGHT_Q_PER` varchar(200) DEFAULT NULL,
  `WEIGHT_PER_QTY` double DEFAULT NULL,
  `WEIGHT_PER_QTY_DIV` double DEFAULT NULL,
  `WEIGHT_AMT` double DEFAULT NULL,
  `FINAL_QTY` double DEFAULT NULL,
  `FINAL_FINAL_AMT` double DEFAULT NULL,
  `NET_FINAL_AMT` double DEFAULT NULL,
  `DROP_SALE_RATE` varchar(200) DEFAULT NULL,
  `SALE_RATE_PER` double DEFAULT NULL,
  `SALE_RATE_AMOUNT` double DEFAULT NULL,
  `FINAL_SALE_RATE` double DEFAULT NULL,
  `BEST_BEFORE` varchar(200) DEFAULT NULL,
  `PRINT_NO` int(11) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(200) DEFAULT NULL,
  `CLEAR` varchar(200) DEFAULT NULL,
  `COLOR_ID` int(11) DEFAULT NULL,
  `SALERATE` double DEFAULT NULL,
  `WS_SALERATE` double DEFAULT NULL,
  `PROD_APMC_TAX_PER` double DEFAULT NULL,
  `PROD_APMC_TAX_AMT` double DEFAULT NULL,
  `SHOW_SALERATE3` double DEFAULT NULL,
  `SIZEID` int(11) DEFAULT NULL,
  `MM` int(11) DEFAULT NULL,
  `EX_DT` varchar(200) DEFAULT NULL,
  `EX_DT_Y_M_D` varchar(200) DEFAULT NULL,
  `REP_QTY` double DEFAULT NULL,
  `PROD_REMARKS2` varchar(200) DEFAULT NULL,
  `ORDER_NO` varchar(200) DEFAULT NULL,
  `PRODLOOSEQTY` double DEFAULT NULL,
  `TRANSPORT_CHRG` double DEFAULT NULL,
  `PROD_SIZE_ID` int(11) DEFAULT NULL,
  `SIZE_TITLE` varchar(200) DEFAULT NULL,
  `MID_SIZE` varchar(200) DEFAULT NULL,
  `MRP_DIFF` double DEFAULT NULL,
  `MRP_PER` double DEFAULT NULL,
  `MARGIN_PER` double DEFAULT NULL,
  `RATE_CONV` double DEFAULT NULL,
  `CHK_PROD` varchar(200) DEFAULT NULL,
  `CGST_PER` double DEFAULT NULL,
  `CGST_AMT` double DEFAULT NULL,
  `SGST_PER` double DEFAULT NULL,
  `SGST_AMT` double DEFAULT NULL,
  `IGST_PER` double DEFAULT NULL,
  `IGST_AMT` double DEFAULT NULL,
  `CESS_PER` double DEFAULT NULL,
  `CESS_AMT` double DEFAULT NULL,
  `SPCESS_PER` double DEFAULT NULL,
  `SPCESS_AMT` double DEFAULT NULL,
  `TAXABLE_NILL` varchar(200) DEFAULT NULL,
  `B_Q` varchar(200) DEFAULT NULL,
  `HSNCODEID` int(11) DEFAULT NULL,
  `COST_BASE_CAL` varchar(200) DEFAULT NULL,
  `SERIESID` int(11) DEFAULT NULL,
  `SALABLE_Y_N` varchar(200) DEFAULT NULL,
  `KORI` double DEFAULT NULL,
  `CARTON` double DEFAULT NULL,
  `CARTON_PKG` double DEFAULT NULL,
  `DISC_FOR_RVS_CAL_PER` double DEFAULT NULL,
  `DISC_FOR_RVS_CAL_AMT` double DEFAULT NULL,
  `USD_RATE` double DEFAULT NULL,
  `RUPEE_ID` int(11) DEFAULT NULL,
  `RS_RATE_CONV` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PURDET`
--

INSERT INTO `PURDET` (`DTRUID`, `BCD_ID`, `BATCH_NO`, `ENTRYID`, `TRANSTYP_ID`, `WONO`, `SRNO`, `PRODID`, `PROD_REMARKS`, `PRODSIZEID`, `INCLU_EXCLU`, `PRODCASE`, `PRODPKGINCASE`, `PRODQTY`, `FREE_QTY`, `MRP`, `COSTRATE`, `UNITID`, `UNITCONVERSION_VAL`, `PRODRATE`, `VAT_RATE`, `PRODGROSSAMT`, `CD_PER`, `CD_AMT`, `TD_PER`, `TD_AMT`, `SP_PER`, `SP_AMT`, `PRODNETAMT`, `PRODTAX`, `PRODTAXAMT`, `PRODTAXABLEAMT`, `DISC_PER`, `DISC_AMT`, `FINAL_AMT`, `PRODDISS_PER`, `PRODDISS_AMT`, `LBT_PER`, `LBT_AMT`, `BROK_Q_PER`, `BROK_PER_QTY`, `BROK_PER_QTY_DIV`, `BROK_AMT`, `TPT_Q_PER`, `TPT_PER_QTY`, `TPT_PER_QTY_DIV`, `TPT_AMT`, `PKG_Q_PER`, `PKG_PER_QTY`, `PKG_PER_QTY_DIV`, `PKG_AMT`, `WEIGHT_Q_PER`, `WEIGHT_PER_QTY`, `WEIGHT_PER_QTY_DIV`, `WEIGHT_AMT`, `FINAL_QTY`, `FINAL_FINAL_AMT`, `NET_FINAL_AMT`, `DROP_SALE_RATE`, `SALE_RATE_PER`, `SALE_RATE_AMOUNT`, `FINAL_SALE_RATE`, `BEST_BEFORE`, `PRINT_NO`, `CREATED_BY`, `CREATED_ON`, `CLEAR`, `COLOR_ID`, `SALERATE`, `WS_SALERATE`, `PROD_APMC_TAX_PER`, `PROD_APMC_TAX_AMT`, `SHOW_SALERATE3`, `SIZEID`, `MM`, `EX_DT`, `EX_DT_Y_M_D`, `REP_QTY`, `PROD_REMARKS2`, `ORDER_NO`, `PRODLOOSEQTY`, `TRANSPORT_CHRG`, `PROD_SIZE_ID`, `SIZE_TITLE`, `MID_SIZE`, `MRP_DIFF`, `MRP_PER`, `MARGIN_PER`, `RATE_CONV`, `CHK_PROD`, `CGST_PER`, `CGST_AMT`, `SGST_PER`, `SGST_AMT`, `IGST_PER`, `IGST_AMT`, `CESS_PER`, `CESS_AMT`, `SPCESS_PER`, `SPCESS_AMT`, `TAXABLE_NILL`, `B_Q`, `HSNCODEID`, `COST_BASE_CAL`, `SERIESID`, `SALABLE_Y_N`, `KORI`, `CARTON`, `CARTON_PKG`, `DISC_FOR_RVS_CAL_PER`, `DISC_FOR_RVS_CAL_AMT`, `USD_RATE`, `RUPEE_ID`, `RS_RATE_CONV`) VALUES
(11, NULL, NULL, 1, 36, NULL, NULL, 8, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, 6000, NULL, NULL, NULL, NULL, 120000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:09 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, NULL, NULL, 1, 36, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, 700, NULL, NULL, NULL, NULL, 14000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:08 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, NULL, NULL, 1, 36, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, 110000, NULL, NULL, NULL, NULL, 2200000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:04 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PURHEAD`
--

CREATE TABLE `PURHEAD` (
  `id` int(11) NOT NULL,
  `ENTRYID` int(11) NOT NULL,
  `TRANSTYP_ID` int(11) NOT NULL,
  `SERIESID` int(11) DEFAULT NULL,
  `PREFIXID` int(11) DEFAULT NULL,
  `PREFIXNO` int(11) DEFAULT NULL,
  `VCHNO` varchar(200) DEFAULT NULL,
  `VCHDT` varchar(200) DEFAULT NULL,
  `VCHDT_Y_M_D` varchar(200) DEFAULT NULL,
  `CHALNO` varchar(200) DEFAULT NULL,
  `CHALDT` varchar(200) DEFAULT NULL,
  `BILLNO` int(11) NOT NULL,
  `BILLDT` varchar(200) DEFAULT NULL,
  `BILLDT_Y_M_D` varchar(200) DEFAULT NULL,
  `GROUPID` int(11) DEFAULT NULL,
  `TAXID` int(11) DEFAULT NULL,
  `TAXGOUPID` int(11) DEFAULT NULL,
  `TOTALCASE` double DEFAULT NULL,
  `TOTALQTY` double DEFAULT NULL,
  `TOT_FREE_QTY` double DEFAULT NULL,
  `TOTALMRP` double DEFAULT NULL,
  `TOTALGROSSAMT` double DEFAULT NULL,
  `TOTAL_CD_AMT` double DEFAULT NULL,
  `TOTAL_TD_AMT` double DEFAULT NULL,
  `TOTAL_SP_AMT` double DEFAULT NULL,
  `TOTALNETAMT` double DEFAULT NULL,
  `TOTALTAXAMT` double DEFAULT NULL,
  `TOTALTAXABLEAMT` double DEFAULT NULL,
  `TOTALDISCAMT` double DEFAULT NULL,
  `TOTALFINALAMT` double DEFAULT NULL,
  `TOTAL_DISS_AMT` double DEFAULT NULL,
  `TOTAL_LBT_AMT` double DEFAULT NULL,
  `TOTAL_BROK_AMT` double DEFAULT NULL,
  `TOTAL_PKG_AMT` double DEFAULT NULL,
  `TOTAL_TPT_AMT` double DEFAULT NULL,
  `TOTAL_WEIGHT_AMT` double DEFAULT NULL,
  `TOTAL_FINAL_BILLAMT` double DEFAULT NULL,
  `FINAL_COST_AMT` double DEFAULT NULL,
  `NARRATION` varchar(200) DEFAULT NULL,
  `VCH_SRS_TRTID` varchar(200) DEFAULT NULL,
  `TAXNTYPE` varchar(200) DEFAULT NULL,
  `TAX_REGION` varchar(200) DEFAULT NULL,
  `TAX_INCL_EXCL` varchar(200) DEFAULT NULL,
  `TRANSPORTID` int(11) DEFAULT NULL,
  `LRNO` varchar(200) DEFAULT NULL,
  `PARCELS` varchar(200) DEFAULT NULL,
  `COURIER` varchar(200) DEFAULT NULL,
  `BOOKING` varchar(200) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(200) DEFAULT NULL,
  `TOTALBILLAMT` double DEFAULT NULL,
  `COMPID` int(11) DEFAULT NULL,
  `LOCATIONID` int(11) DEFAULT NULL,
  `LABOURID` int(11) DEFAULT NULL,
  `ORDER_NO` varchar(200) DEFAULT NULL,
  `FORM_ID` int(11) DEFAULT NULL,
  `IS_CHECK` varchar(200) DEFAULT NULL,
  `FORM_NO` varchar(200) DEFAULT NULL,
  `FORM_DT` varchar(200) DEFAULT NULL,
  `CPD_NAME` varchar(200) DEFAULT NULL,
  `CPD_VAT` varchar(200) DEFAULT NULL,
  `CPD_CST` varchar(200) DEFAULT NULL,
  `CPD_CITY` varchar(200) DEFAULT NULL,
  `CPD_ADD1` varchar(200) DEFAULT NULL,
  `CPD_ADD2` varchar(200) DEFAULT NULL,
  `CPD_ADD3` varchar(200) DEFAULT NULL,
  `CPD_PINCODE` varchar(200) DEFAULT NULL,
  `CPD_MOBILE` varchar(200) DEFAULT NULL,
  `TAXABLE` double DEFAULT NULL,
  `TAX` double DEFAULT NULL,
  `TAXABLE1` double DEFAULT NULL,
  `TAX1` double DEFAULT NULL,
  `TAXABLE2` double DEFAULT NULL,
  `TAX2` double DEFAULT NULL,
  `TAXABLE3` double DEFAULT NULL,
  `TAX3` double DEFAULT NULL,
  `TOTALFREE_QTY` double DEFAULT NULL,
  `PROD_APMC_TAX_AMT` double DEFAULT NULL,
  `DROP_ADD_LESS` varchar(200) DEFAULT NULL,
  `ADD_LESS_AMT` double DEFAULT NULL,
  `CHGABLE_ROUND_OFF_PURCH` double DEFAULT NULL,
  `CHGTYPE_ROUND_OFF_PURCH` varchar(200) DEFAULT NULL,
  `CHG_ROUND_OFF_PURCH` double DEFAULT NULL,
  `TOTALREP_QTY` double DEFAULT NULL,
  `TAXABLE4` double DEFAULT NULL,
  `TAX4` double DEFAULT NULL,
  `CHGABLE_TRANSPORT` double DEFAULT NULL,
  `CHGTYPE_TRANSPORT` varchar(200) DEFAULT NULL,
  `CHG_TRANSPORT` double DEFAULT NULL,
  `CHGABLE_WAGANI` double DEFAULT NULL,
  `CHGTYPE_WAGANI` varchar(200) DEFAULT NULL,
  `CHG_WAGANI` double DEFAULT NULL,
  `TAXABLE5` double DEFAULT NULL,
  `TAX5` double DEFAULT NULL,
  `CHGABLE_VAT5_5` double DEFAULT NULL,
  `CHGTYPE_VAT5_5` double DEFAULT NULL,
  `CHG_VAT5_5` double DEFAULT NULL,
  `LOCALTAXID` varchar(200) DEFAULT NULL,
  `CHGABLE_AAA` double DEFAULT NULL,
  `CHGTYPE_AAA` varchar(200) DEFAULT NULL,
  `CHG_AAA` double DEFAULT NULL,
  `TOT_TRANSPORT_CHRG` double DEFAULT NULL,
  `CHGABLE_TRANSPORT_IN_PURCH` double DEFAULT NULL,
  `CHGTYPE_TRANSPORT_IN_PURCH` varchar(200) DEFAULT NULL,
  `CHG_TRANSPORT_IN_PURCH` double DEFAULT NULL,
  `TAXABLE6` double DEFAULT NULL,
  `TAX6` double DEFAULT NULL,
  `TAXABLE7` double DEFAULT NULL,
  `TAX7` double DEFAULT NULL,
  `CHGABLE_DISCOUNT` double DEFAULT NULL,
  `CHGTYPE_DISCOUNT` varchar(200) DEFAULT NULL,
  `CHG_DISCOUNT` double DEFAULT NULL,
  `CHGABLE_ADD_AMT` double DEFAULT NULL,
  `CHGTYPE_ADD_AMT` varchar(200) DEFAULT NULL,
  `CHG_ADD_AMT` double DEFAULT NULL,
  `CHGABLE_DISCOUNT_AMT` double DEFAULT NULL,
  `CHGTYPE_DISCOUNT_AMT` varchar(200) DEFAULT NULL,
  `CHG_DISCOUNT_AMT` double DEFAULT NULL,
  `TOTALCGST_PER` double DEFAULT NULL,
  `TOTALCGST_AMT` double DEFAULT NULL,
  `TOTALSGST_PER` double DEFAULT NULL,
  `TOTALSGST_AMT` double DEFAULT NULL,
  `TOTALIGST_AMT` double DEFAULT NULL,
  `TOTALIGST_PER` double DEFAULT NULL,
  `INCLU` varchar(200) DEFAULT NULL,
  `REVERSABLE` varchar(200) DEFAULT NULL,
  `TAXABLE8` double DEFAULT NULL,
  `TAX8` double DEFAULT NULL,
  `TAXABLE9` double DEFAULT NULL,
  `TAX9` double DEFAULT NULL,
  `TAXABLE10` double DEFAULT NULL,
  `TAX10` double DEFAULT NULL,
  `GROUPID_EX` int(11) DEFAULT NULL,
  `TOTAL_CESS_AMT` double DEFAULT NULL,
  `TOTAL_SPCESS_AMT` double DEFAULT NULL,
  `GROUPID_CUST` int(11) DEFAULT NULL,
  `GST_TYPE` varchar(200) DEFAULT NULL,
  `GST_TYPE_ID` int(11) DEFAULT NULL,
  `STR_AGAINST_BILL_DET` varchar(200) DEFAULT NULL,
  `TOT_DISC_FOR_RVS_CAL_AMT` double DEFAULT NULL,
  `TOTALCARTON` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PURHEAD`
--

INSERT INTO `PURHEAD` (`id`, `ENTRYID`, `TRANSTYP_ID`, `SERIESID`, `PREFIXID`, `PREFIXNO`, `VCHNO`, `VCHDT`, `VCHDT_Y_M_D`, `CHALNO`, `CHALDT`, `BILLNO`, `BILLDT`, `BILLDT_Y_M_D`, `GROUPID`, `TAXID`, `TAXGOUPID`, `TOTALCASE`, `TOTALQTY`, `TOT_FREE_QTY`, `TOTALMRP`, `TOTALGROSSAMT`, `TOTAL_CD_AMT`, `TOTAL_TD_AMT`, `TOTAL_SP_AMT`, `TOTALNETAMT`, `TOTALTAXAMT`, `TOTALTAXABLEAMT`, `TOTALDISCAMT`, `TOTALFINALAMT`, `TOTAL_DISS_AMT`, `TOTAL_LBT_AMT`, `TOTAL_BROK_AMT`, `TOTAL_PKG_AMT`, `TOTAL_TPT_AMT`, `TOTAL_WEIGHT_AMT`, `TOTAL_FINAL_BILLAMT`, `FINAL_COST_AMT`, `NARRATION`, `VCH_SRS_TRTID`, `TAXNTYPE`, `TAX_REGION`, `TAX_INCL_EXCL`, `TRANSPORTID`, `LRNO`, `PARCELS`, `COURIER`, `BOOKING`, `CREATED_BY`, `CREATED_ON`, `TOTALBILLAMT`, `COMPID`, `LOCATIONID`, `LABOURID`, `ORDER_NO`, `FORM_ID`, `IS_CHECK`, `FORM_NO`, `FORM_DT`, `CPD_NAME`, `CPD_VAT`, `CPD_CST`, `CPD_CITY`, `CPD_ADD1`, `CPD_ADD2`, `CPD_ADD3`, `CPD_PINCODE`, `CPD_MOBILE`, `TAXABLE`, `TAX`, `TAXABLE1`, `TAX1`, `TAXABLE2`, `TAX2`, `TAXABLE3`, `TAX3`, `TOTALFREE_QTY`, `PROD_APMC_TAX_AMT`, `DROP_ADD_LESS`, `ADD_LESS_AMT`, `CHGABLE_ROUND_OFF_PURCH`, `CHGTYPE_ROUND_OFF_PURCH`, `CHG_ROUND_OFF_PURCH`, `TOTALREP_QTY`, `TAXABLE4`, `TAX4`, `CHGABLE_TRANSPORT`, `CHGTYPE_TRANSPORT`, `CHG_TRANSPORT`, `CHGABLE_WAGANI`, `CHGTYPE_WAGANI`, `CHG_WAGANI`, `TAXABLE5`, `TAX5`, `CHGABLE_VAT5_5`, `CHGTYPE_VAT5_5`, `CHG_VAT5_5`, `LOCALTAXID`, `CHGABLE_AAA`, `CHGTYPE_AAA`, `CHG_AAA`, `TOT_TRANSPORT_CHRG`, `CHGABLE_TRANSPORT_IN_PURCH`, `CHGTYPE_TRANSPORT_IN_PURCH`, `CHG_TRANSPORT_IN_PURCH`, `TAXABLE6`, `TAX6`, `TAXABLE7`, `TAX7`, `CHGABLE_DISCOUNT`, `CHGTYPE_DISCOUNT`, `CHG_DISCOUNT`, `CHGABLE_ADD_AMT`, `CHGTYPE_ADD_AMT`, `CHG_ADD_AMT`, `CHGABLE_DISCOUNT_AMT`, `CHGTYPE_DISCOUNT_AMT`, `CHG_DISCOUNT_AMT`, `TOTALCGST_PER`, `TOTALCGST_AMT`, `TOTALSGST_PER`, `TOTALSGST_AMT`, `TOTALIGST_AMT`, `TOTALIGST_PER`, `INCLU`, `REVERSABLE`, `TAXABLE8`, `TAX8`, `TAXABLE9`, `TAX9`, `TAXABLE10`, `TAX10`, `GROUPID_EX`, `TOTAL_CESS_AMT`, `TOTAL_SPCESS_AMT`, `GROUPID_CUST`, `GST_TYPE`, `GST_TYPE_ID`, `STR_AGAINST_BILL_DET`, `TOT_DISC_FOR_RVS_CAL_AMT`, `TOTALCARTON`) VALUES
(4, 1, 36, NULL, NULL, 1, '1', NULL, NULL, NULL, NULL, 1, '26-12-2018', '2018-12-26', 22, NULL, NULL, NULL, 60, NULL, NULL, 2334000, NULL, NULL, NULL, 2334000, NULL, NULL, NULL, 2334000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:23:03 PM', 2334000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SALDET`
--

CREATE TABLE `SALDET` (
  `TRUID` int(11) NOT NULL,
  `DTRUID` int(11) NOT NULL,
  `ENTRYID` int(11) NOT NULL,
  `TRANSTYP_ID` int(11) NOT NULL,
  `SRNO` int(11) NOT NULL,
  `BCD_ID` int(11) NOT NULL,
  `BATCH_NO` int(11) NOT NULL,
  `PRODID` int(11) DEFAULT NULL,
  `PROD_REMARKS` varchar(100) DEFAULT NULL,
  `LOCATIONID` int(11) DEFAULT NULL,
  `PRODCASE` double DEFAULT NULL,
  `PRODPKGINCASE` double DEFAULT NULL,
  `PRODQTY` double DEFAULT NULL,
  `WEIGHT` double DEFAULT NULL,
  `COSTRATE` double DEFAULT NULL,
  `UNITID` int(11) DEFAULT NULL,
  `UNITCONVERSION_VAL` double DEFAULT NULL,
  `INCLU_EXCLU` varchar(100) DEFAULT NULL,
  `MRP` double DEFAULT NULL,
  `PRODRATE` double DEFAULT NULL,
  `PRODGROSSAMT` double DEFAULT NULL,
  `VAT_RATE` double DEFAULT NULL,
  `CD_PER` double DEFAULT NULL,
  `CD_AMT` double DEFAULT NULL,
  `TD_PER` double DEFAULT NULL,
  `TD_AMT` double DEFAULT NULL,
  `SP_PER` double DEFAULT NULL,
  `SP_AMT` double DEFAULT NULL,
  `PRODNETAMT` double DEFAULT NULL,
  `PRODTAXABLEAMT` double DEFAULT NULL,
  `TAX_PER` double DEFAULT NULL,
  `TAX_AMT` double DEFAULT NULL,
  `TAXAMT_VAL` double DEFAULT NULL,
  `FINAL_AMT` double DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(100) DEFAULT NULL,
  `WONO_QTY` varchar(100) DEFAULT NULL,
  `FREE_QTY` double DEFAULT NULL,
  `NET_LANDING_COST` double DEFAULT NULL,
  `B_Q` varchar(100) DEFAULT NULL,
  `SCHEEM_ON` varchar(100) DEFAULT NULL,
  `SCHEEM_VALUE` double DEFAULT NULL,
  `SCHEEM_POINT` double DEFAULT NULL,
  `SCHEEM_POINT_EARN` double DEFAULT NULL,
  `PRODID_2` int(11) DEFAULT NULL,
  `SIZEID` int(11) DEFAULT NULL,
  `MM` int(11) DEFAULT NULL,
  `CARTON` double DEFAULT NULL,
  `CARTON_PKG` double DEFAULT NULL,
  `PRODLENGTH` double DEFAULT NULL,
  `PRODWIDTH` double DEFAULT NULL,
  `FOOT` double DEFAULT NULL,
  `PRODNETRATE` double DEFAULT NULL,
  `REP_QTY` double DEFAULT NULL,
  `PROFIT_PER` double DEFAULT NULL,
  `PROFIT_AMT` double DEFAULT NULL,
  `EX_DT` varchar(100) DEFAULT NULL,
  `EXTRA_CHARGES` double DEFAULT NULL,
  `DELI_ORD` varchar(100) DEFAULT NULL,
  `CHAL_DT` varchar(100) DEFAULT NULL,
  `CHAL_NO` varchar(100) DEFAULT NULL,
  `PARTY_CHAL_NO` varchar(100) DEFAULT NULL,
  `LOOSE_QTY` double DEFAULT NULL,
  `LESS_QTY` double DEFAULT NULL,
  `FIN_QTY` double DEFAULT NULL,
  `PRODCOMM_PER` double DEFAULT NULL,
  `PRODCOMM_AMT` double DEFAULT NULL,
  `PROD_REMARKS2` varchar(100) DEFAULT NULL,
  `SLRTN_EFFECT` varchar(100) DEFAULT NULL,
  `LESSAMT` double DEFAULT NULL,
  `ADDAMT` double DEFAULT NULL,
  `EFFECT_PRODID` int(11) DEFAULT NULL,
  `ORDER_NO` varchar(100) DEFAULT NULL,
  `ORDER_DT` varchar(100) DEFAULT NULL,
  `PRODFINALRATE` double DEFAULT NULL,
  `PCS_LESS` double DEFAULT NULL,
  `PCS_LESS_AMT` varchar(100) DEFAULT NULL,
  `ORD_DTRUID` varchar(100) DEFAULT NULL,
  `SALESMANID` int(11) DEFAULT NULL,
  `TOTAL_MTR` double DEFAULT NULL,
  `RATE_CONV` double DEFAULT NULL,
  `CUTTING_TYPE` varchar(100) DEFAULT NULL,
  `MARBLE_KOTA` varchar(100) DEFAULT NULL,
  `CGST_PER` double DEFAULT NULL,
  `CGST_AMT` double DEFAULT NULL,
  `SGST_PER` double DEFAULT NULL,
  `SGST_AMT` double DEFAULT NULL,
  `IGST_PER` double DEFAULT NULL,
  `IGST_AMT` double DEFAULT NULL,
  `CESS_PER` double DEFAULT NULL,
  `CESS_AMT` double DEFAULT NULL,
  `SPCESS_PER` double DEFAULT NULL,
  `SPCESS_AMT` double DEFAULT NULL,
  `DR_COMM_PER` double DEFAULT NULL,
  `DR_COMM_AMT` double DEFAULT NULL,
  `DR_COMMISSION` double DEFAULT NULL,
  `SALABLE_Y_N` varchar(100) DEFAULT NULL,
  `SALABLE_REASON` varchar(100) DEFAULT NULL,
  `TAXABLE_NILL` varchar(100) DEFAULT NULL,
  `HSNCODEID` int(11) DEFAULT NULL,
  `DOCTORID` int(11) DEFAULT NULL,
  `COST_BASE_CAL` varchar(100) DEFAULT NULL,
  `PUR_ENTRYID` int(11) DEFAULT NULL,
  `PUR_TRANSTYP_ID` int(11) DEFAULT NULL,
  `PUR_SUPP_ID` int(11) DEFAULT NULL,
  `PUR_SUPP_NAME` varchar(100) DEFAULT NULL,
  `PUR_BILLNO` varchar(100) DEFAULT NULL,
  `PUR_BILLDT` varchar(100) DEFAULT NULL,
  `SERIESID` int(11) DEFAULT NULL,
  `BCDID_PRODID` varchar(100) DEFAULT NULL,
  `KORI_PER` double DEFAULT NULL,
  `KORI_AMT` double DEFAULT NULL,
  `DISC3_PER` double DEFAULT NULL,
  `DISC3_AMT` double DEFAULT NULL,
  `DISC_FOR_RVS_CAL_PER` double DEFAULT NULL,
  `DISC_FOR_RVS_CAL_AMT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SALDET`
--

INSERT INTO `SALDET` (`TRUID`, `DTRUID`, `ENTRYID`, `TRANSTYP_ID`, `SRNO`, `BCD_ID`, `BATCH_NO`, `PRODID`, `PROD_REMARKS`, `LOCATIONID`, `PRODCASE`, `PRODPKGINCASE`, `PRODQTY`, `WEIGHT`, `COSTRATE`, `UNITID`, `UNITCONVERSION_VAL`, `INCLU_EXCLU`, `MRP`, `PRODRATE`, `PRODGROSSAMT`, `VAT_RATE`, `CD_PER`, `CD_AMT`, `TD_PER`, `TD_AMT`, `SP_PER`, `SP_AMT`, `PRODNETAMT`, `PRODTAXABLEAMT`, `TAX_PER`, `TAX_AMT`, `TAXAMT_VAL`, `FINAL_AMT`, `CREATED_BY`, `CREATED_ON`, `WONO_QTY`, `FREE_QTY`, `NET_LANDING_COST`, `B_Q`, `SCHEEM_ON`, `SCHEEM_VALUE`, `SCHEEM_POINT`, `SCHEEM_POINT_EARN`, `PRODID_2`, `SIZEID`, `MM`, `CARTON`, `CARTON_PKG`, `PRODLENGTH`, `PRODWIDTH`, `FOOT`, `PRODNETRATE`, `REP_QTY`, `PROFIT_PER`, `PROFIT_AMT`, `EX_DT`, `EXTRA_CHARGES`, `DELI_ORD`, `CHAL_DT`, `CHAL_NO`, `PARTY_CHAL_NO`, `LOOSE_QTY`, `LESS_QTY`, `FIN_QTY`, `PRODCOMM_PER`, `PRODCOMM_AMT`, `PROD_REMARKS2`, `SLRTN_EFFECT`, `LESSAMT`, `ADDAMT`, `EFFECT_PRODID`, `ORDER_NO`, `ORDER_DT`, `PRODFINALRATE`, `PCS_LESS`, `PCS_LESS_AMT`, `ORD_DTRUID`, `SALESMANID`, `TOTAL_MTR`, `RATE_CONV`, `CUTTING_TYPE`, `MARBLE_KOTA`, `CGST_PER`, `CGST_AMT`, `SGST_PER`, `SGST_AMT`, `IGST_PER`, `IGST_AMT`, `CESS_PER`, `CESS_AMT`, `SPCESS_PER`, `SPCESS_AMT`, `DR_COMM_PER`, `DR_COMM_AMT`, `DR_COMMISSION`, `SALABLE_Y_N`, `SALABLE_REASON`, `TAXABLE_NILL`, `HSNCODEID`, `DOCTORID`, `COST_BASE_CAL`, `PUR_ENTRYID`, `PUR_TRANSTYP_ID`, `PUR_SUPP_ID`, `PUR_SUPP_NAME`, `PUR_BILLNO`, `PUR_BILLDT`, `SERIESID`, `BCDID_PRODID`, `KORI_PER`, `KORI_AMT`, `DISC3_PER`, `DISC3_AMT`, `DISC_FOR_RVS_CAL_PER`, `DISC_FOR_RVS_CAL_AMT`) VALUES
(18, 0, 1, 29, 0, 0, 0, 7, NULL, NULL, NULL, NULL, 25, NULL, 700, NULL, NULL, NULL, NULL, NULL, 17500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 0, 1, 29, 0, 0, 0, 8, NULL, NULL, NULL, NULL, 25, NULL, 6000, NULL, NULL, NULL, NULL, NULL, 150000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 0, 1, 29, 0, 0, 0, 9, NULL, NULL, NULL, NULL, 50, NULL, 110000, NULL, NULL, NULL, NULL, NULL, 5500000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SALHEAD`
--

CREATE TABLE `SALHEAD` (
  `TRUID` int(11) NOT NULL,
  `ENTRYID` int(11) DEFAULT NULL,
  `TRANSTYP_ID` int(11) DEFAULT NULL,
  `SERIESID` int(11) DEFAULT NULL,
  `PREFIXID` int(11) DEFAULT NULL,
  `PREFIXNO` int(11) DEFAULT NULL,
  `VCHNO` varchar(100) DEFAULT NULL,
  `VCHDT` varchar(100) DEFAULT NULL,
  `VCHDT_Y_M_D` varchar(100) DEFAULT NULL,
  `CHALNO` varchar(100) DEFAULT NULL,
  `CHALDT` varchar(100) DEFAULT NULL,
  `BILLNO` int(11) NOT NULL,
  `BILLDT` varchar(100) DEFAULT NULL,
  `BILLDT_Y_M_D` varchar(100) DEFAULT NULL,
  `LOCATIONID_FROM` int(11) DEFAULT NULL,
  `LOCATIONID_TO` int(11) DEFAULT NULL,
  `REF_WONO` varchar(100) DEFAULT NULL,
  `REF_ENTRYID` varchar(100) DEFAULT NULL,
  `GROUPID` int(11) DEFAULT NULL,
  `SUB_GROUPID` int(11) DEFAULT NULL,
  `TAXID` int(11) DEFAULT NULL,
  `TAXGOUPID` int(11) DEFAULT NULL,
  `TAXNTYPE` varchar(100) DEFAULT NULL,
  `TAX_REGION` varchar(100) DEFAULT NULL,
  `TAX_INCL_EXCL` varchar(100) DEFAULT NULL,
  `TOTALCASE` double DEFAULT NULL,
  `TOTALQTY` double DEFAULT NULL,
  `TOTAL_WEIGHT` double DEFAULT NULL,
  `TOTALMRP` double DEFAULT NULL,
  `TOTALGROSSAMT` double DEFAULT NULL,
  `TOTAL_CD_AMT` double DEFAULT NULL,
  `TOTAL_TD_AMT` double DEFAULT NULL,
  `TOTAL_SP_AMT` double DEFAULT NULL,
  `TOTALNETAMT` double DEFAULT NULL,
  `TOTALTAXAMT` double DEFAULT NULL,
  `TOTALFINALAMT` double DEFAULT NULL,
  `TOTALBILLAMT` double DEFAULT NULL,
  `NARRATION` varchar(250) DEFAULT NULL,
  `VCH_SRS_TRTID` varchar(100) DEFAULT NULL,
  `TRANSPORTID` int(11) DEFAULT NULL,
  `LRNO` varchar(100) DEFAULT NULL,
  `LRDT` varchar(100) DEFAULT NULL,
  `PARCELS` varchar(100) DEFAULT NULL,
  `COURIER` varchar(100) DEFAULT NULL,
  `BOOKING` varchar(100) DEFAULT NULL,
  `BOOKING_Y_M_D` varchar(100) DEFAULT NULL,
  `BOOKING_Y_N` varchar(100) DEFAULT NULL,
  `PACKING_PERSON` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `CREATED_ON` varchar(100) DEFAULT NULL,
  `COMPID` int(11) DEFAULT NULL,
  `CPD_CODE` varchar(100) DEFAULT NULL,
  `CPD_NAME` varchar(100) DEFAULT NULL,
  `CPD_MOB` varchar(100) DEFAULT NULL,
  `CPD_VAT` varchar(100) DEFAULT NULL,
  `CPD_CST` varchar(100) DEFAULT NULL,
  `CPD_CITY` varchar(100) DEFAULT NULL,
  `CPD_ADD1` varchar(100) DEFAULT NULL,
  `CPD_ADD2` varchar(100) DEFAULT NULL,
  `CPD_ADD3` varchar(100) DEFAULT NULL,
  `CPD_PINCODE` varchar(100) DEFAULT NULL,
  `CPD_MOBILE` varchar(100) DEFAULT NULL,
  `CPD_PANNO` varchar(100) DEFAULT NULL,
  `CPD_AADHARNO` varchar(100) DEFAULT NULL,
  `CPD_CARDNO` varchar(100) DEFAULT NULL,
  `TAXABLE` double DEFAULT NULL,
  `TAX` double DEFAULT NULL,
  `TAXABLFE` double DEFAULT NULL,
  `TAXE` double DEFAULT NULL,
  `TAXABLEFE` double DEFAULT NULL,
  `TAXF` double DEFAULT NULL,
  `TAXABLEEE` double DEFAULT NULL,
  `TAXXX` double DEFAULT NULL,
  `LABOURID` int(11) DEFAULT NULL,
  `SALE_TYPE` varchar(100) DEFAULT NULL,
  `LOCATIONID` int(11) DEFAULT NULL,
  `FORM_ID` int(11) DEFAULT NULL,
  `IS_CHECK` varchar(100) DEFAULT NULL,
  `FORM_NO` varchar(100) DEFAULT NULL,
  `FORM_DT` varchar(100) DEFAULT NULL,
  `TOTALFREE_QTY` double DEFAULT NULL,
  `TOTALREP_QTY` double DEFAULT NULL,
  `DELIVERY_DT` double DEFAULT NULL,
  `DELIVERY_TIME` varchar(100) DEFAULT NULL,
  `PO_NO` varchar(100) DEFAULT NULL,
  `DELI_CHAL_NO` varchar(100) DEFAULT NULL,
  `CHGABLE_ROUND_OFF` double DEFAULT NULL,
  `CHGTYPE_ROUND_OFF` varchar(100) DEFAULT NULL,
  `CHG_ROUND_OFF` double DEFAULT NULL,
  `TOT_SCHEEM_POINT` double DEFAULT NULL,
  `TOT_SCHEEM_POINT_EARN` double DEFAULT NULL,
  `TOTALCARTON` double DEFAULT NULL,
  `SALESMANID` int(11) DEFAULT NULL,
  `SALESMAN_ID` int(11) DEFAULT NULL,
  `MEID` int(11) DEFAULT NULL,
  `GST_ID` int(11) DEFAULT NULL,
  `CANCEL_BILL` varchar(100) DEFAULT NULL,
  `TOT_EXTRA_CHARGES` double DEFAULT NULL,
  `DELIVERY_Y_N` varchar(10) DEFAULT NULL,
  `CASH_CARD_INDEX` int(11) DEFAULT NULL,
  `PO_DT` varchar(100) DEFAULT NULL,
  `DELI_CHAL_DT` varchar(100) DEFAULT NULL,
  `CHGABLE_TAX` double DEFAULT NULL,
  `CHGTYPE_TAX` double DEFAULT NULL,
  `CHG_TAX` double DEFAULT NULL,
  `TOTLESS_QTY` double DEFAULT NULL,
  `TOTFIN_QTY` double DEFAULT NULL,
  `CHGABLE_BABA` double DEFAULT NULL,
  `CHGTYPE_BABA` varchar(100) DEFAULT NULL,
  `CHG_BABA` double DEFAULT NULL,
  `CHGABLE_ABC` double DEFAULT NULL,
  `CHGTYPE_AB` varchar(100) DEFAULT NULL,
  `CHG_ABCYH` double DEFAULT NULL,
  `SLRTN_WONO` varchar(100) DEFAULT NULL,
  `SLRTN_REF_WONO` varchar(100) DEFAULT NULL,
  `SLRTN_BILLAMT` double DEFAULT NULL,
  `SLRTN_BALAMT` double DEFAULT NULL,
  `SLRTN_VCHNO` varchar(100) DEFAULT NULL,
  `TAXABLE_GH` double DEFAULT NULL,
  `TAX_KJAS` double DEFAULT NULL,
  `RECPRODCASE` double DEFAULT NULL,
  `DMGPRODCASE` double DEFAULT NULL,
  `TOT_PROFIT_AMT` double DEFAULT NULL,
  `SLREF_NO` varchar(100) DEFAULT NULL,
  `TAXABLE_KJK` double DEFAULT NULL,
  `TAX_JHVHJ` double DEFAULT NULL,
  `CHGABLE_KAMLESH` double DEFAULT NULL,
  `CHGTYPE_KAMLESH` varchar(100) DEFAULT NULL,
  `CHG_KAMLESH` double DEFAULT NULL,
  `CHGABLE_WAGANI_IN_SALE` double DEFAULT NULL,
  `CHGTYPE_WAGANI_IN_SALE` varchar(100) DEFAULT NULL,
  `CHG_WAGANI_IN_SALE` double DEFAULT NULL,
  `TOTPCS_LESS_AMT` double DEFAULT NULL,
  `CHGABLE_DISC` double DEFAULT NULL,
  `CHGTYPE_DISC` varchar(100) DEFAULT NULL,
  `CHG_DISC` double DEFAULT NULL,
  `BILL_SAVE_DATE` varchar(100) DEFAULT NULL,
  `TAXABLEA` double DEFAULT NULL,
  `TAXGF` double DEFAULT NULL,
  `TAXABLE_JJH` double DEFAULT NULL,
  `TAX13_ASF` double DEFAULT NULL,
  `CHGABLE_TRANSPORT_CHR` double DEFAULT NULL,
  `CHGTYPE_TRANSPORT_CHR` varchar(100) DEFAULT NULL,
  `CHG_TRANSPORT_CHR` double DEFAULT NULL,
  `CHGABLE_PAID` double DEFAULT NULL,
  `CHGTYPE_PAID` varchar(100) DEFAULT NULL,
  `CHG_PAID` double DEFAULT NULL,
  `CHGABLE_DISC_AMT` double DEFAULT NULL,
  `CHGTYPE_DISC_AMT` varchar(100) DEFAULT NULL,
  `CHG_DISC_AMT` double DEFAULT NULL,
  `PNL_DISC_TYPE` int(11) DEFAULT NULL,
  `PNL_DISC_PER` double DEFAULT NULL,
  `PNL_DISC_AMT` double DEFAULT NULL,
  `PNL_ROUNDOFF` double DEFAULT NULL,
  `PNL_TOTALNETAMT` double DEFAULT NULL,
  `PNL_ADV_AMT` double DEFAULT NULL,
  `PNL_BAL_AMT` double DEFAULT NULL,
  `SINK_AMT` double DEFAULT NULL,
  `VERTICAL_AMT` double DEFAULT NULL,
  `FM_AMT` double DEFAULT NULL,
  `HM_AMT` double DEFAULT NULL,
  `DP_AMT` double DEFAULT NULL,
  `VF_AMT` double DEFAULT NULL,
  `SANDWICH_AMT` double DEFAULT NULL,
  `SINK_FOOT` double DEFAULT NULL,
  `VERTICAL_FOOT` double DEFAULT NULL,
  `FM_FOOT` double DEFAULT NULL,
  `HM_FOOT` double DEFAULT NULL,
  `DP_FOOT` double DEFAULT NULL,
  `VF_FOOT` double DEFAULT NULL,
  `SANDWICH_FOOT` double DEFAULT NULL,
  `TOT_TOTAL_MTR` double DEFAULT NULL,
  `TOTALCGST_AMT` double DEFAULT NULL,
  `TOTALSGST_AMT` double DEFAULT NULL,
  `TOTALIGST_AMT` double DEFAULT NULL,
  `INCLU` varchar(100) DEFAULT NULL,
  `DROPRATETYPE` int(11) DEFAULT NULL,
  `IGNORE_PRINTING` varchar(100) DEFAULT NULL,
  `REVERSABLE` varchar(100) DEFAULT NULL,
  `TOTAL_CESS_AMT` double DEFAULT NULL,
  `TOTAL_SPCESS_AMT` double DEFAULT NULL,
  `TAXABLE_JADS` double DEFAULT NULL,
  `TAX_KLN` double DEFAULT NULL,
  `TAXABLE_KJNSJ` double DEFAULT NULL,
  `TAX_AN` double DEFAULT NULL,
  `TAXABLE_KJNSK` double DEFAULT NULL,
  `TAX_KASA` double DEFAULT NULL,
  `TOTAL_DR_COMM` double DEFAULT NULL,
  `GST_TYPE` varchar(100) DEFAULT NULL,
  `GST_TYPE_ID` int(11) DEFAULT NULL,
  `PNL_CHQ_ID` int(11) DEFAULT NULL,
  `PNL_CASH_AMT` double DEFAULT NULL,
  `PNL_CHQ_AMT` double DEFAULT NULL,
  `DONE_Y_N` varchar(100) DEFAULT NULL,
  `TOT_DMG_AMT` double DEFAULT NULL,
  `STR_AGAINST_BILL_DET` varchar(100) DEFAULT NULL,
  `CLOSE_OPEN` varchar(100) DEFAULT NULL,
  `CLOSE_DATE` varchar(100) DEFAULT NULL,
  `EWAY_VEHICAL_NO` varchar(100) DEFAULT NULL,
  `EWAY_DISTANCE` varchar(100) DEFAULT NULL,
  `EWAY_BILL_NO` varchar(100) DEFAULT NULL,
  `EWAY_BILL_DT` varchar(100) DEFAULT NULL,
  `TRANS_MODE` int(11) DEFAULT NULL,
  `VEHI_TYPE` int(11) DEFAULT NULL,
  `PNL_LESS_AMT` double DEFAULT NULL,
  `TOT_KORI_AMT` double DEFAULT NULL,
  `TOT_DISC3_AMT` double DEFAULT NULL,
  `TOT_DISC_FOR_RVS_CAL_AMT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SALHEAD`
--

INSERT INTO `SALHEAD` (`TRUID`, `ENTRYID`, `TRANSTYP_ID`, `SERIESID`, `PREFIXID`, `PREFIXNO`, `VCHNO`, `VCHDT`, `VCHDT_Y_M_D`, `CHALNO`, `CHALDT`, `BILLNO`, `BILLDT`, `BILLDT_Y_M_D`, `LOCATIONID_FROM`, `LOCATIONID_TO`, `REF_WONO`, `REF_ENTRYID`, `GROUPID`, `SUB_GROUPID`, `TAXID`, `TAXGOUPID`, `TAXNTYPE`, `TAX_REGION`, `TAX_INCL_EXCL`, `TOTALCASE`, `TOTALQTY`, `TOTAL_WEIGHT`, `TOTALMRP`, `TOTALGROSSAMT`, `TOTAL_CD_AMT`, `TOTAL_TD_AMT`, `TOTAL_SP_AMT`, `TOTALNETAMT`, `TOTALTAXAMT`, `TOTALFINALAMT`, `TOTALBILLAMT`, `NARRATION`, `VCH_SRS_TRTID`, `TRANSPORTID`, `LRNO`, `LRDT`, `PARCELS`, `COURIER`, `BOOKING`, `BOOKING_Y_M_D`, `BOOKING_Y_N`, `PACKING_PERSON`, `CREATED_BY`, `CREATED_ON`, `COMPID`, `CPD_CODE`, `CPD_NAME`, `CPD_MOB`, `CPD_VAT`, `CPD_CST`, `CPD_CITY`, `CPD_ADD1`, `CPD_ADD2`, `CPD_ADD3`, `CPD_PINCODE`, `CPD_MOBILE`, `CPD_PANNO`, `CPD_AADHARNO`, `CPD_CARDNO`, `TAXABLE`, `TAX`, `TAXABLFE`, `TAXE`, `TAXABLEFE`, `TAXF`, `TAXABLEEE`, `TAXXX`, `LABOURID`, `SALE_TYPE`, `LOCATIONID`, `FORM_ID`, `IS_CHECK`, `FORM_NO`, `FORM_DT`, `TOTALFREE_QTY`, `TOTALREP_QTY`, `DELIVERY_DT`, `DELIVERY_TIME`, `PO_NO`, `DELI_CHAL_NO`, `CHGABLE_ROUND_OFF`, `CHGTYPE_ROUND_OFF`, `CHG_ROUND_OFF`, `TOT_SCHEEM_POINT`, `TOT_SCHEEM_POINT_EARN`, `TOTALCARTON`, `SALESMANID`, `SALESMAN_ID`, `MEID`, `GST_ID`, `CANCEL_BILL`, `TOT_EXTRA_CHARGES`, `DELIVERY_Y_N`, `CASH_CARD_INDEX`, `PO_DT`, `DELI_CHAL_DT`, `CHGABLE_TAX`, `CHGTYPE_TAX`, `CHG_TAX`, `TOTLESS_QTY`, `TOTFIN_QTY`, `CHGABLE_BABA`, `CHGTYPE_BABA`, `CHG_BABA`, `CHGABLE_ABC`, `CHGTYPE_AB`, `CHG_ABCYH`, `SLRTN_WONO`, `SLRTN_REF_WONO`, `SLRTN_BILLAMT`, `SLRTN_BALAMT`, `SLRTN_VCHNO`, `TAXABLE_GH`, `TAX_KJAS`, `RECPRODCASE`, `DMGPRODCASE`, `TOT_PROFIT_AMT`, `SLREF_NO`, `TAXABLE_KJK`, `TAX_JHVHJ`, `CHGABLE_KAMLESH`, `CHGTYPE_KAMLESH`, `CHG_KAMLESH`, `CHGABLE_WAGANI_IN_SALE`, `CHGTYPE_WAGANI_IN_SALE`, `CHG_WAGANI_IN_SALE`, `TOTPCS_LESS_AMT`, `CHGABLE_DISC`, `CHGTYPE_DISC`, `CHG_DISC`, `BILL_SAVE_DATE`, `TAXABLEA`, `TAXGF`, `TAXABLE_JJH`, `TAX13_ASF`, `CHGABLE_TRANSPORT_CHR`, `CHGTYPE_TRANSPORT_CHR`, `CHG_TRANSPORT_CHR`, `CHGABLE_PAID`, `CHGTYPE_PAID`, `CHG_PAID`, `CHGABLE_DISC_AMT`, `CHGTYPE_DISC_AMT`, `CHG_DISC_AMT`, `PNL_DISC_TYPE`, `PNL_DISC_PER`, `PNL_DISC_AMT`, `PNL_ROUNDOFF`, `PNL_TOTALNETAMT`, `PNL_ADV_AMT`, `PNL_BAL_AMT`, `SINK_AMT`, `VERTICAL_AMT`, `FM_AMT`, `HM_AMT`, `DP_AMT`, `VF_AMT`, `SANDWICH_AMT`, `SINK_FOOT`, `VERTICAL_FOOT`, `FM_FOOT`, `HM_FOOT`, `DP_FOOT`, `VF_FOOT`, `SANDWICH_FOOT`, `TOT_TOTAL_MTR`, `TOTALCGST_AMT`, `TOTALSGST_AMT`, `TOTALIGST_AMT`, `INCLU`, `DROPRATETYPE`, `IGNORE_PRINTING`, `REVERSABLE`, `TOTAL_CESS_AMT`, `TOTAL_SPCESS_AMT`, `TAXABLE_JADS`, `TAX_KLN`, `TAXABLE_KJNSJ`, `TAX_AN`, `TAXABLE_KJNSK`, `TAX_KASA`, `TOTAL_DR_COMM`, `GST_TYPE`, `GST_TYPE_ID`, `PNL_CHQ_ID`, `PNL_CASH_AMT`, `PNL_CHQ_AMT`, `DONE_Y_N`, `TOT_DMG_AMT`, `STR_AGAINST_BILL_DET`, `CLOSE_OPEN`, `CLOSE_DATE`, `EWAY_VEHICAL_NO`, `EWAY_DISTANCE`, `EWAY_BILL_NO`, `EWAY_BILL_DT`, `TRANS_MODE`, `VEHI_TYPE`, `PNL_LESS_AMT`, `TOT_KORI_AMT`, `TOT_DISC3_AMT`, `TOT_DISC_FOR_RVS_CAL_AMT`) VALUES
(7, 1, 29, NULL, NULL, 1, '1', NULL, NULL, NULL, NULL, 1, '26-12-2018', '2018-12-26', NULL, NULL, NULL, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 100, NULL, NULL, 5667500, NULL, NULL, NULL, 5667500, NULL, 5667500, 5667500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 111, '06:56:52 PM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `priority` tinyint(4) NOT NULL,
  `description` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `country_id` int(11) NOT NULL,
  `country_name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`country_id`, `country_name`) VALUES
(1, 'Andorra'),
(2, 'United Arab Emirates'),
(3, 'Afghanistan'),
(4, 'Antigua and Barbuda'),
(5, 'Anguilla'),
(6, 'Albania'),
(7, 'Armenia'),
(8, 'Angola'),
(9, 'Antarctica'),
(10, 'Argentina'),
(11, 'American Samoa');

-- --------------------------------------------------------

--
-- Table structure for table `UNIFOOD_EMAIL`
--

CREATE TABLE `UNIFOOD_EMAIL` (
  `ID` int(11) NOT NULL,
  `EMAIL` varchar(250) NOT NULL,
  `TYPE` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UNIFOOD_EMAIL`
--

INSERT INTO `UNIFOOD_EMAIL` (`ID`, `EMAIL`, `TYPE`) VALUES
(1, 'pankaj.khandagle@gmail.com', 'R'),
(2, 'unifoods@mezyapps.com', 'S'),
(4, 'ansari0551@gmail.com', 'R'),
(8, 'payments1@unifoods.com', 'R'),
(9, 'indofoodsmumbai1@gmail.com', 'R');

-- --------------------------------------------------------

--
-- Table structure for table `UNIFOOD_GROUP_PER`
--

CREATE TABLE `UNIFOOD_GROUP_PER` (
  `ID` int(11) NOT NULL,
  `GROUPID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) NOT NULL,
  `GROUP_NAME` varchar(250) NOT NULL,
  `MOBILE_NO` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UNIFOOD_GROUP_PER`
--

INSERT INTO `UNIFOOD_GROUP_PER` (`ID`, `GROUPID`, `GROUP_CODE`, `GROUP_NAME`, `MOBILE_NO`) VALUES
(3, 1, 'abc', 'snnm', '8423073490'),
(4, 2, 'pk', 'kpankaj', 'MOBILE_NO'),
(5, 5, 'CASH SALE I', 'CASH SALE I', '0'),
(6, 6, 'JSM CORPORATION PVT LTD(THE BIG KAHUNA)', 'JSM CORPORATION PVT LTD(THE BIG KAHUNA)', '0'),
(7, 68, 'B ', 'B ', '0'),
(8, 42, 'CAKE BASKET                       RW', 'CAKE BASKET                       RW', '0'),
(9, 38, 'SAMPLING ACCOUNT----COLATE', 'SAMPLING ACCOUNT----COLATE', '0'),
(10, 14, 'CASH SALE (SA)', 'CASH SALE (SA)', '0'),
(11, 24, 'WAH RESTAURANTS PVT LTD          RW', 'WAH RESTAURANTS PVT LTD          RW', '0'),
(12, 482, 'OM PRAKASH BAKERY STORES', 'OM PRAKASH BAKERY STORES', '0'),
(13, 18, 'CHALET HOTELS PVT LTD, UNIT JW MARRIOTT SAHAR', 'CHALET HOTELS PVT LTD, UNIT JW MARRIOTT SAHAR', '0'),
(14, 483, 'YUMIZA SLICE', 'YUMIZA SLICE', '0'),
(15, 811, 'G.A. ENTERPRISES            RW', 'G.A. ENTERPRISES            RW', '0'),
(16, 29, 'LEMON SOUL', 'LEMON SOUL', '0'),
(17, 812, 'HARDIK CORPORATION', 'HARDIK CORPORATION', '0'),
(18, 484, 'SAGAR SPECIALITY CHEMICALS PVT LTD', 'SAGAR SPECIALITY CHEMICALS PVT LTD', '0'),
(19, 813, 'FCK', 'FCK', '0'),
(20, 119, 'SCRUMPTIOUS                      RW', 'SCRUMPTIOUS                      RW', '0'),
(21, 34, 'CASH SALE(SAYYAD)             RW', 'CASH SALE(SAYYAD)             RW', '0'),
(22, 48, 'JSM CORPORATION PVT LTD', 'JSM CORPORATION PVT LTD', '0'),
(23, 10, 'JSM CORPORATION PVT LTD-ANDHERI', 'JSM CORPORATION PVT LTD-ANDHERI', '0'),
(24, 134, 'BAKERS', 'BAKERS', '0'),
(25, 136, 'CAKES BRIGHT SHOP', 'CAKES BRIGHT SHOP', '0'),
(26, 47, 'JSM CORPORATION PVT LTD-WORLI', 'JSM CORPORATION PVT LTD-WORLI', '0'),
(27, 39, 'PAN INDIA THANE(COPPER CHIMNEY)', 'PAN INDIA THANE(COPPER CHIMNEY)', '0'),
(28, 61, 'JSM CORPORATION PVT LTD ASILO', 'JSM CORPORATION PVT LTD ASILO', '0'),
(29, 120, 'DARK TEMPTATION     RS', 'DARK TEMPTATION     RS', '0'),
(30, 64, 'CHINA GATE RESTAURANT SERVICES LTD ( SAKI NAKA )', 'CHINA GATE RESTAURANT SERVICES LTD ( SAKI NAKA )', '0'),
(31, 11, 'MONGINIS FOODS PVT LTD', 'MONGINIS FOODS PVT LTD', '0'),
(32, 17, 'OXYJINN', 'OXYJINN', '0'),
(33, 485, 'THE DOUGH COMPANY', 'THE DOUGH COMPANY', '0'),
(34, 121, 'CAKE WALK', 'CAKE WALK', '0'),
(35, 58, 'J. S. M. CORPORATION,LOWER PAREL', 'J. S. M. CORPORATION,LOWER PAREL', '0'),
(36, 30, 'GENESIS CATERING SERVICES P L ( PRIME ACADEMY SCHOO', 'GENESIS CATERING SERVICES P L ( PRIME ACADEMY SCHOO', '0'),
(37, 7, 'CASH SALE S', 'CASH SALE S', '0'),
(38, 105, 'LA\'BRACO', 'LA\'BRACO', '0'),
(39, 46, 'CORNER SWEETS BAKERS', 'CORNER SWEETS BAKERS', '0'),
(40, 814, 'GENESIS CATERING SERVICES ( IIT POWAI )', 'GENESIS CATERING SERVICES ( IIT POWAI )', '0'),
(41, 73, 'SKY GOURMET CATERING PVT LTD', 'SKY GOURMET CATERING PVT LTD', '0'),
(42, 106, 'SURUCHI-INDIA FOODS(CUST)', 'SURUCHI-INDIA FOODS(CUST)', '0'),
(43, 27, 'NM CHOCO HOLLICS PVT LTD               RC', 'NM CHOCO HOLLICS PVT LTD               RC', '0'),
(44, 110, 'DELUX CATERERS PVT. LTD', 'DELUX CATERERS PVT. LTD', '0'),
(45, 15, 'GENESIS CATERING SERVICES P L(KJ SOMAIYA SIMSR URAN', 'GENESIS CATERING SERVICES P L(KJ SOMAIYA SIMSR URAN', '0'),
(46, 8, 'SMOKE HOUSE DELI BANDRA', 'SMOKE HOUSE DELI BANDRA', '0'),
(47, 9, 'PAN INDIA FOOD SOLUTION PVT. LTD--ANDHERI', 'PAN INDIA FOOD SOLUTION PVT. LTD--ANDHERI', '0'),
(48, 60, 'PAN INDIA FOOD SOLUTION PVT LTD (LOWER PAREL)', 'PAN INDIA FOOD SOLUTION PVT LTD (LOWER PAREL)', '0'),
(49, 98, 'SAMPLING--DM', 'SAMPLING--DM', '0'),
(50, 87, 'OM SHIVAM CONTRUCTIONS', 'OM SHIVAM CONTRUCTIONS', '0'),
(51, 21, 'JSM CORP.PVT LTD ( KURLA )', 'JSM CORP.PVT LTD ( KURLA )', '0'),
(52, 83, 'SAMPLING--MARIM', 'SAMPLING--MARIM', '0'),
(53, 74, 'SAMPLING--VKL', 'SAMPLING--VKL', '0'),
(54, 35, 'FANTASY CAKE SHOP', 'FANTASY CAKE SHOP', '0'),
(55, 13, 'PAN INDIA FOOD SOLUTION PVT LTD (MALAD)', 'PAN INDIA FOOD SOLUTION PVT LTD (MALAD)', '0'),
(56, 19, 'PAN INDIA FOOD SOLUTIONS PVT LTD ( KALAGHODA)', 'PAN INDIA FOOD SOLUTIONS PVT LTD ( KALAGHODA)', '0'),
(57, 23, 'PAN INDIA FOODS PVT LTD ( KURLA PHOENIX )', 'PAN INDIA FOODS PVT LTD ( KURLA PHOENIX )', '0'),
(58, 59, 'PAN INDIA SOLUTIONS PVT LTD ( GOREGAON EAST )', 'PAN INDIA SOLUTIONS PVT LTD ( GOREGAON EAST )', '0'),
(59, 12, 'BROWNIE POINT ---FIRM', 'BROWNIE POINT ---FIRM', '0'),
(60, 16, 'SARWAR FOOD PRODUCTS ( CUSTOMER)', 'SARWAR FOOD PRODUCTS ( CUSTOMER)', '0'),
(61, 20, 'BAKERS PRIDE', 'BAKERS PRIDE', '0'),
(62, 22, 'AARO FOODS PVT LTD                  RW', 'AARO FOODS PVT LTD                  RW', '0'),
(63, 25, 'BISTRO 1', 'BISTRO 1', '0'),
(64, 26, 'MULTI TRADE INC CUSTOMER            RW', 'MULTI TRADE INC CUSTOMER            RW', '0'),
(65, 28, 'PASTRY POINT         RS', 'PASTRY POINT         RS', '0'),
(66, 31, 'SPECIALITY RESTURANT.', 'SPECIALITY RESTURANT.', '0'),
(67, 32, 'HAPPINESS BAKERS PVT LTD', 'HAPPINESS BAKERS PVT LTD', '0'),
(68, 56, 'CELEJOR FOODS INDIA', 'CELEJOR FOODS INDIA', '0'),
(69, 33, 'PERFECT WEIGHT BEVERAGE (URD)', 'PERFECT WEIGHT BEVERAGE (URD)', '0'),
(70, 36, 'B L ENTERPRISES', 'B L ENTERPRISES', '0'),
(71, 37, 'CASH SALE ADHIK', 'CASH SALE ADHIK', '0'),
(72, 40, 'OM SHIVAM THANE', 'OM SHIVAM THANE', '0'),
(73, 41, 'OM SHIVAM CONSTRUCTION - ANDHERI WEST', 'OM SHIVAM CONSTRUCTION - ANDHERI WEST', '0'),
(74, 43, 'NITIN', 'NITIN', '0'),
(75, 112, 'CENTER POINT               RW', 'CENTER POINT               RW', '0'),
(76, 85, 'CHALET HOTELS PVT LTD', 'CHALET HOTELS PVT LTD', '0'),
(77, 66, 'CHINA GATE RESTUARANT SERVICES LTD - BANDRA WEST', 'CHINA GATE RESTUARANT SERVICES LTD - BANDRA WEST', '0'),
(78, 96, 'GRAND CUISINE BANQUET PVT. LTD.', 'GRAND CUISINE BANQUET PVT. LTD.', '0'),
(79, 65, 'HONEYWELL ENTERPRISES DIVISION BLISSS CAFE...', 'HONEYWELL ENTERPRISES DIVISION BLISSS CAFE...', '0'),
(80, 69, 'CHINAGATE RESTAURANT SERVICE LTD. (MIDC)', 'CHINAGATE RESTAURANT SERVICE LTD. (MIDC)', '0'),
(81, 67, 'CHINAGATE RESTUARANT SERVICES LTD SANTACRUZ WEST', 'CHINAGATE RESTUARANT SERVICES LTD SANTACRUZ WEST', '0'),
(82, 44, 'YAASHKRISHNI FOOD SCIENCE LTD.        RW', 'YAASHKRISHNI FOOD SCIENCE LTD.        RW', '0'),
(83, 45, 'CHOC LE â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'CHOC LE â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(84, 109, 'GRAND HYATT MUMBAI        RW', 'GRAND HYATT MUMBAI        RW', '0'),
(85, 49, 'VERTEX SALES', 'VERTEX SALES', '0'),
(86, 50, 'JHAMA BAKERS', 'JHAMA BAKERS', '0'),
(87, 51, 'R G ENTERPRISE', 'R G ENTERPRISE', '0'),
(88, 52, 'CS SWEET PASSIONS RC â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'CS SWEET PASSIONS RC â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(89, 53, 'FOOD TALK BAKERY(URD)', 'FOOD TALK BAKERY(URD)', '0'),
(90, 54, 'IMPRESARIO ENTERTAINMENT ', 'IMPRESARIO ENTERTAINMENT ', '0'),
(91, 55, 'FOOD TALKS', 'FOOD TALKS', '0'),
(92, 99, 'JSM CORPORATION (COOLING TOWER)', 'JSM CORPORATION (COOLING TOWER)', '0'),
(93, 57, 'ELLINOR BAKING COMPANY', 'ELLINOR BAKING COMPANY', '0'),
(94, 62, 'MERWANS CONFECTIONARS PVT LTD', 'MERWANS CONFECTIONARS PVT LTD', '0'),
(95, 63, 'PARTY CAKE SHOP (GHATKOPAR)', 'PARTY CAKE SHOP (GHATKOPAR)', '0'),
(96, 114, 'AK\'S BAKERS ', 'AK\'S BAKERS ', '0'),
(97, 97, 'M.G BAKERY                     RC', 'M.G BAKERY                     RC', '0'),
(98, 70, 'JSM GGC RESTAURANTS PVT LTD ( MALAD)', 'JSM GGC RESTAURANTS PVT LTD ( MALAD)', '0'),
(99, 71, 'BAKEWELL                             RC', 'BAKEWELL                             RC', '0'),
(100, 72, 'SHARIF', 'SHARIF', '0'),
(101, 81, 'TRINITY ENTERPRISES             RC', 'TRINITY ENTERPRISES             RC', '0'),
(102, 75, 'SAMPLING---HYFUN', 'SAMPLING---HYFUN', '0'),
(103, 76, 'FOOD UNLIMITED', 'FOOD UNLIMITED', '0'),
(104, 77, 'JOY BOX', 'JOY BOX', '0'),
(105, 113, 'GAUR FOODS PVT. LTD               RC', 'GAUR FOODS PVT. LTD               RC', '0'),
(106, 78, 'KREAMY KUBES                         RW', 'KREAMY KUBES                         RW', '0'),
(107, 79, 'S K ENTERPRISES (URD)', 'S K ENTERPRISES (URD)', '0'),
(108, 837, 'SHAH TRADERS', 'SHAH TRADERS', '0'),
(109, 118, 'OVEN HOT                          RC', 'OVEN HOT                          RC', '0'),
(110, 80, 'ADARSH BAKERS POINT   RS', 'ADARSH BAKERS POINT   RS', '0'),
(111, 82, 'RG FOODS AND CONFECTIONARY PVT LTD', 'RG FOODS AND CONFECTIONARY PVT LTD', '0'),
(112, 95, 'BEENA\'S HOMEMADE PRODUCT', 'BEENA\'S HOMEMADE PRODUCT', '0'),
(113, 84, 'BROWNIE POINT                       RC', 'BROWNIE POINT                       RC', '0'),
(114, 111, 'CASH SALE N', 'CASH SALE N', '0'),
(115, 92, 'GLORIA FOODS', 'GLORIA FOODS', '0'),
(116, 86, 'JUHU BEACH RESORTS LTD', 'JUHU BEACH RESORTS LTD', '0'),
(117, 93, 'LE GATEAU FOODS INDIA PRIVATE LIMITED', 'LE GATEAU FOODS INDIA PRIVATE LIMITED', '0'),
(118, 838, 'TREES IMPEX', 'TREES IMPEX', '0'),
(119, 88, 'SAHYOG BAKERY                       RW', 'SAHYOG BAKERY                       RW', '0'),
(120, 89, 'SAMPLING--IFFCO', 'SAMPLING--IFFCO', '0'),
(121, 90, 'CAKE STAR', 'CAKE STAR', '0'),
(122, 91, 'CHINA GATE RESTAURANT SERVICES LTD ( ANDHERI WEST )', 'CHINA GATE RESTAURANT SERVICES LTD ( ANDHERI WEST )', '0'),
(123, 94, 'SAMPLING ACCOUNT -- MAPRO', 'SAMPLING ACCOUNT -- MAPRO', '0'),
(124, 132, 'ZERO DEGREE BREAK FREE  DESERT', 'ZERO DEGREE BREAK FREE  DESERT', '0'),
(125, 103, 'ARIF (MATUNGA)', 'ARIF (MATUNGA)', '0'),
(126, 125, 'DELICIA FOODS', 'DELICIA FOODS', '0'),
(127, 130, 'BAKERS HOUSE (URD)', 'BAKERS HOUSE (URD)', '0'),
(128, 820, 'BOMBAY BURGERS', 'BOMBAY BURGERS', '0'),
(129, 122, 'FREE INDIA BAKERY', 'FREE INDIA BAKERY', '0'),
(130, 142, 'JADE STONE CAFE (URD)', 'JADE STONE CAFE (URD)', '0'),
(131, 100, 'CHINA GATE RESTAURANTS PVT LTD(OBEROI MAIN STORE)', 'CHINA GATE RESTAURANTS PVT LTD(OBEROI MAIN STORE)', '0'),
(132, 101, 'SAMPLING -- HABIT', 'SAMPLING -- HABIT', '0'),
(133, 107, 'PARTY CAKE SHOP               RC', 'PARTY CAKE SHOP               RC', '0'),
(134, 102, 'ICE HOSPITALITY PVT LTD', 'ICE HOSPITALITY PVT LTD', '0'),
(135, 104, 'JAIHIND COLLEGE CANTEEN (URD)', 'JAIHIND COLLEGE CANTEEN (URD)', '0'),
(136, 108, 'SARATHI ENTERPRISES', 'SARATHI ENTERPRISES', '0'),
(137, 123, 'FRONTSTREET           RO', 'FRONTSTREET           RO', '0'),
(138, 839, 'RED VELVET CAKE SHOP', 'RED VELVET CAKE SHOP', '0'),
(139, 840, 'AMBIKA FOODS', 'AMBIKA FOODS', '0'),
(140, 816, 'BAKERS CHEER', 'BAKERS CHEER', '0'),
(141, 146, 'NISHITA', 'NISHITA', '0'),
(142, 139, 'OCCASIONS CAKES ', 'OCCASIONS CAKES ', '0'),
(143, 138, 'OM SAI MARKETING', 'OM SAI MARKETING', '0'),
(144, 818, 'SANTOSHAM', 'SANTOSHAM', '0'),
(145, 117, 'SUGARTOOTH   â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'SUGARTOOTH   â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(146, 563, 'VIDYA ENTERPRISE', 'VIDYA ENTERPRISE', '0'),
(147, 2243, 'C J HOSPITALITIES LLP', 'C J HOSPITALITIES LLP', '0'),
(148, 2012, 'THE CHOCOLATE ROOM (INDIA)PVT LTD', 'THE CHOCOLATE ROOM (INDIA)PVT LTD', '0'),
(149, 2112, 'SAI FOODS', 'SAI FOODS', '0'),
(150, 1449, 'ASALUTI GOURMAND LLP', 'ASALUTI GOURMAND LLP', '0'),
(151, 2018, 'RMZ FOOD AND HOSPITALITY PVT LTD', 'RMZ FOOD AND HOSPITALITY PVT LTD', '0'),
(152, 1436, 'SUZETTE GOURMET PVT LTD', 'SUZETTE GOURMET PVT LTD', '0'),
(153, 2903, 'SAURABH ENTERPRISES', 'SAURABH ENTERPRISES', '0'),
(154, 1933, 'NOVOTEL IMAGICA KHOPOLI', 'NOVOTEL IMAGICA KHOPOLI', '0'),
(155, 2776, 'WALIAS F ', 'WALIAS F ', '0'),
(156, 2542, 'GUPTA BRANDS LLP', 'GUPTA BRANDS LLP', '0'),
(157, 1104, 'PVR LIMITED', 'PVR LIMITED', '0'),
(158, 2069, 'MI FAVARITO', 'MI FAVARITO', '0'),
(159, 757, 'GAYATRI CHOCOLATE', 'GAYATRI CHOCOLATE', '0'),
(160, 2032, 'VEG DELICIOUS', 'VEG DELICIOUS', '0'),
(161, 2107, 'GOURMET INVESTMENTS PVT.LTD', 'GOURMET INVESTMENTS PVT.LTD', '0'),
(162, 1555, '3FORKS HOSPITALITY PRIVATE LIMITED', '3FORKS HOSPITALITY PRIVATE LIMITED', '0'),
(163, 2422, '3FOLKS HOSPITALITY PRIVATE LTD', '3FOLKS HOSPITALITY PRIVATE LTD', '0'),
(164, 2761, 'SARIKA ENTERPRISES', 'SARIKA ENTERPRISES', '0'),
(165, 2402, 'AMIGOS FOOD COMPANY LLP', 'AMIGOS FOOD COMPANY LLP', '0'),
(166, 2835, 'DESSERT DELIGHT', 'DESSERT DELIGHT', '0'),
(167, 2593, 'CASH SALE UM', 'CASH SALE UM', '0'),
(168, 1926, 'SAWHNEY ', 'SAWHNEY ', '0'),
(169, 2877, 'SANDWIZZA FOOD PVT LTD', 'SANDWIZZA FOOD PVT LTD', '0'),
(170, 1930, 'IRFAN MOULD', 'IRFAN MOULD', '0'),
(171, 2214, 'LE NIBELETTE', 'LE NIBELETTE', '0'),
(172, 2553, 'M/S SHRI MAMAL FOODS', 'M/S SHRI MAMAL FOODS', '0'),
(173, 1249, 'SIN CHOCOLATES ', 'SIN CHOCOLATES ', '0'),
(174, 360, 'MRK FOODS PRIVATE LIMITED', 'MRK FOODS PRIVATE LIMITED', '0'),
(175, 2163, 'CAKES ', 'CAKES ', '0'),
(176, 1913, 'THE MUFFIN MAN', 'THE MUFFIN MAN', '0'),
(177, 1810, 'BAKERS HOUSE', 'BAKERS HOUSE', '0'),
(178, 2219, 'SCHOOL FOR EUROPEAN PASTRY', 'SCHOOL FOR EUROPEAN PASTRY', '0'),
(179, 2906, 'SHEETAL ASHISH HOTEL PVT LTD', 'SHEETAL ASHISH HOTEL PVT LTD', '0'),
(180, 699, 'FAGUN CAKES', 'FAGUN CAKES', '0'),
(181, 1257, 'JMD FOODS', 'JMD FOODS', '0'),
(182, 534, 'LUCKY PROVISION STORES', 'LUCKY PROVISION STORES', '0'),
(183, 2479, 'SPRINKLES', 'SPRINKLES', '0'),
(184, 2798, 'AM BAKERS HOUSE', 'AM BAKERS HOUSE', '0'),
(185, 1709, 'GREEN CHILLY HOSPITALITY', 'GREEN CHILLY HOSPITALITY', '0'),
(186, 1591, 'BHADRICHA ENTERPRISE', 'BHADRICHA ENTERPRISE', '0'),
(187, 1967, 'FOODBITE (GOREGAON) (URD)', 'FOODBITE (GOREGAON) (URD)', '0'),
(188, 1329, 'GLOBAL FOODS ', 'GLOBAL FOODS ', '0'),
(189, 2053, 'MUMBAI AIRPORT LOUNGE SERVICE PVT LTD', 'MUMBAI AIRPORT LOUNGE SERVICE PVT LTD', '0'),
(190, 2864, 'DFINE MARKETING LLP', 'DFINE MARKETING LLP', '0'),
(191, 380, 'GREEN SOURCE AGRO PRODUCTS (CHUNKIES)', 'GREEN SOURCE AGRO PRODUCTS (CHUNKIES)', '0'),
(192, 462, 'LAXMI FOODS', 'LAXMI FOODS', '0'),
(193, 1035, 'FOOD WONDER', 'FOOD WONDER', '0'),
(194, 1978, 'R M MOULDE', 'R M MOULDE', '0'),
(195, 2154, 'CAFE O', 'CAFE O', '0'),
(196, 2869, 'CAFE 2 O', 'CAFE 2 O', '0'),
(197, 2675, 'SQR ENTERPRISES', 'SQR ENTERPRISES', '0'),
(198, 987, 'JAI HIND FINE DINE (SAYANI ROAD)', 'JAI HIND FINE DINE (SAYANI ROAD)', '0'),
(199, 590, 'FOOD ', 'FOOD ', '0'),
(200, 2005, 'GOPAL JI CONFECTIONERS (URD)', 'GOPAL JI CONFECTIONERS (URD)', '0'),
(201, 2088, 'PRASHANT CATERERS  ( LOWER PAREL)', 'PRASHANT CATERERS  ( LOWER PAREL)', '0'),
(202, 1977, 'COOL SUNDAY (URD)', 'COOL SUNDAY (URD)', '0'),
(203, 753, 'SHILPA RESTAURANT', 'SHILPA RESTAURANT', '0'),
(204, 1964, 'LANDMARK LEISURES ', 'LANDMARK LEISURES ', '0'),
(205, 1538, 'SAI FOODS AND BEVERAGES', 'SAI FOODS AND BEVERAGES', '0'),
(206, 1561, 'GEETA ENTERPRISES ( UN REG DEALER - NO VAT TIN )', 'GEETA ENTERPRISES ( UN REG DEALER - NO VAT TIN )', '0'),
(207, 2085, 'ANNAMRITA FOUNDATION', 'ANNAMRITA FOUNDATION', '0'),
(208, 657, 'RUCHI FOOD PLAZA PVT LTD', 'RUCHI FOOD PLAZA PVT LTD', '0'),
(209, 1534, 'DIVENA CAKE MOLD AND TOOLS', 'DIVENA CAKE MOLD AND TOOLS', '0'),
(210, 1019, 'EXEL ENTERPRISE', 'EXEL ENTERPRISE', '0'),
(211, 2176, 'JUNO\'S PIZZA', 'JUNO\'S PIZZA', '0'),
(212, 2910, 'BRUNCH ', 'BRUNCH ', '0'),
(213, 640, 'CAFE EDESIA', 'CAFE EDESIA', '0'),
(214, 2866, 'ENRICH', 'ENRICH', '0'),
(215, 2691, 'HOTEL MAYFAIR PVT LTD', 'HOTEL MAYFAIR PVT LTD', '0'),
(216, 2381, 'BRIO HOSPITALITY PVT LTD', 'BRIO HOSPITALITY PVT LTD', '0'),
(217, 1599, 'DELLA ADVENTURE ', 'DELLA ADVENTURE ', '0'),
(218, 656, 'MINI PUNJAB CATERING INDIA PVT LTD', 'MINI PUNJAB CATERING INDIA PVT LTD', '0'),
(219, 2447, 'I LOVE CAKES', 'I LOVE CAKES', '0'),
(220, 2872, 'GOOD TIME INCORPORATED', 'GOOD TIME INCORPORATED', '0'),
(221, 2452, 'ARA HOSPITALITY', 'ARA HOSPITALITY', '0'),
(222, 1912, 'BHAVESH JAYANT DESAI', 'BHAVESH JAYANT DESAI', '0'),
(223, 696, 'NEWYORKER, CHOWPATTY', 'NEWYORKER, CHOWPATTY', '0'),
(224, 1924, 'CLASSIC SURPRISE THE CAKE SHOP', 'CLASSIC SURPRISE THE CAKE SHOP', '0'),
(225, 2072, '1TABLESPOON', '1TABLESPOON', '0'),
(226, 2673, 'UMANG MOULDS ', 'UMANG MOULDS ', '0'),
(227, 1665, 'INDIRA CATERERS', 'INDIRA CATERERS', '0'),
(228, 1920, 'MARUTI ENTERPRISES', 'MARUTI ENTERPRISES', '0'),
(229, 1900, 'DEV CHEMICALS', 'DEV CHEMICALS', '0'),
(230, 2026, 'STEPPING STONE ENTERPRISE', 'STEPPING STONE ENTERPRISE', '0'),
(231, 416, 'MAROL BAKERY             RW', 'MAROL BAKERY             RW', '0'),
(232, 2315, 'BAKE FOR ME', 'BAKE FOR ME', '0'),
(233, 917, 'K.G ', 'K.G ', '0'),
(234, 2114, 'VIRAF ADAJANIA', 'VIRAF ADAJANIA', '0'),
(235, 1868, 'TRIDENT                                RC', 'TRIDENT                                RC', '0'),
(236, 2256, 'SHREEJI SALES MACHINES', 'SHREEJI SALES MACHINES', '0'),
(237, 440, 'ANNAPURNA', 'ANNAPURNA', '0'),
(238, 188, 'HOTEL MARINE PLAZA          RS', 'HOTEL MARINE PLAZA          RS', '0'),
(239, 1979, 'ANMOL FLUID CONTROL PRODUCTS PVT LTD.', 'ANMOL FLUID CONTROL PRODUCTS PVT LTD.', '0'),
(240, 183, 'SHELL INN INTERNATIONAL LTD', 'SHELL INN INTERNATIONAL LTD', '0'),
(241, 2605, 'THE BYKE HOSPITALITY LTD. (SURAJ PLAZA)', 'THE BYKE HOSPITALITY LTD. (SURAJ PLAZA)', '0'),
(242, 2316, 'LA CROSTA (THE WAFFILIST)', 'LA CROSTA (THE WAFFILIST)', '0'),
(243, 468, 'CAKE BITE', 'CAKE BITE', '0'),
(244, 471, 'ALL IN ONE SALES AGENCY PVT. LTD.', 'ALL IN ONE SALES AGENCY PVT. LTD.', '0'),
(245, 1670, 'SARYU PROPERTIES AND HOTELS PVT LTD', 'SARYU PROPERTIES AND HOTELS PVT LTD', '0'),
(246, 388, 'SEVEN SEVENS', 'SEVEN SEVENS', '0'),
(247, 2916, 'FLAMBOYANT FOODS', 'FLAMBOYANT FOODS', '0'),
(248, 280, 'HOTEL MIRAGE', 'HOTEL MIRAGE', '0'),
(249, 2716, 'GCC HOTEL PVT LTD', 'GCC HOTEL PVT LTD', '0'),
(250, 2915, 'VIJAYRAJ ASSOCIATES', 'VIJAYRAJ ASSOCIATES', '0'),
(251, 310, 'ASIAN HOTEL (W) LTD.', 'ASIAN HOTEL (W) LTD.', '0'),
(252, 200, 'DELICIOUS CAKE SHOP (URD)', 'DELICIOUS CAKE SHOP (URD)', '0'),
(253, 151, 'ITC GRAND CENTRAL', 'ITC GRAND CENTRAL', '0'),
(254, 861, 'URBAN STREET CAFE.', 'URBAN STREET CAFE.', '0'),
(255, 2064, 'LA VISTA', 'LA VISTA', '0'),
(256, 2868, 'MAHALXMI TRADING', 'MAHALXMI TRADING', '0'),
(257, 2922, 'M S LUVISH IT PIONEERS PVT LTD(KHYBER LOWERPAREL)', 'M S LUVISH IT PIONEERS PVT LTD(KHYBER LOWERPAREL)', '0'),
(258, 2368, 'DAAHARSH FOODS PRIVATE LIMITED ANDHERI', 'DAAHARSH FOODS PRIVATE LIMITED ANDHERI', '0'),
(259, 901, 'APURVA NATVAR PARIKH ', 'APURVA NATVAR PARIKH ', '0'),
(260, 1161, 'TRIDENT- THANE', 'TRIDENT- THANE', '0'),
(261, 254, 'HOTEL SUBA INTERNATIONAL', 'HOTEL SUBA INTERNATIONAL', '0'),
(262, 2159, 'CAKES N CANDLES (URD)', 'CAKES N CANDLES (URD)', '0'),
(263, 2314, 'SHARAYU ENTERPRISES', 'SHARAYU ENTERPRISES', '0'),
(264, 2912, 'AUGUST ASSORTMENTS', 'AUGUST ASSORTMENTS', '0'),
(265, 2932, 'NESCO FOODS', 'NESCO FOODS', '0'),
(266, 2938, 'FUSION CASTLE', 'FUSION CASTLE', '0'),
(267, 1560, 'SHILPA CATERERS PRIVATE LIMITED', 'SHILPA CATERERS PRIVATE LIMITED', '0'),
(268, 435, 'RICH ROCHE HOSPITALITY', 'RICH ROCHE HOSPITALITY', '0'),
(269, 3000, 'ACE ', 'ACE ', '0'),
(270, 1691, 'NIRVANA FOOD CONCEPT PVT LTD', 'NIRVANA FOOD CONCEPT PVT LTD', '0'),
(271, 353, 'ROSHAN BAKERY', 'ROSHAN BAKERY', '0'),
(272, 585, 'LEMON ', 'LEMON ', '0'),
(273, 2008, 'RUPESH JAIN', 'RUPESH JAIN', '0'),
(274, 751, 'CARAVAN HOTELS PVT LTD', 'CARAVAN HOTELS PVT LTD', '0'),
(275, 858, 'AMAR BAKERS ', 'AMAR BAKERS ', '0'),
(276, 1001, 'SUNSHINE FINE FOOD', 'SUNSHINE FINE FOOD', '0'),
(277, 2304, 'SWEET CASTLE', 'SWEET CASTLE', '0'),
(278, 2920, 'LAXMI HOMEMADE CHOCOLATE', 'LAXMI HOMEMADE CHOCOLATE', '0'),
(279, 1690, 'AADITYA VENTURES', 'AADITYA VENTURES', '0'),
(280, 1280, 'JOEYS PIZZA', 'JOEYS PIZZA', '0'),
(281, 2997, 'KENORITA COLLECTIONS PRIVATE LIMITED', 'KENORITA COLLECTIONS PRIVATE LIMITED', '0'),
(282, 1421, 'MADHAV BHUVAN VISHRANTI GRUH', 'MADHAV BHUVAN VISHRANTI GRUH', '0'),
(283, 1587, 'TASHKENT BAKERY', 'TASHKENT BAKERY', '0'),
(284, 3001, 'AMAD MARKETING', 'AMAD MARKETING', '0'),
(285, 2566, 'NUTAN SHIRODKAR (URD)', 'NUTAN SHIRODKAR (URD)', '0'),
(286, 169, 'A-1 SUPER BAZAAR', 'A-1 SUPER BAZAAR', '0'),
(287, 2463, 'R G FOODS', 'R G FOODS', '0'),
(288, 2797, 'HOTEL YOGI MIDTOWN', 'HOTEL YOGI MIDTOWN', '0'),
(289, 1881, 'SAROVAR VEG RESTAURANT', 'SAROVAR VEG RESTAURANT', '0'),
(290, 436, 'THE PATISSERIE HOME', 'THE PATISSERIE HOME', '0'),
(291, 170, 'BANGALORE IYENGAR ANDHERI EAST', 'BANGALORE IYENGAR ANDHERI EAST', '0'),
(292, 2185, 'LAYERS OF CAKE', 'LAYERS OF CAKE', '0'),
(293, 2735, 'SUN N SEA HOTEL PVT LTD', 'SUN N SEA HOTEL PVT LTD', '0'),
(294, 2186, 'THE LAB CAFE', 'THE LAB CAFE', '0'),
(295, 227, 'BANGALORE IYENGAR BAKERY KURLA', 'BANGALORE IYENGAR BAKERY KURLA', '0'),
(296, 808, 'CHIKITA SNACK BAR', 'CHIKITA SNACK BAR', '0'),
(297, 1137, 'HIRLO FOODS (URD)', 'HIRLO FOODS (URD)', '0'),
(298, 2925, 'LIVE BAKERY', 'LIVE BAKERY', '0'),
(299, 2849, 'WRAP CHEESE FOOD WITH BITE', 'WRAP CHEESE FOOD WITH BITE', '0'),
(300, 144, 'CANDIES', 'CANDIES', '0'),
(301, 407, 'AND CHILLIES', 'AND CHILLIES', '0'),
(302, 2794, 'MAA GAYATRI FOODS', 'MAA GAYATRI FOODS', '0'),
(303, 2271, 'FFABULAS KITCHEN', 'FFABULAS KITCHEN', '0'),
(304, 2765, 'PRM FOOD TECH', 'PRM FOOD TECH', '0'),
(305, 299, 'AMBROSIA', 'AMBROSIA', '0'),
(306, 885, 'RED VELVET CAKE SHOP', 'RED VELVET CAKE SHOP', '0'),
(307, 2895, 'PARTH GENERAL STORES', 'PARTH GENERAL STORES', '0'),
(308, 2477, 'POMONA', 'POMONA', '0'),
(309, 2532, 'FOODBERRY LLP (ANDHERI)', 'FOODBERRY LLP (ANDHERI)', '0'),
(310, 1078, 'CHEF\'S DELIGHT', 'CHEF\'S DELIGHT', '0'),
(311, 2237, 'PATEL TRADING', 'PATEL TRADING', '0'),
(312, 1575, 'GREENZ RESTAURANT (URD)KHAR', 'GREENZ RESTAURANT (URD)KHAR', '0'),
(313, 2921, 'MAHESHWARI FOODS ', 'MAHESHWARI FOODS ', '0'),
(314, 2919, 'V K FOOD ', 'V K FOOD ', '0'),
(315, 2144, 'CHOCO MAGIC', 'CHOCO MAGIC', '0'),
(316, 2989, 'M/S ARHAM (WOW)', 'M/S ARHAM (WOW)', '0'),
(317, 2900, 'GENEX MARKETING (CUSTOMER)', 'GENEX MARKETING (CUSTOMER)', '0'),
(318, 2420, 'NAUGHTY BITES', 'NAUGHTY BITES', '0'),
(319, 2133, 'PIZZA RIDE', 'PIZZA RIDE', '0'),
(320, 912, 'SYMPHONY KITCHENS PVT LTD', 'SYMPHONY KITCHENS PVT LTD', '0'),
(321, 276, 'SWAGAT CATERERS', 'SWAGAT CATERERS', '0'),
(322, 260, 'THE GOOD FOOD CO', 'THE GOOD FOOD CO', '0'),
(323, 2902, 'VINIT FOOD', 'VINIT FOOD', '0'),
(324, 2147, 'EXITO AMBROSIA LLP', 'EXITO AMBROSIA LLP', '0'),
(325, 2929, 'THE INDIAN BURGER', 'THE INDIAN BURGER', '0'),
(326, 2941, 'URBAN TAPRI CAFE', 'URBAN TAPRI CAFE', '0'),
(327, 1851, 'AMAR FAST FOOD', 'AMAR FAST FOOD', '0'),
(328, 371, 'CHOICE BAKERS', 'CHOICE BAKERS', '0'),
(329, 3004, 'HK THE CAKE SHOP', 'HK THE CAKE SHOP', '0'),
(330, 1178, 'LEE ANNE\'S KITCHEN (URD)', 'LEE ANNE\'S KITCHEN (URD)', '0'),
(331, 2205, 'THE MESSY HOUSE', 'THE MESSY HOUSE', '0'),
(332, 2370, 'MOM\'S MAGIC PIZZA AND MORE', 'MOM\'S MAGIC PIZZA AND MORE', '0'),
(333, 2661, 'CAFE AMIGOS', 'CAFE AMIGOS', '0'),
(334, 986, 'CHINESE ROOM/M.P.MALVAN KRISH HOSP/CAT SERVS', 'CHINESE ROOM/M.P.MALVAN KRISH HOSP/CAT SERVS', '0'),
(335, 2323, 'NARAYAN SALES CORPORATION', 'NARAYAN SALES CORPORATION', '0'),
(336, 2250, 'GLOBAL FRANCHISE HOSPITALITY LLP', 'GLOBAL FRANCHISE HOSPITALITY LLP', '0'),
(337, 2317, 'RALPHY\'S', 'RALPHY\'S', '0'),
(338, 2985, 'THE BAKERS', 'THE BAKERS', '0'),
(339, 833, 'PIZZA CAPRINA', 'PIZZA CAPRINA', '0'),
(340, 2405, 'EXOTIC BITES', 'EXOTIC BITES', '0'),
(341, 1981, 'SHREYA FOOD SERVICE', 'SHREYA FOOD SERVICE', '0'),
(342, 128, 'HUCKLBERRYS', 'HUCKLBERRYS', '0'),
(343, 2743, 'JUDE COLD STORAGE', 'JUDE COLD STORAGE', '0'),
(344, 446, 'BADRI MAHAL', 'BADRI MAHAL', '0'),
(345, 2644, 'MAGIC VENTURES', 'MAGIC VENTURES', '0'),
(346, 2343, 'MUSHMERRY CHOCOLATES LLP', 'MUSHMERRY CHOCOLATES LLP', '0'),
(347, 2557, 'STAR ONE PIZZA', 'STAR ONE PIZZA', '0'),
(348, 1504, 'BAKEZY (UNREGISTER DEALER - NO VAT TIN)', 'BAKEZY (UNREGISTER DEALER - NO VAT TIN)', '0'),
(349, 1701, 'BALAJI MODERN HOSPITALITY', 'BALAJI MODERN HOSPITALITY', '0'),
(350, 2536, 'SQUARES PIZZA AND CAFE LLP (MALAD)', 'SQUARES PIZZA AND CAFE LLP (MALAD)', '0'),
(351, 1875, 'FOOD INN', 'FOOD INN', '0'),
(352, 1738, 'UTSAV GROUP', 'UTSAV GROUP', '0'),
(353, 2708, 'GARZZO PVT LTD', 'GARZZO PVT LTD', '0'),
(354, 423, 'YOGURTBAY FOODS ', 'YOGURTBAY FOODS ', '0'),
(355, 344, 'GARYS                  RS', 'GARYS                  RS', '0'),
(356, 2909, 'MANGLORE COLD STORAGE', 'MANGLORE COLD STORAGE', '0'),
(357, 1355, 'SHREE GANESH TRADING CO.', 'SHREE GANESH TRADING CO.', '0'),
(358, 2779, 'SWAMI NARAYANMANDIR', 'SWAMI NARAYANMANDIR', '0'),
(359, 2390, 'BATULZ CAKES AND MORE', 'BATULZ CAKES AND MORE', '0'),
(360, 2236, 'MELTING MORSELS', 'MELTING MORSELS', '0'),
(361, 2844, 'THE BOMBAY CAFE', 'THE BOMBAY CAFE', '0'),
(362, 1762, 'FIDVI TRADING CO', 'FIDVI TRADING CO', '0'),
(363, 2245, 'MAGDALENA (MAZGAON)', 'MAGDALENA (MAZGAON)', '0'),
(364, 390, 'PIZZARIA HOUSE----KANDIVALI', 'PIZZARIA HOUSE----KANDIVALI', '0'),
(365, 1517, 'CAKE FANTASY', 'CAKE FANTASY', '0'),
(366, 1183, 'CHOCOLATE CENTRE', 'CHOCOLATE CENTRE', '0'),
(367, 410, 'BJR\'S', 'BJR\'S', '0'),
(368, 2106, 'HAYGREEV ENTERPRISES', 'HAYGREEV ENTERPRISES', '0'),
(369, 2640, 'LYFE KITCHEN', 'LYFE KITCHEN', '0'),
(370, 2881, 'SHREE MAYUR TEA ', 'SHREE MAYUR TEA ', '0'),
(371, 2339, 'AVANI ENTERPRISE ( APPLE CELEBRATION )', 'AVANI ENTERPRISE ( APPLE CELEBRATION )', '0'),
(372, 1133, 'CONEY ISLAND', 'CONEY ISLAND', '0'),
(373, 2436, 'N P FROZEN FOODS', 'N P FROZEN FOODS', '0'),
(374, 1884, 'LEAPING  WINDOWS CAFE (URD)', 'LEAPING  WINDOWS CAFE (URD)', '0'),
(375, 2084, 'METRO AGENCY', 'METRO AGENCY', '0'),
(376, 1387, 'BANSI LAKHNI (URD)', 'BANSI LAKHNI (URD)', '0'),
(377, 1113, 'CITY BAKERY                         RS â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'CITY BAKERY                         RS â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(378, 1326, 'CLEARFAST TRADING COMPANY PVT LTD', 'CLEARFAST TRADING COMPANY PVT LTD', '0'),
(379, 2787, 'COSMOS AGENCY', 'COSMOS AGENCY', '0'),
(380, 2149, 'EL POSTRE', 'EL POSTRE', '0'),
(381, 3008, 'FERNS SHIP SUPPLY CO', 'FERNS SHIP SUPPLY CO', '0'),
(382, 2821, 'GALAXY ENTERPRISES', 'GALAXY ENTERPRISES', '0'),
(383, 2179, 'MM FOODS', 'MM FOODS', '0'),
(384, 2885, 'RELISH FOODS AND HOSPITALITY', 'RELISH FOODS AND HOSPITALITY', '0'),
(385, 2170, 'SHREE DURGA CATERERS', 'SHREE DURGA CATERERS', '0'),
(386, 3009, 'SHREEJI VENDING SERVICES', 'SHREEJI VENDING SERVICES', '0'),
(387, 3010, 'THE CAKES ART CAKE SHOP', 'THE CAKES ART CAKE SHOP', '0'),
(388, 1467, 'YOGESH RAHATE (BYCULLA)', 'YOGESH RAHATE (BYCULLA)', '0'),
(389, 2386, '21', '21', '0'),
(390, 1874, 'AHURA CUISINE', 'AHURA CUISINE', '0'),
(391, 2978, 'BAKER\'S TOWN', 'BAKER\'S TOWN', '0'),
(392, 2251, 'BALAJI BEACH SHACK', 'BALAJI BEACH SHACK', '0'),
(393, 2060, 'CAKE SHOW PREMIUM CAKE HUB', 'CAKE SHOW PREMIUM CAKE HUB', '0'),
(394, 2484, 'DANIEL PATISSIER', 'DANIEL PATISSIER', '0'),
(395, 1906, 'FOOD TRUNK (URD)', 'FOOD TRUNK (URD)', '0'),
(396, 2364, 'FRESH O\'BAKE', 'FRESH O\'BAKE', '0'),
(397, 2800, 'GOUT ', 'GOUT ', '0'),
(398, 2127, 'IMBISS ( BANDR WEST)', 'IMBISS ( BANDR WEST)', '0'),
(399, 2778, 'KITTU\'S BALAJI', 'KITTU\'S BALAJI', '0'),
(400, 1973, 'K TEA AND SNACK', 'K TEA AND SNACK', '0'),
(401, 766, 'LITTE BITE CAKE SHOP KANDIVALI', 'LITTE BITE CAKE SHOP KANDIVALI', '0'),
(402, 2037, 'LUCIBELLO\'S', 'LUCIBELLO\'S', '0'),
(403, 1693, 'M M KURESHI (URD)', 'M M KURESHI (URD)', '0'),
(404, 707, 'NIRVAAN HOSPITALITY', 'NIRVAAN HOSPITALITY', '0'),
(405, 1430, 'SHEETAL DRY FRUIT CENTRE', 'SHEETAL DRY FRUIT CENTRE', '0'),
(406, 610, 'SHREE SAGAR VEG RESTAURANT', 'SHREE SAGAR VEG RESTAURANT', '0'),
(407, 2806, 'TUSITA FOOD AND HOSPITALITY', 'TUSITA FOOD AND HOSPITALITY', '0'),
(408, 2857, 'FOOD 1', 'FOOD 1', '0'),
(409, 2848, 'THE MIMU', 'THE MIMU', '0'),
(410, 2025, 'JAI HIND LUNCH HOME', 'JAI HIND LUNCH HOME', '0'),
(411, 1794, 'AROMA BAKE SHOP', 'AROMA BAKE SHOP', '0'),
(412, 2988, 'ROMEL AGENCIES', 'ROMEL AGENCIES', '0'),
(413, 1021, 'ARIES MARKETING', 'ARIES MARKETING', '0'),
(414, 1946, 'FIRDOUS SWEET CONFECTIONERY', 'FIRDOUS SWEET CONFECTIONERY', '0'),
(415, 1902, 'MB TRADING', 'MB TRADING', '0'),
(416, 229, 'CAKE OFF (URD)', 'CAKE OFF (URD)', '0'),
(417, 1748, 'HOTEL FARYAS COLLABA', 'HOTEL FARYAS COLLABA', '0'),
(418, 783, 'PANTRY HOSPITALITY                  RW', 'PANTRY HOSPITALITY                  RW', '0'),
(419, 1273, 'THE BAKING HUB', 'THE BAKING HUB', '0'),
(420, 1558, 'SHREE GANGOUR FOODS (INTERNATIONAL )LLP', 'SHREE GANGOUR FOODS (INTERNATIONAL )LLP', '0'),
(421, 277, 'THE SPOT', 'THE SPOT', '0'),
(422, 667, 'ARIF', 'ARIF', '0'),
(423, 168, 'SYMCO SALES PVT LTD.', 'SYMCO SALES PVT LTD.', '0'),
(424, 251, 'CATERING AND ALLIED', 'CATERING AND ALLIED', '0'),
(425, 1980, 'THE BAKERS PARADISE', 'THE BAKERS PARADISE', '0'),
(426, 2226, 'KYRASHA HOSPITALITY', 'KYRASHA HOSPITALITY', '0'),
(427, 422, 'NEELAM PROVISION STORE', 'NEELAM PROVISION STORE', '0'),
(428, 160, 'LE CAFE(JEWEL OF CHEMBUR)', 'LE CAFE(JEWEL OF CHEMBUR)', '0'),
(429, 853, 'D ', 'D ', '0'),
(430, 2718, 'HEDGE HOTELS (I) PVT LTD', 'HEDGE HOTELS (I) PVT LTD', '0'),
(431, 221, 'PATISSIERIE CAKES R US ( URD)', 'PATISSIERIE CAKES R US ( URD)', '0'),
(432, 2277, 'SEARCH ROUTE (WOWFILLSS)', 'SEARCH ROUTE (WOWFILLSS)', '0'),
(433, 2223, 'BHARAT HOTELS LIMITED', 'BHARAT HOTELS LIMITED', '0'),
(434, 1271, 'O.K. HOSPITALITY LLP', 'O.K. HOSPITALITY LLP', '0'),
(435, 786, 'SOUL KONNECT HOSPITALITY LLP', 'SOUL KONNECT HOSPITALITY LLP', '0'),
(436, 2465, 'ZIKRAH\'Z KOKO KRAFT', 'ZIKRAH\'Z KOKO KRAFT', '0'),
(437, 796, 'KRISHNA ENTERPRISES (BHANDUP)', 'KRISHNA ENTERPRISES (BHANDUP)', '0'),
(438, 2093, 'HARYANI VENTURE', 'HARYANI VENTURE', '0'),
(439, 171, 'SMB BAKERS', 'SMB BAKERS', '0'),
(440, 184, 'UNCLE SHOP', 'UNCLE SHOP', '0'),
(441, 291, 'GANESH STORES', 'GANESH STORES', '0'),
(442, 1799, 'THE CHOCOLATE SPOON COMPANY PVT LTD (LOWER PAREL)', 'THE CHOCOLATE SPOON COMPANY PVT LTD (LOWER PAREL)', '0'),
(443, 829, 'BREW WORKS PVT LTDâ‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'BREW WORKS PVT LTDâ‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(444, 189, 'BUNTS HOTELS', 'BUNTS HOTELS', '0'),
(445, 1818, 'BUSHRAVI HOSPITALITY LLP', 'BUSHRAVI HOSPITALITY LLP', '0'),
(446, 2810, 'GENERAL MILLS INDIA PVT LTD', 'GENERAL MILLS INDIA PVT LTD', '0'),
(447, 165, 'FARIDI IMPEX PVT LTD(CUST)', 'FARIDI IMPEX PVT LTD(CUST)', '0'),
(448, 220, 'KAMAT HOTELS (INDIA) LTD (VITS HOTEL)', 'KAMAT HOTELS (INDIA) LTD (VITS HOTEL)', '0'),
(449, 1138, 'INDIANAPOLI HOSPITALITY PVT LTD', 'INDIANAPOLI HOSPITALITY PVT LTD', '0'),
(450, 2491, 'OCCASSION CAKE SHOP PVT LTD - KANDIVALI EAST', 'OCCASSION CAKE SHOP PVT LTD - KANDIVALI EAST', '0'),
(451, 1671, 'M/S THIYA BISTRO AND CAFE', 'M/S THIYA BISTRO AND CAFE', '0'),
(452, 239, 'UPPER CRUST FOODS PVT LTD.,', 'UPPER CRUST FOODS PVT LTD.,', '0'),
(453, 288, 'NC FOODS', 'NC FOODS', '0'),
(454, 252, 'GREEN WOODS PALACES AND RESORTS PVT. LTD', 'GREEN WOODS PALACES AND RESORTS PVT. LTD', '0'),
(455, 285, 'CARRY SALES AGENCY CUSTOMER', 'CARRY SALES AGENCY CUSTOMER', '0'),
(456, 2745, 'HARSH SHAH', 'HARSH SHAH', '0'),
(457, 906, 'HARSH CHOCOLATES', 'HARSH CHOCOLATES', '0'),
(458, 2293, 'IJB HOTELS PVT LTD', 'IJB HOTELS PVT LTD', '0'),
(459, 1458, 'VK CHOCOLATE FOUNTAIN AND ICECREAM (URD)', 'VK CHOCOLATE FOUNTAIN AND ICECREAM (URD)', '0'),
(460, 892, 'MIRA TRADING COMPANY', 'MIRA TRADING COMPANY', '0'),
(461, 836, 'LE 15 PATISSERIE PRIVATE LTD', 'LE 15 PATISSERIE PRIVATE LTD', '0'),
(462, 2077, 'ABM MARKETING CELL PVT LTD', 'ABM MARKETING CELL PVT LTD', '0'),
(463, 1071, 'JUGHEADS HOTELS ', 'JUGHEADS HOTELS ', '0'),
(464, 257, 'JUHU RESORTS ', 'JUHU RESORTS ', '0'),
(465, 1879, 'THIMEET BISTRO AND CAFE LLP', 'THIMEET BISTRO AND CAFE LLP', '0'),
(466, 230, 'SHALUZ DELIGHTZ (URD)', 'SHALUZ DELIGHTZ (URD)', '0'),
(467, 1093, 'INDEPENDENCE BREWING COMPANY PVT LTD', 'INDEPENDENCE BREWING COMPANY PVT LTD', '0'),
(468, 2581, 'NEW PATEL TRADING CO.', 'NEW PATEL TRADING CO.', '0'),
(469, 2838, 'QUALITY CHECK OUT', 'QUALITY CHECK OUT', '0'),
(470, 2031, 'II WALLS HOSPITALITY', 'II WALLS HOSPITALITY', '0'),
(471, 1853, 'LAKE VIEW HOSPITALITY', 'LAKE VIEW HOSPITALITY', '0'),
(472, 1142, 'PBS GOURMET FOODS PVT LTD', 'PBS GOURMET FOODS PVT LTD', '0'),
(473, 1105, 'SQUARE ONE HOSPITALITY LLP', 'SQUARE ONE HOSPITALITY LLP', '0'),
(474, 2841, 'BARBEQUE NATIONAL HOSPITALITY LIMITED TURBHE', 'BARBEQUE NATIONAL HOSPITALITY LIMITED TURBHE', '0'),
(475, 1672, 'BN ENTERPRISES', 'BN ENTERPRISES', '0'),
(476, 2782, 'M/S CHILIAD PROCONS PVT LTD', 'M/S CHILIAD PROCONS PVT LTD', '0'),
(477, 1248, 'KNR ENTERPRISES', 'KNR ENTERPRISES', '0'),
(478, 348, 'EAST END DELI', 'EAST END DELI', '0'),
(479, 995, 'AURA PACKAGING', 'AURA PACKAGING', '0'),
(480, 1232, 'THE LEELA', 'THE LEELA', '0'),
(481, 234, 'DCC FOODS', 'DCC FOODS', '0'),
(482, 195, 'UNICO FOOD LLP', 'UNICO FOOD LLP', '0'),
(483, 1793, 'MASSIVE RESTAURANT PRIVATE LIMITED(FARZI CAFE)', 'MASSIVE RESTAURANT PRIVATE LIMITED(FARZI CAFE)', '0'),
(484, 172, 'PALM GROOVE BEACH HOTEL', 'PALM GROOVE BEACH HOTEL', '0'),
(485, 1060, 'SMAAASH ENTERTAINMENT PVT. LTD. , LOWER PAREL', 'SMAAASH ENTERTAINMENT PVT. LTD. , LOWER PAREL', '0'),
(486, 2833, 'AZURE HOSPITALITY PVT LTD', 'AZURE HOSPITALITY PVT LTD', '0'),
(487, 290, 'EPOCH ENTERPRISES', 'EPOCH ENTERPRISES', '0'),
(488, 718, 'FRENCH CONNETION MALAD                   RW', 'FRENCH CONNETION MALAD                   RW', '0'),
(489, 2840, 'MASAFI TRADING CO', 'MASAFI TRADING CO', '0'),
(490, 1847, 'PROFESSIONAL CATERING SERVICES', 'PROFESSIONAL CATERING SERVICES', '0'),
(491, 1842, 'SAIKRIPA FOODS SERVICES PVT LTD-GULMOHAR REST IIT', 'SAIKRIPA FOODS SERVICES PVT LTD-GULMOHAR REST IIT', '0'),
(492, 177, 'OVEN FRESH BAKERY--DADAR', 'OVEN FRESH BAKERY--DADAR', '0'),
(493, 1821, 'VITHAL RESTAURANT', 'VITHAL RESTAURANT', '0'),
(494, 803, 'KRISHNA PALACE HOTEL', 'KRISHNA PALACE HOTEL', '0'),
(495, 1798, 'ASHIMO CHEMICALS', 'ASHIMO CHEMICALS', '0'),
(496, 271, 'EDDIES HOSPITALITY PRIVATE LIMITED', 'EDDIES HOSPITALITY PRIVATE LIMITED', '0'),
(497, 219, 'TANASH FOOD PRODUCTS PVT .LTD', 'TANASH FOOD PRODUCTS PVT .LTD', '0'),
(498, 2695, 'GENESIS RESORT PVT. LTD', 'GENESIS RESORT PVT. LTD', '0'),
(499, 2911, 'THE BAKERS WORLD', 'THE BAKERS WORLD', '0'),
(500, 2719, 'BHAVI CHOCOLATESS', 'BHAVI CHOCOLATESS', '0'),
(501, 1611, 'DELICIOUS CAKE SHOP (AMBERNATH)', 'DELICIOUS CAKE SHOP (AMBERNATH)', '0'),
(502, 309, 'KA HOSPITALITY PVT LTD', 'KA HOSPITALITY PVT LTD', '0'),
(503, 326, 'MAGIC MASTI', 'MAGIC MASTI', '0'),
(504, 997, 'S.S. ENTERPRISES (LOWER PAREL)', 'S.S. ENTERPRISES (LOWER PAREL)', '0'),
(505, 427, 'SURINDER CATERING SERVICES', 'SURINDER CATERING SERVICES', '0'),
(506, 1843, 'GREEN BASKET (SION)', 'GREEN BASKET (SION)', '0'),
(507, 2898, 'KNR FOODS PRIVATE LIMITED', 'KNR FOODS PRIVATE LIMITED', '0'),
(508, 246, 'MC RONNIES FOODS PVT LTD', 'MC RONNIES FOODS PVT LTD', '0'),
(509, 2763, 'RADISSON MUMBAI ANDH MIDC', 'RADISSON MUMBAI ANDH MIDC', '0'),
(510, 295, 'NOOR BAKERY', 'NOOR BAKERY', '0'),
(511, 913, 'BOMBAY FOOD TRUCK', 'BOMBAY FOOD TRUCK', '0'),
(512, 1848, 'ASSOCIATED HOSPITALITY ', 'ASSOCIATED HOSPITALITY ', '0'),
(513, 296, 'DEVARSHREE ENTERPRISES', 'DEVARSHREE ENTERPRISES', '0'),
(514, 694, 'FRENCH CONNECTION KANDIWALI                 RW', 'FRENCH CONNECTION KANDIWALI                 RW', '0'),
(515, 2811, 'JAIN TRADERS', 'JAIN TRADERS', '0'),
(516, 2992, 'SAURASHTRA\'S SWEET CRUNCH', 'SAURASHTRA\'S SWEET CRUNCH', '0'),
(517, 958, 'SID HOSPITALITY (POT PORI)', 'SID HOSPITALITY (POT PORI)', '0'),
(518, 2366, 'THE SUPER HERO CAFE', 'THE SUPER HERO CAFE', '0'),
(519, 514, 'HOME MAKERS', 'HOME MAKERS', '0'),
(520, 376, 'INDULGE                            RW', 'INDULGE                            RW', '0'),
(521, 208, 'OM ENTERPRISES', 'OM ENTERPRISES', '0'),
(522, 272, 'GOLDEN RESTUARANT', 'GOLDEN RESTUARANT', '0'),
(523, 265, 'KIRAN KOTAK ', 'KIRAN KOTAK ', '0'),
(524, 255, 'SID HOSPITALITY PVT LTD BANDRA WEST', 'SID HOSPITALITY PVT LTD BANDRA WEST', '0'),
(525, 1067, 'SQUAREMEAL FOODS PVT LTD', 'SQUAREMEAL FOODS PVT LTD', '0'),
(526, 235, 'THEOBROMA FOODS PVT LTD', 'THEOBROMA FOODS PVT LTD', '0'),
(527, 2183, 'CHAWLA AGENCY', 'CHAWLA AGENCY', '0'),
(528, 2262, 'DOUGHKRAFT FOOD LLP', 'DOUGHKRAFT FOOD LLP', '0'),
(529, 2692, 'AMBASSADOR AJANTA HOTEL - AURANGABAD', 'AMBASSADOR AJANTA HOTEL - AURANGABAD', '0'),
(530, 2602, 'FLAMING 5', 'FLAMING 5', '0'),
(531, 372, 'MIRAMAHAL PREMISES PVT. LTD.', 'MIRAMAHAL PREMISES PVT. LTD.', '0'),
(532, 903, 'HOTEL RISHI CORNER (I) PVT LTD', 'HOTEL RISHI CORNER (I) PVT LTD', '0'),
(533, 1882, 'WESTERN MARKETING', 'WESTERN MARKETING', '0'),
(534, 284, 'ATLAS HOSPITALITY PVT LTD', 'ATLAS HOSPITALITY PVT LTD', '0'),
(535, 1549, 'BALAJI VADA PAV', 'BALAJI VADA PAV', '0'),
(536, 2785, 'INTERNATIONAL AIRPORT HOTELS AND RESORT PVT LTD', 'INTERNATIONAL AIRPORT HOTELS AND RESORT PVT LTD', '0'),
(537, 2706, 'AKASH THE SWEET CORNER', 'AKASH THE SWEET CORNER', '0'),
(538, 2730, 'AYUSH HOMEMADE CHOCOLATE', 'AYUSH HOMEMADE CHOCOLATE', '0'),
(539, 443, 'BOULANGERIE AND PATISSERIR LLP', 'BOULANGERIE AND PATISSERIR LLP', '0'),
(540, 2703, 'K D FOODS', 'K D FOODS', '0'),
(541, 312, 'MANSURI CATERERS', 'MANSURI CATERERS', '0'),
(542, 397, 'GOLDEN BUTTERFLY ENTERPRISES             RW', 'GOLDEN BUTTERFLY ENTERPRISES             RW', '0'),
(543, 905, 'MAHESH  LUNCH HOME', 'MAHESH  LUNCH HOME', '0'),
(544, 198, 'TAJ MAHAL PALACE                 RS', 'TAJ MAHAL PALACE                 RS', '0'),
(545, 300, 'BURGER BITE HOUSE SANTACRUZ WEST', 'BURGER BITE HOUSE SANTACRUZ WEST', '0'),
(546, 1838, 'FCM', 'FCM', '0'),
(547, 268, 'IB HOSPITALITY PVT LTD', 'IB HOSPITALITY PVT LTD', '0'),
(548, 2676, 'SMAAASH LEISURE LIMITED', 'SMAAASH LEISURE LIMITED', '0'),
(549, 2255, 'EMIRATES FOODS', 'EMIRATES FOODS', '0'),
(550, 1800, 'PUROHIT FOOD PRODUCTS PVT. LTD.', 'PUROHIT FOOD PRODUCTS PVT. LTD.', '0'),
(551, 2517, 'CAKES AND ROLLS', 'CAKES AND ROLLS', '0'),
(552, 899, 'MODERN STORES', 'MODERN STORES', '0'),
(553, 2733, 'AAKASH THE SWEET CORNER', 'AAKASH THE SWEET CORNER', '0'),
(554, 1460, 'STEAMY MUGS (UNREGISTER DEALER - NO VAT TIN)', 'STEAMY MUGS (UNREGISTER DEALER - NO VAT TIN)', '0'),
(555, 419, 'THE FOOD COMPANY', 'THE FOOD COMPANY', '0'),
(556, 2712, 'TRISHA DECORS', 'TRISHA DECORS', '0'),
(557, 1706, 'CAKES ', 'CAKES ', '0'),
(558, 1072, 'ESPRESSOTECH VENDING SOLUTION', 'ESPRESSOTECH VENDING SOLUTION', '0'),
(559, 2457, 'J S BURGERS', 'J S BURGERS', '0'),
(560, 2425, 'SALASAR LIFESTYLE PVT LTD', 'SALASAR LIFESTYLE PVT LTD', '0'),
(561, 2523, 'BROWNWALL FOODS PVT LTD', 'BROWNWALL FOODS PVT LTD', '0'),
(562, 1579, 'YUMMY DELIGHT CAKE SHOP', 'YUMMY DELIGHT CAKE SHOP', '0'),
(563, 2424, 'CREAMY DREAMY', 'CREAMY DREAMY', '0'),
(564, 1122, 'GOLDEN STORES', 'GOLDEN STORES', '0'),
(565, 894, 'HEALTHY LIFE FOODTECH PVT LTD ( CUSTOMER)', 'HEALTHY LIFE FOODTECH PVT LTD ( CUSTOMER)', '0'),
(566, 311, 'JEEVAN RESTAURANTS', 'JEEVAN RESTAURANTS', '0'),
(567, 294, 'NILAM GIRDHAR               RW', 'NILAM GIRDHAR               RW', '0'),
(568, 1674, 'SANTINOS FAST FOODS PVT LTD', 'SANTINOS FAST FOODS PVT LTD', '0'),
(569, 2374, 'ZAM ZAM STORES', 'ZAM ZAM STORES', '0'),
(570, 2482, 'RAUT ENTERPRISES', 'RAUT ENTERPRISES', '0'),
(571, 2594, 'ATOMIUM FOODWORKS LLP', 'ATOMIUM FOODWORKS LLP', '0'),
(572, 3011, 'PERCEPT SYSTEMS', 'PERCEPT SYSTEMS', '0'),
(573, 2516, 'SRA FOOD', 'SRA FOOD', '0'),
(574, 2140, 'AAREY SARITA FRANKY', 'AAREY SARITA FRANKY', '0'),
(575, 3012, 'SCOOP ', 'SCOOP ', '0'),
(576, 2689, 'SUGAREES PARADISE CAKE SHOP', 'SUGAREES PARADISE CAKE SHOP', '0'),
(577, 1916, 'SUPERB LIVE BAKERY ', 'SUPERB LIVE BAKERY ', '0'),
(578, 675, 'SWEET LOUNGE', 'SWEET LOUNGE', '0'),
(579, 3013, 'SYED  ASIF', 'SYED  ASIF', '0'),
(580, 2792, 'ARAR ENTERPRISES(LONDON BUBBLE)', 'ARAR ENTERPRISES(LONDON BUBBLE)', '0'),
(581, 2693, 'KOOVARJI ENTERPRISE LLP(LONDON BUBBLE)', 'KOOVARJI ENTERPRISE LLP(LONDON BUBBLE)', '0'),
(582, 3014, 'RA ENTERPRISES  (LONDON BUBBLE CO)', 'RA ENTERPRISES  (LONDON BUBBLE CO)', '0'),
(583, 405, 'CS PICARSDO CAKE SHOP       RWâ‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'CS PICARSDO CAKE SHOP       RWâ‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(584, 1854, 'FLAVOUR  POT FOODS LLP ( TAFTOON BKC)', 'FLAVOUR  POT FOODS LLP ( TAFTOON BKC)', '0'),
(585, 2993, 'AK DELIGHT', 'AK DELIGHT', '0'),
(586, 2720, 'A STAR BURGERS', 'A STAR BURGERS', '0'),
(587, 3015, 'R A J HOSPITALITY', 'R A J HOSPITALITY', '0'),
(588, 2983, 'XOTIK CAFE', 'XOTIK CAFE', '0'),
(589, 3016, 'ADAMO HOSPITALITY LLP', 'ADAMO HOSPITALITY LLP', '0'),
(590, 1634, 'AROMA THE CAKE SHOP', 'AROMA THE CAKE SHOP', '0'),
(591, 3017, 'CAFE UNIVERSAL', 'CAFE UNIVERSAL', '0'),
(592, 2884, 'DIEM CHOCOLATES ', 'DIEM CHOCOLATES ', '0'),
(593, 2233, 'HILONIS CAKES', 'HILONIS CAKES', '0'),
(594, 3018, 'LA PATISSERIE', 'LA PATISSERIE', '0'),
(595, 2337, 'LGE FOODS LLP', 'LGE FOODS LLP', '0'),
(596, 2977, 'SATHYARUCHI CATERING AND MANAGEMENT SERVICES', 'SATHYARUCHI CATERING AND MANAGEMENT SERVICES', '0'),
(597, 2324, 'YELLO FOOD', 'YELLO FOOD', '0'),
(598, 2485, 'LABELLA CAFE', 'LABELLA CAFE', '0'),
(599, 2467, 'HARIHAR OIL TRADERS CUSTOMER', 'HARIHAR OIL TRADERS CUSTOMER', '0'),
(600, 1959, 'KESA\'S', 'KESA\'S', '0'),
(601, 930, 'VIVANTA BY TAJ', 'VIVANTA BY TAJ', '0'),
(602, 2943, 'LA PATISSERIE GALLERY  PVT LTD  (SURAT )', 'LA PATISSERIE GALLERY  PVT LTD  (SURAT )', '0'),
(603, 2146, 'SAHAJ ENTERPRISES', 'SAHAJ ENTERPRISES', '0'),
(604, 2942, 'ASHISH SONI', 'ASHISH SONI', '0'),
(605, 2888, 'BANGALORE IYANGER BAKERY ', 'BANGALORE IYANGER BAKERY ', '0'),
(606, 2556, 'BANGLORE IYANGAR BAKERY (GHATKOPAR) URD', 'BANGLORE IYANGAR BAKERY (GHATKOPAR) URD', '0'),
(607, 2862, 'CAKE 4 U', 'CAKE 4 U', '0'),
(608, 1487, 'GREENZ RESTUARANT POWAI', 'GREENZ RESTUARANT POWAI', '0'),
(609, 960, 'HEXA BYTE CAKE SHOP', 'HEXA BYTE CAKE SHOP', '0'),
(610, 2367, 'RAJESH ENTERPRISES', 'RAJESH ENTERPRISES', '0'),
(611, 2431, 'THE MAGIC CAKE SHOP', 'THE MAGIC CAKE SHOP', '0'),
(612, 1246, 'THE WHITE CREAME', 'THE WHITE CREAME', '0'),
(613, 3019, 'ZUST BURNS', 'ZUST BURNS', '0'),
(614, 1922, 'ETERNAL BLISS (URD)', 'ETERNAL BLISS (URD)', '0'),
(615, 2499, 'BANGALORE IYANGANR\'S BAKERY- MORARJI NAGAR POWAI', 'BANGALORE IYANGANR\'S BAKERY- MORARJI NAGAR POWAI', '0'),
(616, 2762, 'FROZEN ZONE', 'FROZEN ZONE', '0'),
(617, 464, 'MYEISHA FOOD SOLUTIONS LLP', 'MYEISHA FOOD SOLUTIONS LLP', '0'),
(618, 908, 'SHREE GANESH AGENCY', 'SHREE GANESH AGENCY', '0'),
(619, 3020, 'JUICE NEST', 'JUICE NEST', '0'),
(620, 2622, 'MUFFINOS', 'MUFFINOS', '0'),
(621, 3021, 'QUALIA HOSPITALITY PVT. LTD.', 'QUALIA HOSPITALITY PVT. LTD.', '0'),
(622, 3022, 'TOFFEE', 'TOFFEE', '0'),
(623, 703, 'SHASHIKANT RESTAURANT ', 'SHASHIKANT RESTAURANT ', '0'),
(624, 1617, 'R M DISTRIBUTORS', 'R M DISTRIBUTORS', '0'),
(625, 1824, 'CHOCOLATE HEAVAN PVT LTD', 'CHOCOLATE HEAVAN PVT LTD', '0'),
(626, 3023, 'KHUSHI FOODS', 'KHUSHI FOODS', '0'),
(627, 1745, 'CASH SALE UNI FOODS', 'CASH SALE UNI FOODS', '0'),
(628, 2537, 'THE HIGHNESS ENTERPRISES', 'THE HIGHNESS ENTERPRISES', '0'),
(629, 2265, 'M/S PARTY (GHATKOPAR)', 'M/S PARTY (GHATKOPAR)', '0'),
(630, 2266, 'M/S PARTY (MATUNGA)', 'M/S PARTY (MATUNGA)', '0'),
(631, 2439, 'KAPCO BANQUETS AND CATERING PVT. LTD.', 'KAPCO BANQUETS AND CATERING PVT. LTD.', '0'),
(632, 1603, 'CHOC LE', 'CHOC LE', '0'),
(633, 1235, 'EDEN BAKERY                RW', 'EDEN BAKERY                RW', '0'),
(634, 579, 'THE AMBASSADOR\'S SKY CHEF            RW', 'THE AMBASSADOR\'S SKY CHEF            RW', '0'),
(635, 1293, 'JHAMA SWEETS', 'JHAMA SWEETS', '0'),
(636, 1040, 'FOOD VISTA INDIA PVT. LTD.', 'FOOD VISTA INDIA PVT. LTD.', '0'),
(637, 2259, 'FOODLINK SERVICES (INDIA) PVT. LTD.', 'FOODLINK SERVICES (INDIA) PVT. LTD.', '0'),
(638, 639, 'YELLOW BANANA FOOD', 'YELLOW BANANA FOOD', '0'),
(639, 408, 'DENISH FOOD PRODUCTS                    RC', 'DENISH FOOD PRODUCTS                    RC', '0'),
(640, 517, 'DISH HOSPITALITY', 'DISH HOSPITALITY', '0'),
(641, 460, 'THE IRISH HOUSE FOOD AND BEVERAGES PVT LTD', 'THE IRISH HOUSE FOOD AND BEVERAGES PVT LTD', '0'),
(642, 1832, 'MELUHA THE FERN A DIV OF HGP COMMUNITY PVT LTD', 'MELUHA THE FERN A DIV OF HGP COMMUNITY PVT LTD', '0'),
(643, 1710, 'HEERAMANI PACKAGING', 'HEERAMANI PACKAGING', '0'),
(644, 526, 'BRAND ARBOR SERVICE ', 'BRAND ARBOR SERVICE ', '0'),
(645, 2326, 'NYC HOSPITALITY', 'NYC HOSPITALITY', '0'),
(646, 574, 'INNOVATIVE FOOD SOLUTION', 'INNOVATIVE FOOD SOLUTION', '0'),
(647, 2573, 'SAIMITHAM JIO (WOW)', 'SAIMITHAM JIO (WOW)', '0'),
(648, 1755, 'CHOCOLATE ', 'CHOCOLATE ', '0'),
(649, 1829, 'KANAKIA HOTELS ', 'KANAKIA HOTELS ', '0'),
(650, 2768, 'PRANTAN LEISURE AND HOSPITALITY PVT LTD', 'PRANTAN LEISURE AND HOSPITALITY PVT LTD', '0'),
(651, 1656, 'TAJ SATS AIR CATERING', 'TAJ SATS AIR CATERING', '0'),
(652, 2347, 'FLIPSTONE HOSPITALITY PVT LTD', 'FLIPSTONE HOSPITALITY PVT LTD', '0'),
(653, 2611, 'AUM FOOD ENTERPRISES', 'AUM FOOD ENTERPRISES', '0'),
(654, 1940, 'TRAVEL FOOD SERVICES', 'TRAVEL FOOD SERVICES', '0'),
(655, 2396, 'THE GOOD FOOD PEOPLE', 'THE GOOD FOOD PEOPLE', '0'),
(656, 1408, 'GARNISH FOODS', 'GARNISH FOODS', '0'),
(657, 1827, 'BRIGHT FNB', 'BRIGHT FNB', '0'),
(658, 708, 'STAR ANISE                        RC', 'STAR ANISE                        RC', '0'),
(659, 1488, 'BAKIN PACKIN', 'BAKIN PACKIN', '0'),
(660, 1038, 'LITE BITE TRAVEL FOOD PVT LTD', 'LITE BITE TRAVEL FOOD PVT LTD', '0'),
(661, 620, 'KHANNA HOTELS PVT. LTD.                      RW', 'KHANNA HOTELS PVT. LTD.                      RW', '0'),
(662, 641, 'EMPORIO PATISSERIE PVT.                   RC', 'EMPORIO PATISSERIE PVT.                   RC', '0'),
(663, 2065, 'HOTEL RODAS - HGP COMMUNITY PVT LTD', 'HOTEL RODAS - HGP COMMUNITY PVT LTD', '0'),
(664, 510, 'K.RAHEJA CORP PVT LTD( THE RESORT)', 'K.RAHEJA CORP PVT LTD( THE RESORT)', '0'),
(665, 2282, 'DEGUSTIBUS HOSPITALITY PVT LTD', 'DEGUSTIBUS HOSPITALITY PVT LTD', '0'),
(666, 2874, 'GALAXY ENTERTAINMENT CORPORATION LTD FOOD HALL', 'GALAXY ENTERTAINMENT CORPORATION LTD FOOD HALL', '0'),
(667, 2777, 'CAKERS ', 'CAKERS ', '0'),
(668, 552, 'NOT JUST DESSERTS                    RC', 'NOT JUST DESSERTS                    RC', '0'),
(669, 2076, 'JHAMA ENTERPRISE', 'JHAMA ENTERPRISE', '0'),
(670, 2646, 'OMKAR FOOD ', 'OMKAR FOOD ', '0'),
(671, 688, 'ASRANI INNS  ', 'ASRANI INNS  ', '0'),
(672, 1983, 'SEVEN FLAVORS ENTERPRISES', 'SEVEN FLAVORS ENTERPRISES', '0'),
(673, 2095, 'EIH LIMITED', 'EIH LIMITED', '0'),
(674, 2669, 'CAFFEINE INDIAN CAFE PVT LTD', 'CAFFEINE INDIAN CAFE PVT LTD', '0'),
(675, 951, 'GINAS CAKE', 'GINAS CAKE', '0'),
(676, 1781, 'RELISH FOODS ', 'RELISH FOODS ', '0'),
(677, 1713, 'RAJAN RAKESH ', 'RAJAN RAKESH ', '0'),
(678, 456, 'NAVKAR ENTERPRISES                RW', 'NAVKAR ENTERPRISES                RW', '0'),
(679, 2647, 'SLURRP FOODWORKS (WOW)', 'SLURRP FOODWORKS (WOW)', '0'),
(680, 2615, 'EFFINGUT BREWERS PVT LTD', 'EFFINGUT BREWERS PVT LTD', '0'),
(681, 475, 'ZAHRA HOSPITALITY PVT. LTD.', 'ZAHRA HOSPITALITY PVT. LTD.', '0'),
(682, 1604, 'CS SWEET PASSIONS', 'CS SWEET PASSIONS', '0'),
(683, 1936, 'EXCEL ENTERPRIESE', 'EXCEL ENTERPRIESE', '0'),
(684, 609, 'VIAAN DIVYA SAGAR FOOD PLAZA', 'VIAAN DIVYA SAGAR FOOD PLAZA', '0'),
(685, 1952, 'DELICIAE', 'DELICIAE', '0'),
(686, 1662, 'CAKE BAKE THE CAKE STUDIO', 'CAKE BAKE THE CAKE STUDIO', '0'),
(687, 1867, 'MIRAH HOSPITALITY ', 'MIRAH HOSPITALITY ', '0'),
(688, 512, 'FOODSTUFF ENTERPRISE L L P', 'FOODSTUFF ENTERPRISE L L P', '0'),
(689, 1411, 'MARS ENTERPRISES ', 'MARS ENTERPRISES ', '0'),
(690, 2208, 'SRINATHJIS CUISINES PVT LTD', 'SRINATHJIS CUISINES PVT LTD', '0'),
(691, 622, 'OVEN TREAT', 'OVEN TREAT', '0'),
(692, 450, 'ANJALI SERVICES PVT LTD', 'ANJALI SERVICES PVT LTD', '0'),
(693, 698, 'DREA IMPEX', 'DREA IMPEX', '0'),
(694, 1492, 'FASHION RESTO BAR ', 'FASHION RESTO BAR ', '0'),
(695, 398, 'SHRUTI BHARADWAJ', 'SHRUTI BHARADWAJ', '0'),
(696, 2268, 'FOODLINK SERVICES I PVT LTD ( BANQUET DIV â€“ JADE GARDEN)', 'FOODLINK SERVICES I PVT LTD ( BANQUET DIV â€“ JADE GARDEN)', '0'),
(697, 616, 'SAI KRIPA FOOD SERVICES PVT LTD', 'SAI KRIPA FOOD SERVICES PVT LTD', '0'),
(698, 2986, 'KUBER HEATH FOOD ', 'KUBER HEATH FOOD ', '0'),
(699, 955, 'PENINSULA  NEXT', 'PENINSULA  NEXT', '0'),
(700, 536, 'GREEN BASKET VASHI', 'GREEN BASKET VASHI', '0'),
(701, 461, 'ARCHWAY VENTURES INTERNATINAL PVT LTD', 'ARCHWAY VENTURES INTERNATINAL PVT LTD', '0'),
(702, 593, 'OBEROI FLIGHT KITCHEN', 'OBEROI FLIGHT KITCHEN', '0'),
(703, 2876, 'S D CORPORATION', 'S D CORPORATION', '0'),
(704, 674, 'LITE BITE FOODS PVT. LTD.', 'LITE BITE FOODS PVT. LTD.', '0'),
(705, 2578, 'DIPLOMAT HOTEL', 'DIPLOMAT HOTEL', '0'),
(706, 2651, 'SPRING FIELDS', 'SPRING FIELDS', '0'),
(707, 2164, 'PROVENANCE LAND PVT. LTD.', 'PROVENANCE LAND PVT. LTD.', '0'),
(708, 1496, 'GALAXY ENTERTAINMENT CORPORATION LTD', 'GALAXY ENTERTAINMENT CORPORATION LTD', '0'),
(709, 1954, 'SADGURU HOSPITALITIES LLP', 'SADGURU HOSPITALITIES LLP', '0'),
(710, 2433, 'J V CORPORATION (WOW)', 'J V CORPORATION (WOW)', '0'),
(711, 726, 'TASTY BITES', 'TASTY BITES', '0'),
(712, 2852, 'SOUFFLE FOODWORKS (I) PVT LTD', 'SOUFFLE FOODWORKS (I) PVT LTD', '0'),
(713, 513, 'AVNI CHOCOLATES', 'AVNI CHOCOLATES', '0'),
(714, 2410, 'THE PALATE CULINARY', 'THE PALATE CULINARY', '0'),
(715, 167, 'KOHINOOR CONTINENTIAL', 'KOHINOOR CONTINENTIAL', '0'),
(716, 2933, 'ARIFE LAMOULDE (MIRA ROAD)', 'ARIFE LAMOULDE (MIRA ROAD)', '0'),
(717, 672, 'THE WESTIN MUMBAI GARDEN CITY', 'THE WESTIN MUMBAI GARDEN CITY', '0'),
(718, 3024, 'ZUPPA HOSPITALITY', 'ZUPPA HOSPITALITY', '0'),
(719, 602, 'MOOD SWING CONFECTIONARY                  RS', 'MOOD SWING CONFECTIONARY                  RS', '0'),
(720, 597, 'NEW ARIFE LAA  MOULDE                    RW', 'NEW ARIFE LAA  MOULDE                    RW', '0'),
(721, 493, 'ARIF LAMOULDE (NASIK)', 'ARIF LAMOULDE (NASIK)', '0'),
(722, 2509, 'GREEN  TURTLE (WOW)', 'GREEN  TURTLE (WOW)', '0'),
(723, 1797, 'KRISHTINA FOODS', 'KRISHTINA FOODS', '0'),
(724, 2021, 'S.K HOSPITALITY SERVICES', 'S.K HOSPITALITY SERVICES', '0'),
(725, 2650, 'S.S.V DISTRIBUTORS PVT LTD CUSTOMER', 'S.S.V DISTRIBUTORS PVT LTD CUSTOMER', '0'),
(726, 1657, 'LENEXIS FOODWORKS PVT LTD. ( WOK EXPRESS )', 'LENEXIS FOODWORKS PVT LTD. ( WOK EXPRESS )', '0'),
(727, 1351, 'DESIROUS FOODS', 'DESIROUS FOODS', '0'),
(728, 2796, 'THE FRENCH FRIES', 'THE FRENCH FRIES', '0'),
(729, 2853, 'COPIAN JOGESHWARI', 'COPIAN JOGESHWARI', '0'),
(730, 297, 'RESIPLEX HOSPITALITY DEVELOPERS PVT LTD', 'RESIPLEX HOSPITALITY DEVELOPERS PVT LTD', '0'),
(731, 2875, 'CENTER POINT', 'CENTER POINT', '0'),
(732, 2275, 'SHREE NAMAN HOTELS PVT LTD', 'SHREE NAMAN HOTELS PVT LTD', '0'),
(733, 921, 'TIP TOP ENTERPRISES', 'TIP TOP ENTERPRISES', '0'),
(734, 603, 'PONCHO HOSPITALITY ANDHERI', 'PONCHO HOSPITALITY ANDHERI', '0'),
(735, 798, 'THE AMBASSADOR (CHURCHGATE)', 'THE AMBASSADOR (CHURCHGATE)', '0'),
(736, 613, 'SAHARA HOSPITALITY LTD                   RW', 'SAHARA HOSPITALITY LTD                   RW', '0'),
(737, 2577, 'BLOOM BRAND PARTNERS (WOW INDORE)', 'BLOOM BRAND PARTNERS (WOW INDORE)', '0'),
(738, 2752, 'WOW MOMO FOODS PVT LTD', 'WOW MOMO FOODS PVT LTD', '0'),
(739, 2702, 'SADGURU ENTERPRISES', 'SADGURU ENTERPRISES', '0'),
(740, 2267, 'SHRISHTI AGENCIES', 'SHRISHTI AGENCIES', '0'),
(741, 567, 'IDEAL HOSPITALITY PVT LTD', 'IDEAL HOSPITALITY PVT LTD', '0'),
(742, 1005, 'TJUK TRADE NETWORKS PRIVATE LIMITED', 'TJUK TRADE NETWORKS PRIVATE LIMITED', '0'),
(743, 1297, 'NOVOTEL MUMBAI JUHU BEACH', 'NOVOTEL MUMBAI JUHU BEACH', '0'),
(744, 3025, 'TANASH FOOD PRODUCTS PVT. LTD---MANGALORE', 'TANASH FOOD PRODUCTS PVT. LTD---MANGALORE', '0'),
(745, 539, 'KAMAT HOTELS (INDIA) LTD (HOTEL ORCHID)', 'KAMAT HOTELS (INDIA) LTD (HOTEL ORCHID)', '0'),
(746, 2653, 'S ', 'S ', '0'),
(747, 878, 'RAHUL ENTERPRISES', 'RAHUL ENTERPRISES', '0'),
(748, 1330, 'THE CELEBRATION HOUSE (URD)', 'THE CELEBRATION HOUSE (URD)', '0'),
(749, 2430, 'SARALA KEVALIA RAJKOT (WOW)', 'SARALA KEVALIA RAJKOT (WOW)', '0');
INSERT INTO `UNIFOOD_GROUP_PER` (`ID`, `GROUPID`, `GROUP_CODE`, `GROUP_NAME`, `MOBILE_NO`) VALUES
(750, 1294, 'SHREE WAHEGURU TRADERS', 'SHREE WAHEGURU TRADERS', '0'),
(751, 1663, 'FOOD TALK BAKERY', 'FOOD TALK BAKERY', '0'),
(752, 2726, 'COFFEE DAY GLOBAL LTD', 'COFFEE DAY GLOBAL LTD', '0'),
(753, 2278, 'THE CAKES N MORE', 'THE CAKES N MORE', '0'),
(754, 2253, 'SHYAM AGRO FROZEN FOODS', 'SHYAM AGRO FROZEN FOODS', '0'),
(755, 2934, 'TATA STARBUCKS PVT LTD', 'TATA STARBUCKS PVT LTD', '0'),
(756, 3026, 'APEX CLUBS (INDIA) PRIVATE LIMITED', 'APEX CLUBS (INDIA) PRIVATE LIMITED', '0'),
(757, 474, 'APOORVA DELICIES', 'APOORVA DELICIES', '0'),
(758, 2837, 'BACCHA PARTY', 'BACCHA PARTY', '0'),
(759, 2198, 'BHAGWATI FRUIT ICE CREAM', 'BHAGWATI FRUIT ICE CREAM', '0'),
(760, 2626, 'CAKES ', 'CAKES ', '0'),
(761, 2830, 'JAYANTHI FAST FOOD', 'JAYANTHI FAST FOOD', '0'),
(762, 2879, 'KALORIES CAKES', 'KALORIES CAKES', '0'),
(763, 2679, 'LITTLE STIRS STUDIO', 'LITTLE STIRS STUDIO', '0'),
(764, 2829, 'NEW IDEAL RESTAURANT', 'NEW IDEAL RESTAURANT', '0'),
(765, 2066, 'OPTIMUS ENT.', 'OPTIMUS ENT.', '0'),
(766, 2505, 'ROYAL BAKERS', 'ROYAL BAKERS', '0'),
(767, 606, 'NEW ARIF LA MOUDE HYDERABAD', 'NEW ARIF LA MOUDE HYDERABAD', '0'),
(768, 2083, 'THE BLUE (URD)', 'THE BLUE (URD)', '0'),
(769, 2630, 'THE CHOCOLATE CONNECTIONS', 'THE CHOCOLATE CONNECTIONS', '0'),
(770, 2597, 'WHITE DOVE', 'WHITE DOVE', '0'),
(771, 3006, 'MORYA ENTERPRISES (WOW)', 'MORYA ENTERPRISES (WOW)', '0'),
(772, 764, 'VIRCHAND KHIMJI AND CO', 'VIRCHAND KHIMJI AND CO', '0'),
(773, 806, 'RISO', 'RISO', '0'),
(774, 1945, 'K P ENTERPRISES', 'K P ENTERPRISES', '0'),
(775, 2474, 'DIVINE VENTURES (WOW)', 'DIVINE VENTURES (WOW)', '0'),
(776, 2417, 'BLACK HAWK VENTURES (WOW)', 'BLACK HAWK VENTURES (WOW)', '0'),
(777, 1198, 'HIMESH FOODS PVT. LTD.', 'HIMESH FOODS PVT. LTD.', '0'),
(778, 2298, 'JET AIRWAYS ( INDIA ) LIMITED', 'JET AIRWAYS ( INDIA ) LIMITED', '0'),
(779, 863, 'BAKERS ZONE', 'BAKERS ZONE', '0'),
(780, 1149, 'CHOICE BEST CHOCLATE (URD)', 'CHOICE BEST CHOCLATE (URD)', '0'),
(781, 569, 'HOTEL SHREE RAM', 'HOTEL SHREE RAM', '0'),
(782, 1379, 'MELTING MOMENT', 'MELTING MOMENT', '0'),
(783, 2780, 'ROYAL FAST FOOD', 'ROYAL FAST FOOD', '0'),
(784, 2407, 'SANGREH FASHIONS PVT LTD', 'SANGREH FASHIONS PVT LTD', '0'),
(785, 2310, 'SANCHITA FOOD HUB', 'SANCHITA FOOD HUB', '0'),
(786, 2867, 'BIG PLATE CUISINE LLP', 'BIG PLATE CUISINE LLP', '0'),
(787, 2469, 'FINOM CAKE STOP - BORIVALI', 'FINOM CAKE STOP - BORIVALI', '0'),
(788, 470, 'PARSI DAIRY FARM', 'PARSI DAIRY FARM', '0'),
(789, 944, 'HOTEL SAIKRIPA', 'HOTEL SAIKRIPA', '0'),
(790, 349, 'HANGOUT PIZZA HUB', 'HANGOUT PIZZA HUB', '0'),
(791, 2490, 'HOR KIDDA FOODS PVT LTD', 'HOR KIDDA FOODS PVT LTD', '0'),
(792, 2979, 'OCCASSIONS', 'OCCASSIONS', '0'),
(793, 2826, 'ON THE WAY VEG SNACKS', 'ON THE WAY VEG SNACKS', '0'),
(794, 3027, 'DELISH HOSPITLAITY ( LONDON BUBBLE CO. FRANCHISE )', 'DELISH HOSPITLAITY ( LONDON BUBBLE CO. FRANCHISE )', '0'),
(795, 2914, 'PAREKH ENTERPRISES   (LONDON BUBBLE CO.)', 'PAREKH ENTERPRISES   (LONDON BUBBLE CO.)', '0'),
(796, 3028, 'WAFFLE AND WAFFLE', 'WAFFLE AND WAFFLE', '0'),
(797, 2489, 'BANGALORE BAKERY - NAHAR AMRUT SHAKTI', 'BANGALORE BAKERY - NAHAR AMRUT SHAKTI', '0'),
(798, 2117, 'DEEPAK JUMANI', 'DEEPAK JUMANI', '0'),
(799, 3029, 'INTER - CONTINENTAL TEA CORPORATION', 'INTER - CONTINENTAL TEA CORPORATION', '0'),
(800, 2624, 'KRISHNAKANT FLOWER MERCHANT', 'KRISHNAKANT FLOWER MERCHANT', '0'),
(801, 1993, 'NEW MAHARASHTRA BAKERY', 'NEW MAHARASHTRA BAKERY', '0'),
(802, 3030, 'SEEMA CAKES', 'SEEMA CAKES', '0'),
(803, 3031, 'BARKAAT STORES', 'BARKAAT STORES', '0'),
(804, 963, 'COMPERE HOTELS PVT LTD', 'COMPERE HOTELS PVT LTD', '0'),
(805, 2369, 'GARG AND GARG ASSOCIATES', 'GARG AND GARG ASSOCIATES', '0'),
(806, 754, 'SHRI HARI TRADING', 'SHRI HARI TRADING', '0'),
(807, 2802, 'BRIJSPICE TRADER', 'BRIJSPICE TRADER', '0'),
(808, 2973, 'NSK FOODS', 'NSK FOODS', '0'),
(809, 2690, 'BANGALORE IYENGER BAKERY (KHAR)', 'BANGALORE IYENGER BAKERY (KHAR)', '0'),
(810, 2623, 'CAPTAIN COOK', 'CAPTAIN COOK', '0'),
(811, 2307, 'CHANTILLY ENTERPRISES', 'CHANTILLY ENTERPRISES', '0'),
(812, 2160, 'GOGRI ENTERPRISE', 'GOGRI ENTERPRISE', '0'),
(813, 2677, 'KAPREE FOODS', 'KAPREE FOODS', '0'),
(814, 1193, 'MOMO STATION (URD)', 'MOMO STATION (URD)', '0'),
(815, 2010, 'SATTVA VEG RESTAURANT', 'SATTVA VEG RESTAURANT', '0'),
(816, 637, 'S.P. BURGER', 'S.P. BURGER', '0'),
(817, 1889, 'SUPREME PIZZA KITCHEN', 'SUPREME PIZZA KITCHEN', '0'),
(818, 1857, 'CHOCOLATE HEAVAN PVT LTD - BORIVALI', 'CHOCOLATE HEAVAN PVT LTD - BORIVALI', '0'),
(819, 2229, 'JAI HIND FINE DINING ( BANDRA)', 'JAI HIND FINE DINING ( BANDRA)', '0'),
(820, 2406, 'VILAS PATNE', 'VILAS PATNE', '0'),
(821, 612, 'CELEBRATION THE CAKE SHOP (URD)', 'CELEBRATION THE CAKE SHOP (URD)', '0'),
(822, 2660, 'KANKARIA HOSPITALITY  (WOW)  BENGALURU', 'KANKARIA HOSPITALITY  (WOW)  BENGALURU', '0'),
(823, 3032, 'KRISHNA ENTERPRISES', 'KRISHNA ENTERPRISES', '0'),
(824, 2428, 'HARI OM ENTERPRISES (WOW)', 'HARI OM ENTERPRISES (WOW)', '0'),
(825, 879, 'MONGINIS FOODS PVT LTD (KOLHAPUR)', 'MONGINIS FOODS PVT LTD (KOLHAPUR)', '0'),
(826, 758, 'GYPSY CHINESE', 'GYPSY CHINESE', '0'),
(827, 762, 'SHEETAL SWEETS', 'SHEETAL SWEETS', '0'),
(828, 2990, '7TH HEAVEN (KHARGHAR)', '7TH HEAVEN (KHARGHAR)', '0'),
(829, 3033, 'CAKES ', 'CAKES ', '0'),
(830, 3034, 'INNOVATIVE GASTRONOMY', 'INNOVATIVE GASTRONOMY', '0'),
(831, 3035, 'OMANI SERVICE INCORPORATION', 'OMANI SERVICE INCORPORATION', '0'),
(832, 2535, 'OM FOODS', 'OM FOODS', '0'),
(833, 492, 'TRENDY TASTE', 'TRENDY TASTE', '0'),
(834, 3036, 'VIVGATO FOODS PVT LTD', 'VIVGATO FOODS PVT LTD', '0'),
(835, 2894, 'AASHAPURA CAKE SHOP', 'AASHAPURA CAKE SHOP', '0'),
(836, 2760, 'GUNINAA FOODS', 'GUNINAA FOODS', '0'),
(837, 1244, 'THE CAKE HOUSE', 'THE CAKE HOUSE', '0'),
(838, 1917, 'VAMA HOSPITALITY', 'VAMA HOSPITALITY', '0'),
(839, 3037, 'VIRAJ ENTERPRISES', 'VIRAJ ENTERPRISES', '0'),
(840, 1000, 'MOONLIGHT (VIKHROLI)', 'MOONLIGHT (VIKHROLI)', '0'),
(841, 1241, 'PUNJABI MOTI HALWAI (URD)', 'PUNJABI MOTI HALWAI (URD)', '0'),
(842, 785, 'SHOBHA ONLY VEG', 'SHOBHA ONLY VEG', '0'),
(843, 3038, 'TRENDY TASTE URD', 'TRENDY TASTE URD', '0'),
(844, 2456, 'AARTI UMESH BONDRE', 'AARTI UMESH BONDRE', '0'),
(845, 2047, 'AISHA FAST FOOD', 'AISHA FAST FOOD', '0'),
(846, 2892, 'AMEY AND AKSHAY`S BLISSFULL TEMPTATIONS', 'AMEY AND AKSHAY`S BLISSFULL TEMPTATIONS', '0'),
(847, 2771, 'COCO TEMPTATION', 'COCO TEMPTATION', '0'),
(848, 3039, 'KUDOS HOSPITALITY', 'KUDOS HOSPITALITY', '0'),
(849, 2534, 'SWISS WAFFLE', 'SWISS WAFFLE', '0'),
(850, 2820, 'BEING HEALTHY KITCHEN', 'BEING HEALTHY KITCHEN', '0'),
(851, 2248, 'HUNGER POINT', 'HUNGER POINT', '0'),
(852, 3040, 'NATURE`S BAKE', 'NATURE`S BAKE', '0'),
(853, 2732, 'NUCLEUS FOOD COMPANY', 'NUCLEUS FOOD COMPANY', '0'),
(854, 2714, 'MFY', 'MFY', '0'),
(855, 2391, 'QUALITY CENTRE', 'QUALITY CENTRE', '0'),
(856, 2392, 'VAS THE ITALIAN FOOD CUISINE', 'VAS THE ITALIAN FOOD CUISINE', '0'),
(857, 2873, 'ASHTVINAYAK HOSPITALITY', 'ASHTVINAYAK HOSPITALITY', '0'),
(858, 1028, 'THE CHOCOLATE SPOON COMPANY PVT LTD (CHURCHGATE)', 'THE CHOCOLATE SPOON COMPANY PVT LTD (CHURCHGATE)', '0'),
(859, 3041, 'MASSIVE RESTAURANT PRIVATE LIMITED', 'MASSIVE RESTAURANT PRIVATE LIMITED', '0'),
(860, 2731, 'BANGALORE IYENGAR BAKERY - JOGESHWARI E', 'BANGALORE IYENGAR BAKERY - JOGESHWARI E', '0'),
(861, 274, 'GURUKRIPA JAIN BAKERY', 'GURUKRIPA JAIN BAKERY', '0'),
(862, 1577, 'VIENNA BAKERY', 'VIENNA BAKERY', '0'),
(863, 2097, 'GAUTAM RESTAURANT', 'GAUTAM RESTAURANT', '0'),
(864, 1552, 'SARAS CAKE SHOP ( UN REG DEALER  - NO VAT TIN )', 'SARAS CAKE SHOP ( UN REG DEALER  - NO VAT TIN )', '0'),
(865, 2749, 'THE LEGENDARY HOSPITALITY', 'THE LEGENDARY HOSPITALITY', '0'),
(866, 780, 'AUTO HANGAR', 'AUTO HANGAR', '0'),
(867, 1846, 'DELUX ENTERPRISE', 'DELUX ENTERPRISE', '0'),
(868, 2812, 'THE PARADISE TUNGA', 'THE PARADISE TUNGA', '0'),
(869, 261, 'BARBEQUE NATIONAL HOSPITALITY LIMITED', 'BARBEQUE NATIONAL HOSPITALITY LIMITED', '0'),
(870, 293, 'JAIN BAKERS', 'JAIN BAKERS', '0'),
(871, 186, 'LOVE SUGAR DOUGH PVT LTD', 'LOVE SUGAR DOUGH PVT LTD', '0'),
(872, 1910, 'BAKER\'S BASKET', 'BAKER\'S BASKET', '0'),
(873, 2580, 'VPJ CREATION ENTERPRISES', 'VPJ CREATION ENTERPRISES', '0'),
(874, 2748, 'NDS HOSPITALITY SERVICES PVT LTD', 'NDS HOSPITALITY SERVICES PVT LTD', '0'),
(875, 1734, 'ORIENTAL STORES ', 'ORIENTAL STORES ', '0'),
(876, 467, 'BAKER ', 'BAKER ', '0'),
(877, 2328, 'CHAI CENTRE', 'CHAI CENTRE', '0'),
(878, 2046, 'CHIT CHAT CHAI', 'CHIT CHAT CHAI', '0'),
(879, 2612, 'HAS LIFESTYLE LIMITED', 'HAS LIFESTYLE LIMITED', '0'),
(880, 1817, 'PIZZA SABROSO', 'PIZZA SABROSO', '0'),
(881, 2937, 'S ', 'S ', '0'),
(882, 887, 'TULSI (URD)', 'TULSI (URD)', '0'),
(883, 367, 'ASHWINI FAST FOOD', 'ASHWINI FAST FOOD', '0'),
(884, 2444, 'CHEF CHOCOLA', 'CHEF CHOCOLA', '0'),
(885, 2435, 'FOOD FOLK', 'FOOD FOLK', '0'),
(886, 1830, 'FRESH CAKES N  BREADS', 'FRESH CAKES N  BREADS', '0'),
(887, 2696, 'FUN TWIST WAFFLE', 'FUN TWIST WAFFLE', '0'),
(888, 2062, 'KENIYA STORES', 'KENIYA STORES', '0'),
(889, 2896, 'NAEEM MASALA', 'NAEEM MASALA', '0'),
(890, 325, 'ARIHANT MITHAI ', 'ARIHANT MITHAI ', '0'),
(891, 2545, 'TAKE N BAKE', 'TAKE N BAKE', '0'),
(892, 2242, 'GD\'S CHINESE', 'GD\'S CHINESE', '0'),
(893, 477, 'SINGH CONFECTIONERIES', 'SINGH CONFECTIONERIES', '0'),
(894, 476, 'ADITYA SNACKS ', 'ADITYA SNACKS ', '0'),
(895, 1553, 'LETS CELEBRATE', 'LETS CELEBRATE', '0'),
(896, 1154, 'SWEET MOMENTS', 'SWEET MOMENTS', '0'),
(897, 3042, 'ARTISANAL CUISINES PVT LTD.', 'ARTISANAL CUISINES PVT LTD.', '0'),
(898, 133, 'BAY LEAF', 'BAY LEAF', '0'),
(899, 2803, 'BOMBAY ROLLS', 'BOMBAY ROLLS', '0'),
(900, 3043, 'CAKES ', 'CAKES ', '0'),
(901, 765, 'GARCIAâ€™S FAMOUS PIZZA', 'GARCIAâ€™S FAMOUS PIZZA', '0'),
(902, 3044, 'MAVERICK FOODLABS LLP', 'MAVERICK FOODLABS LLP', '0'),
(903, 3045, 'USA WAFFLE', 'USA WAFFLE', '0'),
(904, 2908, 'ANAND BHUVAN LUNCH HOME', 'ANAND BHUVAN LUNCH HOME', '0'),
(905, 828, 'BREACH CANDY HOSPITAL', 'BREACH CANDY HOSPITAL', '0'),
(906, 3046, 'MILKBAR', 'MILKBAR', '0'),
(907, 503, 'SWADESH VEG RESTAURANT', 'SWADESH VEG RESTAURANT', '0'),
(908, 362, 'ARPAN RESTAURANT ', 'ARPAN RESTAURANT ', '0'),
(909, 1473, 'CALIFORNIA COFFEE (UNREGISTER DEALER NO VAT TIN', 'CALIFORNIA COFFEE (UNREGISTER DEALER NO VAT TIN', '0'),
(910, 2951, 'THE BLEND EXPRESS - CAFÃ‰', 'THE BLEND EXPRESS - CAFÃ‰', '0'),
(911, 3047, 'BISTRO 89', 'BISTRO 89', '0'),
(912, 1043, 'KIRTI TRADING', 'KIRTI TRADING', '0'),
(913, 940, 'GURUPRASAD RESTAURANT ', 'GURUPRASAD RESTAURANT ', '0'),
(914, 1871, 'MUMBAI BISTRO THE CAFE', 'MUMBAI BISTRO THE CAFE', '0'),
(915, 2134, 'MOMENTS HOSPITALITY', 'MOMENTS HOSPITALITY', '0'),
(916, 1508, 'JAIHIND COLLEGE CANTEEN', 'JAIHIND COLLEGE CANTEEN', '0'),
(917, 916, 'PRASADAM', 'PRASADAM', '0'),
(918, 2057, 'THE PEABERRY TRAILS', 'THE PEABERRY TRAILS', '0'),
(919, 1068, 'VASUDEV TRADING CO', 'VASUDEV TRADING CO', '0'),
(920, 2380, 'CENTRAL FISH SUPPLIER', 'CENTRAL FISH SUPPLIER', '0'),
(921, 1283, 'RISA HOSPITALITY PVT. LTD.', 'RISA HOSPITALITY PVT. LTD.', '0'),
(922, 1033, 'SATRA ENETERPRISE', 'SATRA ENETERPRISE', '0'),
(923, 2416, 'IJAZZ HOSPITALITY LLP (WOW)', 'IJAZZ HOSPITALITY LLP (WOW)', '0'),
(924, 852, 'LILAVATI HOSPITAL ', 'LILAVATI HOSPITAL ', '0'),
(925, 2486, 'FOOD QUEST PVT LTD   (KAI FOODS)', 'FOOD QUEST PVT LTD   (KAI FOODS)', '0'),
(926, 1897, 'GREENZ PAREL', 'GREENZ PAREL', '0'),
(927, 3048, 'HOTEL SADGURU', 'HOTEL SADGURU', '0'),
(928, 3049, 'JHP', 'JHP', '0'),
(929, 140, 'PLUM CASTLE', 'PLUM CASTLE', '0'),
(930, 3050, 'ROYAL RESTAURANTS ', 'ROYAL RESTAURANTS ', '0'),
(931, 3051, 'SAANVI CREAMBELL ( LONDON BUBBLE CO. FRANCHISE OUTLET)', 'SAANVI CREAMBELL ( LONDON BUBBLE CO. FRANCHISE OUTLET)', '0'),
(932, 3052, 'GIRI ENTERPRISES', 'GIRI ENTERPRISES', '0'),
(933, 2882, 'QUENTINS HEALTHY CAFE', 'QUENTINS HEALTHY CAFE', '0'),
(934, 2048, 'BREADKRAFT  (KANDIVALI EAST )', 'BREADKRAFT  (KANDIVALI EAST )', '0'),
(935, 3053, 'FOOD FOR THOUGHT ( KITAB KHANA )', 'FOOD FOR THOUGHT ( KITAB KHANA )', '0'),
(936, 2395, 'ITC MARATHA', 'ITC MARATHA', '0'),
(937, 2495, 'SANGEETA CHOCOLATES', 'SANGEETA CHOCOLATES', '0'),
(938, 3054, 'PURPLE DOT HOSPITALITY ( LONDON BUBBLE PUNE )', 'PURPLE DOT HOSPITALITY ( LONDON BUBBLE PUNE )', '0'),
(939, 2775, 'ICEE SPICY', 'ICEE SPICY', '0'),
(940, 2389, 'THE WAFFLIST', 'THE WAFFLIST', '0'),
(941, 2846, 'GAURAV JUICE ', 'GAURAV JUICE ', '0'),
(942, 1229, 'KRISPIES', 'KRISPIES', '0'),
(943, 3055, 'THE LATIN MESS PVT LTD', 'THE LATIN MESS PVT LTD', '0'),
(944, 2674, 'THE SLICE PIZZA', 'THE SLICE PIZZA', '0'),
(945, 2658, 'R AND G ENTERPRISES', 'R AND G ENTERPRISES', '0'),
(946, 1315, 'TOP CLASS ENTERPRISE', 'TOP CLASS ENTERPRISE', '0'),
(947, 3005, 'SIZZLE HOUSE OSHIWARA ( TASTE ', 'SIZZLE HOUSE OSHIWARA ( TASTE ', '0'),
(948, 556, 'PARIJAT RESTAURANT', 'PARIJAT RESTAURANT', '0'),
(949, 127, 'CAKE DELIGHT (MAHIM) (URD)', 'CAKE DELIGHT (MAHIM) (URD)', '0'),
(950, 2101, 'FAMOUS CAKE CENTER', 'FAMOUS CAKE CENTER', '0'),
(951, 2935, 'BANGALORE IYENGAR BAKERS--MAHALAXMI', 'BANGALORE IYENGAR BAKERS--MAHALAXMI', '0'),
(952, 1513, 'BELL PEPPERS', 'BELL PEPPERS', '0'),
(953, 1541, 'ELYSIUM PATISSERIE', 'ELYSIUM PATISSERIE', '0'),
(954, 3056, 'SHAKTI FOOD ', 'SHAKTI FOOD ', '0'),
(955, 3057, 'THE BLOOMSBURY PLACE', 'THE BLOOMSBURY PLACE', '0'),
(956, 2688, 'FOODELICIOUS', 'FOODELICIOUS', '0'),
(957, 2950, 'KETCHIKAN FOODS LLP', 'KETCHIKAN FOODS LLP', '0'),
(958, 3058, 'MRS. POONAM PURI', 'MRS. POONAM PURI', '0'),
(959, 3059, 'SAI FOODS  - PAREL', 'SAI FOODS  - PAREL', '0'),
(960, 2662, 'THE NOISY CAFE', 'THE NOISY CAFE', '0'),
(961, 1996, 'CAKE BOX URD', 'CAKE BOX URD', '0'),
(962, 2828, 'AD`S MILKBAR', 'AD`S MILKBAR', '0'),
(963, 1724, 'BINDAAS BINGE', 'BINDAAS BINGE', '0'),
(964, 3060, 'GD PEST CONTROL PVT LTD', 'GD PEST CONTROL PVT LTD', '0'),
(965, 1425, 'GK ENTERPRISES', 'GK ENTERPRISES', '0'),
(966, 2807, 'HD CAKE KING AND MORE', 'HD CAKE KING AND MORE', '0'),
(967, 2045, 'PAVALION RESTAURANT', 'PAVALION RESTAURANT', '0'),
(968, 3061, 'RAHUL ENTERPRISES (URD)', 'RAHUL ENTERPRISES (URD)', '0'),
(969, 3062, 'RRMM AND DAUGHTER\'S PVT. LTD.', 'RRMM AND DAUGHTER\'S PVT. LTD.', '0'),
(970, 2639, 'RUHI CATERERS', 'RUHI CATERERS', '0'),
(971, 2860, 'VELVET FINE CHOCOLATES', 'VELVET FINE CHOCOLATES', '0'),
(972, 2847, 'CHEF STEPS KITCHEN (URD)', 'CHEF STEPS KITCHEN (URD)', '0'),
(973, 3063, 'M/S KITCHY HOSPITALITY LLP', 'M/S KITCHY HOSPITALITY LLP', '0'),
(974, 1015, 'PAYAL DOSHI', 'PAYAL DOSHI', '0'),
(975, 2576, 'SEWREE SWEETS ', 'SEWREE SWEETS ', '0'),
(976, 335, 'LOBO STORES', 'LOBO STORES', '0'),
(977, 1438, 'CAFE CHOKOLADE', 'CAFE CHOKOLADE', '0'),
(978, 809, 'DEEPCHAND AND SONS', 'DEEPCHAND AND SONS', '0'),
(979, 2972, 'SHRAVANI ENTERPRISES', 'SHRAVANI ENTERPRISES', '0'),
(980, 1825, 'SHRINATHJIS  SWEETS ', 'SHRINATHJIS  SWEETS ', '0'),
(981, 3064, 'THE CAKES AND BAKES', 'THE CAKES AND BAKES', '0'),
(982, 2090, 'BLUE BITE (URD)', 'BLUE BITE (URD)', '0'),
(983, 844, 'PIER SPECIALITY FOODS LLP', 'PIER SPECIALITY FOODS LLP', '0'),
(984, 2507, 'THE FRIENDS BENCH ALL DAY CAFE', 'THE FRIENDS BENCH ALL DAY CAFE', '0'),
(985, 3065, 'XPRESS BURGER', 'XPRESS BURGER', '0'),
(986, 1177, 'YUMMILICIOUS (URD)', 'YUMMILICIOUS (URD)', '0'),
(987, 1837, 'THAKKARS STARDOM EVENTS PVT LTD', 'THAKKARS STARDOM EVENTS PVT LTD', '0'),
(988, 515, 'KHYBER RESTAURANT', 'KHYBER RESTAURANT', '0'),
(989, 3066, 'EHI LTD UNIT OBEROI FLIGHT SERVICES', 'EHI LTD UNIT OBEROI FLIGHT SERVICES', '0'),
(990, 2589, 'BEYOND PANCAKES', 'BEYOND PANCAKES', '0'),
(991, 3067, 'JAYRAJ ENTERPRISES', 'JAYRAJ ENTERPRISES', '0'),
(992, 1660, 'COFFEE DYNAMICS PVT LTD', 'COFFEE DYNAMICS PVT LTD', '0'),
(993, 2897, 'ASIF SEA FOOD SUPPLIERS', 'ASIF SEA FOOD SUPPLIERS', '0'),
(994, 2443, 'SHOKOLAAT (NAGPADA JUNCTION)', 'SHOKOLAAT (NAGPADA JUNCTION)', '0'),
(995, 2772, 'ANKIT KHANDELWAL (HUF )', 'ANKIT KHANDELWAL (HUF )', '0'),
(996, 509, 'SRRS FOODS PVT LTD (THE SPARE KITCHEN)', 'SRRS FOODS PVT LTD (THE SPARE KITCHEN)', '0'),
(997, 2652, 'ROYAL CHINA', 'ROYAL CHINA', '0'),
(998, 1400, 'CONE T GO', 'CONE T GO', '0'),
(999, 3068, 'BROWNIE POINT PALAVA', 'BROWNIE POINT PALAVA', '0'),
(1000, 3069, 'GALAXY CLOUD KITCHENS LTD', 'GALAXY CLOUD KITCHENS LTD', '0'),
(1001, 1503, 'NEW SUPER SWEET', 'NEW SUPER SWEET', '0'),
(1002, 1742, 'HOTEL KUMKUM', 'HOTEL KUMKUM', '0'),
(1003, 1098, 'ASHMICIKS SNACK SHACK', 'ASHMICIKS SNACK SHACK', '0'),
(1004, 2827, 'OM RESTO', 'OM RESTO', '0'),
(1005, 2514, 'UFO FRIES FRIES AND CORN', 'UFO FRIES FRIES AND CORN', '0'),
(1006, 2087, 'DAWN D\'SOUZA', 'DAWN D\'SOUZA', '0'),
(1007, 1140, 'BANGLORE IYANGAR BAKERY (SANTACRUZ EAST)', 'BANGLORE IYANGAR BAKERY (SANTACRUZ EAST)', '0'),
(1008, 1699, 'A J ENTERPRISES', 'A J ENTERPRISES', '0'),
(1009, 2475, 'D ', 'D ', '0'),
(1010, 3070, 'EXOTIKKA', 'EXOTIKKA', '0'),
(1011, 3071, 'MOCAMBO CAFE', 'MOCAMBO CAFE', '0'),
(1012, 3072, 'OM ENTERPRISE', 'OM ENTERPRISE', '0'),
(1013, 3073, 'PAMPLEMOUSSE CAKES', 'PAMPLEMOUSSE CAKES', '0'),
(1014, 2883, 'SMILE N BAKE', 'SMILE N BAKE', '0'),
(1015, 2585, 'BHAVANS GYMKHANA CANTEEN', 'BHAVANS GYMKHANA CANTEEN', '0'),
(1016, 2855, 'PUSHPA ENTERPRISE.', 'PUSHPA ENTERPRISE.', '0'),
(1017, 3003, 'FIRANGI HALWAI', 'FIRANGI HALWAI', '0'),
(1018, 2980, 'BLUE WATERS SEA FOODS', 'BLUE WATERS SEA FOODS', '0'),
(1019, 2788, 'M.H. SHAIKH FRUIT ', 'M.H. SHAIKH FRUIT ', '0'),
(1020, 3074, 'JAI HIND LUNCH HOME BANDRA EAST', 'JAI HIND LUNCH HOME BANDRA EAST', '0'),
(1021, 2741, 'MAGSA MOULDE', 'MAGSA MOULDE', '0'),
(1022, 1819, 'MALVAN SAMUDRA', 'MALVAN SAMUDRA', '0'),
(1023, 1053, 'PATEL LUNCH HOME ( URD)', 'PATEL LUNCH HOME ( URD)', '0'),
(1024, 1166, 'VIGHNESH HOSPITALITY', 'VIGHNESH HOSPITALITY', '0'),
(1025, 2694, 'SUGARPIXEL ( LONDON BUBBLE )', 'SUGARPIXEL ( LONDON BUBBLE )', '0'),
(1026, 2940, 'SADGURU ENTERPRISES - THANE', 'SADGURU ENTERPRISES - THANE', '0'),
(1027, 2850, 'D D FOODS', 'D D FOODS', '0'),
(1028, 3075, 'RISA AFT HOSPITALITY LLP', 'RISA AFT HOSPITALITY LLP', '0'),
(1029, 2587, 'ABID', 'ABID', '0'),
(1030, 1866, 'DELIURE', 'DELIURE', '0'),
(1031, 1757, 'PRASHANT CATERERS', 'PRASHANT CATERERS', '0'),
(1032, 3076, 'OM ENTERPRISE (LE GEATUE)', 'OM ENTERPRISE (LE GEATUE)', '0'),
(1033, 2685, 'THE FRANCHISE CO.(LONDON BUBBLE)', 'THE FRANCHISE CO.(LONDON BUBBLE)', '0'),
(1034, 2952, 'NATURES BASKET LIMITED', 'NATURES BASKET LIMITED', '0'),
(1035, 2953, 'FUTURE RETAIL LIMITED--HYPERCITY', 'FUTURE RETAIL LIMITED--HYPERCITY', '0'),
(1036, 2954, 'FUTURE RETAIL LIMITED', 'FUTURE RETAIL LIMITED', '0'),
(1037, 2955, 'SUPERMARKET GROCERY SUPPLIES PVT. LTD', 'SUPERMARKET GROCERY SUPPLIES PVT. LTD', '0'),
(1038, 2222, 'ADITYA BIRLA RETAIL LIMITED', 'ADITYA BIRLA RETAIL LIMITED', '0'),
(1039, 2956, 'FUTURE RETAIL LIMITED - LOWER PAREL', 'FUTURE RETAIL LIMITED - LOWER PAREL', '0'),
(1040, 3077, 'CELEBRATION THE CAKE SHOP', 'CELEBRATION THE CAKE SHOP', '0'),
(1041, 2239, 'ASPIRE HOSPITALITY', 'ASPIRE HOSPITALITY', '0'),
(1042, 3078, 'RRUCHI FOOD PLAZA PVT LTD', 'RRUCHI FOOD PLAZA PVT LTD', '0'),
(1043, 3079, 'KOHINOOR HALL( VOWS BANQUET)', 'KOHINOOR HALL( VOWS BANQUET)', '0'),
(1044, 3080, 'DOYEN FOODS LLP', 'DOYEN FOODS LLP', '0'),
(1045, 2258, 'SUNRISE HOSPITALITY', 'SUNRISE HOSPITALITY', '0'),
(1046, 2079, 'FOOD BUDDIESSS', 'FOOD BUDDIESSS', '0'),
(1047, 2511, 'II WALLS HOSPITALITY (RAIN FOREST PUNE)', 'II WALLS HOSPITALITY (RAIN FOREST PUNE)', '0'),
(1048, 3081, 'IRTIKA KHAN', 'IRTIKA KHAN', '0'),
(1049, 2756, 'PRITHVIS CAVERN', 'PRITHVIS CAVERN', '0'),
(1050, 3082, 'THE PIZZAIOLO', 'THE PIZZAIOLO', '0'),
(1051, 2913, 'UMA ENTERPRISES', 'UMA ENTERPRISES', '0'),
(1052, 3083, 'DESSI CUPPA', 'DESSI CUPPA', '0'),
(1053, 3084, 'ELIOR WEST CATERING LLP', 'ELIOR WEST CATERING LLP', '0'),
(1054, 1921, 'MUMBAI\'S MOMOS ', 'MUMBAI\'S MOMOS ', '0'),
(1055, 3085, 'SADA CANTEEN SERVICES', 'SADA CANTEEN SERVICES', '0'),
(1056, 902, 'SAMRAT RESTUARANT ', 'SAMRAT RESTUARANT ', '0'),
(1057, 238, 'INTERGLOBE HOTELS PVT LTD', 'INTERGLOBE HOTELS PVT LTD', '0'),
(1058, 3086, 'BANGALORE IYANGAR\'S BAKERY (ANDHERI MAROL)', 'BANGALORE IYANGAR\'S BAKERY (ANDHERI MAROL)', '0'),
(1059, 2508, 'FIVE FAT MONKS', 'FIVE FAT MONKS', '0'),
(1060, 3087, 'LOOP HOSPITALITY', 'LOOP HOSPITALITY', '0'),
(1061, 3088, 'SPIL HOSPITALITY PVT LTD', 'SPIL HOSPITALITY PVT LTD', '0'),
(1062, 3089, 'EIH LTD UNIT OBEROI FLIGHT SERVICES', 'EIH LTD UNIT OBEROI FLIGHT SERVICES', '0'),
(1063, 489, 'LA CHOCOLATIER', 'LA CHOCOLATIER', '0'),
(1064, 2753, 'VIZIFDARS HOSPITALITY', 'VIZIFDARS HOSPITALITY', '0'),
(1065, 2607, 'ASPIRING FOODPRENEUR', 'ASPIRING FOODPRENEUR', '0'),
(1066, 1324, 'BAKERS POINT (URD)', 'BAKERS POINT (URD)', '0'),
(1067, 3090, 'BARKAAT STORE', 'BARKAAT STORE', '0'),
(1068, 3091, 'HOT SPOT RESTAURANT AND BAR', 'HOT SPOT RESTAURANT AND BAR', '0'),
(1069, 1546, 'BANGALORE IYANGAR BAKERY- GHATKOPER', 'BANGALORE IYANGAR BAKERY- GHATKOPER', '0'),
(1070, 3092, 'MATESHWARI SODA PUB', 'MATESHWARI SODA PUB', '0'),
(1071, 3093, 'JAI HIND FINE DINING BANDRA (W)', 'JAI HIND FINE DINING BANDRA (W)', '0'),
(1072, 2834, 'HOTEL TUNGA REGALE (INDIA ) PVT LTD', 'HOTEL TUNGA REGALE (INDIA ) PVT LTD', '0'),
(1073, 2737, 'BARSOLUTIONS LLP', 'BARSOLUTIONS LLP', '0'),
(1074, 3094, 'WIG ASSOCIATES PVT LTD', 'WIG ASSOCIATES PVT LTD', '0'),
(1075, 2042, 'R M CHOCOLATE (URD)', 'R M CHOCOLATE (URD)', '0'),
(1076, 3095, 'PALAK AJMERA', 'PALAK AJMERA', '0'),
(1077, 2355, 'ZEN ENTERPRISES', 'ZEN ENTERPRISES', '0'),
(1078, 1971, 'SAI CATERERS', 'SAI CATERERS', '0'),
(1079, 3096, 'M. SANJAY KUMAR ', 'M. SANJAY KUMAR ', '0'),
(1080, 2455, 'R.K.ENTERPRISE', 'R.K.ENTERPRISE', '0'),
(1081, 216, 'CHAMUNDA CATERERS', 'CHAMUNDA CATERERS', '0'),
(1082, 1673, 'FUSION WOK', 'FUSION WOK', '0'),
(1083, 2365, 'PARAMOUNT PATISSERIE', 'PARAMOUNT PATISSERIE', '0'),
(1084, 2635, 'SINGH SAAB RESTAURANT (URD)', 'SINGH SAAB RESTAURANT (URD)', '0'),
(1085, 2817, 'WTC PASTA', 'WTC PASTA', '0'),
(1086, 2260, 'BACHELOR JUICE HOUSE', 'BACHELOR JUICE HOUSE', '0'),
(1087, 2468, 'BACHELOR ICE CREAM', 'BACHELOR ICE CREAM', '0'),
(1088, 860, 'CRYSTAL ENTERPRISES', 'CRYSTAL ENTERPRISES', '0'),
(1089, 2418, 'SATTE PE SATTA', 'SATTE PE SATTA', '0'),
(1090, 3097, 'VIVEKA ESSENCE MART GOA', 'VIVEKA ESSENCE MART GOA', '0'),
(1091, 3098, 'RK BURGER', 'RK BURGER', '0'),
(1092, 3099, 'H', 'H', '0'),
(1093, 3100, 'NAUTICA FOOD', 'NAUTICA FOOD', '0'),
(1094, 3101, 'TURMIX CAFE', 'TURMIX CAFE', '0'),
(1095, 1296, 'SMOKE HOUSE DELI BKC', 'SMOKE HOUSE DELI BKC', '0'),
(1096, 1123, 'OLIVE BAR ', 'OLIVE BAR ', '0'),
(1097, 2801, 'MESO PESO', 'MESO PESO', '0'),
(1098, 1747, 'THE SERIAL GRILLER', 'THE SERIAL GRILLER', '0'),
(1099, 3102, 'GIRISH GUPTA (URD)', 'GIRISH GUPTA (URD)', '0'),
(1100, 3103, 'DLIGHT CAKE SHOP', 'DLIGHT CAKE SHOP', '0'),
(1101, 3104, 'FOOD WORKS', 'FOOD WORKS', '0'),
(1102, 3105, 'NANO FINVEST CONSULTANCIES PVT LTD', 'NANO FINVEST CONSULTANCIES PVT LTD', '0'),
(1103, 523, 'PRATIKSHA RESTAURANT BAR ', 'PRATIKSHA RESTAURANT BAR ', '0'),
(1104, 3106, 'KUDOS HOSPITALITY PVT LTD', 'KUDOS HOSPITALITY PVT LTD', '0'),
(1105, 2549, 'DHRUV', 'DHRUV', '0'),
(1106, 3107, 'INDUS HOSPITALITY', 'INDUS HOSPITALITY', '0'),
(1107, 2287, 'BANGALORE IYENGAR\'S BAKERY (BYCULLA)', 'BANGALORE IYENGAR\'S BAKERY (BYCULLA)', '0'),
(1108, 0, '', '', ''),
(1109, 3108, 'KAILASH PICTURE COMPANY PRIVATE LIMITED', 'KAILASH PICTURE COMPANY PRIVATE LIMITED', '0'),
(1110, 3109, 'FOOD FOR THOUGHT', 'FOOD FOR THOUGHT', '0'),
(1111, 3110, 'DASILA\'S CAKE SHOP', 'DASILA\'S CAKE SHOP', '0'),
(1112, 2931, 'M/S CONTROL ALT FOODS PRIVATE LIMITED', 'M/S CONTROL ALT FOODS PRIVATE LIMITED', '0'),
(1113, 150, 'SHAH SUPPLIERS', 'SHAH SUPPLIERS', '0'),
(1114, 1505, 'KHUSHALANI STORES', 'KHUSHALANI STORES', '0'),
(1115, 3111, 'COFFEE BEANS COMPANY', 'COFFEE BEANS COMPANY', '0'),
(1116, 2148, '3 SISTERS CAKE SHOP', '3 SISTERS CAKE SHOP', '0'),
(1117, 3112, 'BROOKLYN BINGE PRIVATE LIMITED', 'BROOKLYN BINGE PRIVATE LIMITED', '0'),
(1118, 3113, 'D CAKE CREATIONS', 'D CAKE CREATIONS', '0'),
(1119, 1003, 'FEAST CAKES N BAKES        RW', 'FEAST CAKES N BAKES        RW', '0'),
(1120, 2918, 'BAKE N SNACKS', 'BAKE N SNACKS', '0'),
(1121, 3114, 'CASH SALES AAJ', 'CASH SALES AAJ', '0'),
(1122, 3115, 'MAIN STREET BAKERY', 'MAIN STREET BAKERY', '0'),
(1123, 3116, 'NAVONA KITCHEN LLP', 'NAVONA KITCHEN LLP', '0'),
(1124, 2742, 'PASTICCERIA BAKERS', 'PASTICCERIA BAKERS', '0'),
(1125, 3117, 'PRIYANKA SAMPAT MUNDHE', 'PRIYANKA SAMPAT MUNDHE', '0'),
(1126, 3118, 'SHALOM CATERERS', 'SHALOM CATERERS', '0'),
(1127, 3119, 'YUMMYNTUMMY', 'YUMMYNTUMMY', '0'),
(1128, 2927, 'RHUBARB AND CRUMBS CUPCAKE', 'RHUBARB AND CRUMBS CUPCAKE', '0'),
(1129, 1708, 'TEJAL MODI (URD)', 'TEJAL MODI (URD)', '0'),
(1130, 1778, 'STUDIO KITCHEN', 'STUDIO KITCHEN', '0'),
(1131, 3120, 'THE WAFFLE ', 'THE WAFFLE ', '0'),
(1132, 2363, 'FUSION PIZZA PRIVATE LTD', 'FUSION PIZZA PRIVATE LTD', '0'),
(1133, 3121, 'SWAYAMDEEP ENTERPRISES', 'SWAYAMDEEP ENTERPRISES', '0'),
(1134, 1179, 'SUNSET CHINESE CUISINE (URD)', 'SUNSET CHINESE CUISINE (URD)', '0'),
(1135, 676, 'CAKE N CANDY', 'CAKE N CANDY', '0'),
(1136, 730, 'CHEF SANAP', 'CHEF SANAP', '0'),
(1137, 3122, 'CASH SALE O', 'CASH SALE O', '0'),
(1138, 2225, 'PREMIUM ENTERPRISES', 'PREMIUM ENTERPRISES', '0'),
(1139, 2224, 'NEW MAHARASHTRA MECHANICAL WORKS', 'NEW MAHARASHTRA MECHANICAL WORKS', '0'),
(1140, 3123, 'FRESH BAKE (HOME MAKERS)', 'FRESH BAKE (HOME MAKERS)', '0'),
(1141, 3124, 'CRAVING BOX', 'CRAVING BOX', '0'),
(1142, 3125, 'DOKE INDUSTRY', 'DOKE INDUSTRY', '0'),
(1143, 2905, 'M Y HOSPITALITY', 'M Y HOSPITALITY', '0'),
(1144, 3126, 'ROYALE FOOD AND HOSPITALITY', 'ROYALE FOOD AND HOSPITALITY', '0'),
(1145, 3127, 'SHREE SADGURU HOSPITALITY AND SERVICES', 'SHREE SADGURU HOSPITALITY AND SERVICES', '0'),
(1146, 3128, 'SALE/18-19/1104', 'SALE/18-19/1104', '0'),
(1147, 2575, 'BANYAN TREE HOSPITALITY', 'BANYAN TREE HOSPITALITY', '0'),
(1148, 3129, 'FOUR DREAMS THE CAKE SHOP', 'FOUR DREAMS THE CAKE SHOP', '0'),
(1149, 2751, 'HOPE BERRY ( LONDON BUBBLE CO )', 'HOPE BERRY ( LONDON BUBBLE CO )', '0'),
(1150, 1845, 'TRUPATI AGENCIES', 'TRUPATI AGENCIES', '0'),
(1151, 2991, 'DHEER FOODS', 'DHEER FOODS', '0'),
(1152, 3130, 'THE TEA COUNTY', 'THE TEA COUNTY', '0'),
(1153, 3131, 'ADARSH ENTERPRISES (LONDON BUBBLE)', 'ADARSH ENTERPRISES (LONDON BUBBLE)', '0'),
(1154, 3132, 'SONIA FOODS (NEO POLITAN PIZZA)', 'SONIA FOODS (NEO POLITAN PIZZA)', '0'),
(1155, 3133, 'CAFE 2 O - MATUNGA', 'CAFE 2 O - MATUNGA', '0'),
(1156, 3134, 'SACHDEV HOSPITALITIES', 'SACHDEV HOSPITALITIES', '0'),
(1157, 1269, 'ZAIKA (DELICIOUS FAST FOOD)', 'ZAIKA (DELICIOUS FAST FOOD)', '0'),
(1158, 2394, 'CAFE ISTAA', 'CAFE ISTAA', '0'),
(1159, 2928, 'SUMMER PLAZA RESORT', 'SUMMER PLAZA RESORT', '0'),
(1160, 2558, 'DISHA JAIN', 'DISHA JAIN', '0'),
(1161, 2099, 'PIZZARIO', 'PIZZARIO', '0'),
(1162, 3135, 'EK NUMBER HOSPITALITY LLP', 'EK NUMBER HOSPITALITY LLP', '0'),
(1163, 3136, 'SUPERFIT LIFESTYLE ASIA LLP', 'SUPERFIT LIFESTYLE ASIA LLP', '0'),
(1164, 1242, 'SILVER BEACH ENTERTAINMENT ', 'SILVER BEACH ENTERTAINMENT ', '0'),
(1165, 3137, 'AALIA HOSPITALITY PVT LTD JUHU', 'AALIA HOSPITALITY PVT LTD JUHU', '0'),
(1166, 1192, 'AHIMSA HOSPITALITY PVT LTD', 'AHIMSA HOSPITALITY PVT LTD', '0'),
(1167, 3138, 'IVAAR HOSPITALITY PRIVATE LIMITED ( BAYROUTE )', 'IVAAR HOSPITALITY PRIVATE LIMITED ( BAYROUTE )', '0'),
(1168, 3139, 'T H MUMBAI RESTAURANTS LLP', 'T H MUMBAI RESTAURANTS LLP', '0'),
(1169, 3140, 'YOGA HOUSE CAFE', 'YOGA HOUSE CAFE', '0'),
(1170, 3141, 'THE CRAFTERS', 'THE CRAFTERS', '0'),
(1171, 3142, 'BLUE FROG HOSPITALITY PVT LTD (BOTECO)', 'BLUE FROG HOSPITALITY PVT LTD (BOTECO)', '0'),
(1172, 3143, 'AGA HOSPITALITY PVT LTD', 'AGA HOSPITALITY PVT LTD', '0'),
(1173, 3144, 'MIZU - CULINARY DISCIPLES', 'MIZU - CULINARY DISCIPLES', '0'),
(1174, 3145, 'QUALIA HOSPITALITY LLP', 'QUALIA HOSPITALITY LLP', '0'),
(1175, 3146, 'THE INDIAN FILM COMBINE PVT LTD', 'THE INDIAN FILM COMBINE PVT LTD', '0'),
(1176, 3147, 'BASTIAN HOSPITALITY PVT LTD', 'BASTIAN HOSPITALITY PVT LTD', '0'),
(1177, 3148, 'WHITE HAT WINE ', 'WHITE HAT WINE ', '0'),
(1178, 3149, 'KASA FOODWORKS', 'KASA FOODWORKS', '0'),
(1179, 3150, 'M/S BOTONICA CAFE AND DINER', 'M/S BOTONICA CAFE AND DINER', '0'),
(1180, 3151, 'SAURASHTRA CEMENTS LIMITED', 'SAURASHTRA CEMENTS LIMITED', '0'),
(1181, 3152, 'BHAVIK BHIMJYANI', 'BHAVIK BHIMJYANI', '0'),
(1182, 3153, 'ZOUT HOSPITALITY', 'ZOUT HOSPITALITY', '0'),
(1183, 3154, 'SIKKA PORTS ', 'SIKKA PORTS ', '0'),
(1184, 3155, 'MISS ANU', 'MISS ANU', '0'),
(1185, 3156, 'MISS SANJANA BATRA', 'MISS SANJANA BATRA', '0'),
(1186, 3157, 'MR.MEIL SEHGAL', 'MR.MEIL SEHGAL', '0'),
(1187, 3158, 'ZEN CAFE', 'ZEN CAFE', '0'),
(1188, 3159, 'KGN FOODS', 'KGN FOODS', '0'),
(1189, 2279, 'SWAPNAJYOTI TRADING PRIVATE LIMITED', 'SWAPNAJYOTI TRADING PRIVATE LIMITED', '0'),
(1190, 1407, 'NYX HOSPITALITY  PVT LTD (URD)', 'NYX HOSPITALITY  PVT LTD (URD)', '0'),
(1191, 2308, 'NRR HOSPITALITY', 'NRR HOSPITALITY', '0'),
(1192, 1736, 'METRO BURGER', 'METRO BURGER', '0'),
(1193, 886, 'SURBHI CATERERS (URD)', 'SURBHI CATERERS (URD)', '0'),
(1194, 2434, 'TASTE BUDS', 'TASTE BUDS', '0'),
(1195, 3160, 'NIKHIL CORPORTION', 'NIKHIL CORPORTION', '0'),
(1196, 3161, 'PARAS ENTERPRISES', 'PARAS ENTERPRISES', '0'),
(1197, 1213, 'AMI CAKES', 'AMI CAKES', '0'),
(1198, 3162, 'BANGLORE IYENGER BAKERY (KAMANI)', 'BANGLORE IYENGER BAKERY (KAMANI)', '0'),
(1199, 3163, 'CHETNA CATERERS', 'CHETNA CATERERS', '0'),
(1200, 3164, 'JB ENTERPRISESES', 'JB ENTERPRISESES', '0'),
(1201, 3165, 'CEREMONIAL KITCHEN', 'CEREMONIAL KITCHEN', '0'),
(1202, 2863, 'GRANVILLE HOTEL PVT LTD', 'GRANVILLE HOTEL PVT LTD', '0'),
(1203, 3166, 'I`M VADA PAV STORE', 'I`M VADA PAV STORE', '0'),
(1204, 3167, 'KRSNA THE WELLNESS SPA PVT LTD', 'KRSNA THE WELLNESS SPA PVT LTD', '0'),
(1205, 3168, 'PIZZA CAPRINA (SANTACRUZ)', 'PIZZA CAPRINA (SANTACRUZ)', '0'),
(1206, 722, 'GUILT TRIP', 'GUILT TRIP', '0'),
(1207, 2109, 'O B HOSPITALITIES PRIVATE LIMITED', 'O B HOSPITALITIES PRIVATE LIMITED', '0'),
(1208, 1605, 'SUKH HOTEL', 'SUKH HOTEL', '0'),
(1209, 3169, 'ARCS SANDWICHES PVT LTD', 'ARCS SANDWICHES PVT LTD', '0'),
(1210, 3170, 'HOTEL MELUHA, A DIVISION OF MELRONIA HOSPITALITY PRIVATE LIMITED', 'HOTEL MELUHA, A DIVISION OF MELRONIA HOSPITALITY PRIVATE LIMITED', '0'),
(1211, 3171, 'HOTEL RODAS, A DIVISION OF MELRONIA HOSPITALITY PRIVATE LIMITED', 'HOTEL RODAS, A DIVISION OF MELRONIA HOSPITALITY PRIVATE LIMITED', '0'),
(1212, 570, 'UDAIPURWALA AND SONS', 'UDAIPURWALA AND SONS', '0'),
(1213, 3172, 'CASH SALES V', 'CASH SALES V', '0'),
(1214, 3173, 'ACE AIM ENTERPRISE', 'ACE AIM ENTERPRISE', '0'),
(1215, 3174, 'MENSE AND COMPANY', 'MENSE AND COMPANY', '0'),
(1216, 3175, 'LE MILL', 'LE MILL', '0'),
(1217, 3176, 'MR DEEPAK MIRCHANDANI', 'MR DEEPAK MIRCHANDANI', '0'),
(1218, 3177, 'RTC RESTAURANT INDIA LTD', 'RTC RESTAURANT INDIA LTD', '0'),
(1219, 3178, 'MR.ANU GOYAL', 'MR.ANU GOYAL', '0'),
(1220, 3179, 'M/S BUTTERFLY HIGH', 'M/S BUTTERFLY HIGH', '0'),
(1221, 3180, 'MS DEEPA PARDASANI', 'MS DEEPA PARDASANI', '0'),
(1222, 3181, 'EXCELLENT SPICES', 'EXCELLENT SPICES', '0'),
(1223, 3182, 'KUNDAN FISH MERCHANT', 'KUNDAN FISH MERCHANT', '0'),
(1224, 3183, 'R STEAM HOT', 'R STEAM HOT', '0'),
(1225, 3184, 'TOUM UNIT OF IYENGAR M HOSPITALITY LLP', 'TOUM UNIT OF IYENGAR M HOSPITALITY LLP', '0'),
(1226, 2564, 'K 3 M HOSPITALITY PVT LTD', 'K 3 M HOSPITALITY PVT LTD', '0'),
(1227, 3185, 'M K ENTERPRISE', 'M K ENTERPRISE', '0'),
(1228, 3186, 'SNEHA JAGIASI', 'SNEHA JAGIASI', '0'),
(1229, 3187, 'MEET ENTERPRISE', 'MEET ENTERPRISE', '0'),
(1230, 1592, 'PRITAM RESTAURANT ', 'PRITAM RESTAURANT ', '0'),
(1231, 3188, 'USHA JAIN (URD)', 'USHA JAIN (URD)', '0'),
(1232, 962, 'BISCUITWALA ', 'BISCUITWALA ', '0'),
(1233, 3189, 'JAI MATA DI HOME CONSTRUCTION PRIVATE LIMITED', 'JAI MATA DI HOME CONSTRUCTION PRIVATE LIMITED', '0'),
(1234, 3190, 'N S HOSPITALITY', 'N S HOSPITALITY', '0'),
(1235, 3191, 'ANA DESIGNS PRIVATE LIMITED', 'ANA DESIGNS PRIVATE LIMITED', '0'),
(1236, 3192, 'INFINITY HOSPITALITY VENTURES', 'INFINITY HOSPITALITY VENTURES', '0'),
(1237, 3193, 'BROWNSALT', 'BROWNSALT', '0'),
(1238, 2584, 'TAPRI - THE CAFE', 'TAPRI - THE CAFE', '0'),
(1239, 2567, 'UDDHAV GANAGE (URD)', 'UDDHAV GANAGE (URD)', '0'),
(1240, 3194, 'HOUSE OF SALADS', 'HOUSE OF SALADS', '0'),
(1241, 3195, 'MR. SURENDRA KAILASH', 'MR. SURENDRA KAILASH', '0'),
(1242, 1700, 'NOVA REGAL (URD)', 'NOVA REGAL (URD)', '0'),
(1243, 382, 'PM ENTERPRISE (CHEDDA FOOD SPOT)', 'PM ENTERPRISE (CHEDDA FOOD SPOT)', '0'),
(1244, 3196, 'CAFE FOOD FOR THOUGHT LLP', 'CAFE FOOD FOR THOUGHT LLP', '0'),
(1245, 3197, 'CHOCOBRELLA', 'CHOCOBRELLA', '0'),
(1246, 2734, 'BIG BINGE CO.', 'BIG BINGE CO.', '0'),
(1247, 3198, 'CRESTAR INTERNATIONAL', 'CRESTAR INTERNATIONAL', '0'),
(1248, 3199, 'COUNTRY INNS ', 'COUNTRY INNS ', '0'),
(1249, 2851, 'INTERCONTINENTAL MARINE DRIVE MUM            RS', 'INTERCONTINENTAL MARINE DRIVE MUM            RS', '0'),
(1250, 2789, 'BAKERSVILLE INDIA PVT LTD-- CUSTOMER', 'BAKERSVILLE INDIA PVT LTD-- CUSTOMER', '0'),
(1251, 3200, 'REVOLUTION FOODS PVT LTD (HUNGER HEAD)', 'REVOLUTION FOODS PVT LTD (HUNGER HEAD)', '0'),
(1252, 3201, 'THE BOSTON BUTT', 'THE BOSTON BUTT', '0'),
(1253, 3202, 'HDC INDIA PRIVATE LIMITED', 'HDC INDIA PRIVATE LIMITED', '0'),
(1254, 3203, 'DINERAMA PVT LTD', 'DINERAMA PVT LTD', '0'),
(1255, 826, 'SITARA RESTAURANT', 'SITARA RESTAURANT', '0'),
(1256, 3204, 'BEYOND WAFFLES', 'BEYOND WAFFLES', '0'),
(1257, 2246, 'KALA GHODA CAFE', 'KALA GHODA CAFE', '0'),
(1258, 2998, 'RAJARAM GUPTA', 'RAJARAM GUPTA', '0'),
(1259, 3205, 'V.N.CATERS', 'V.N.CATERS', '0'),
(1260, 3206, 'BARBEQUE NATIONAL HOSPITALITY LIMITED--VIRAR', 'BARBEQUE NATIONAL HOSPITALITY LIMITED--VIRAR', '0'),
(1261, 3207, 'AMIT SADH', 'AMIT SADH', '0'),
(1262, 3208, 'IBIS NAVI MUMBAI-UNIT OF INTERGLOBE HOTELS PVT.LTD.', 'IBIS NAVI MUMBAI-UNIT OF INTERGLOBE HOTELS PVT.LTD.', '0'),
(1263, 2382, 'THX FOODCRAFT', 'THX FOODCRAFT', '0'),
(1264, 2831, 'INSPIRE RESTRO -PUB LLP', 'INSPIRE RESTRO -PUB LLP', '0'),
(1265, 2319, 'BOSTAN (URD)', 'BOSTAN (URD)', '0'),
(1266, 2561, 'CHERRY ON TOP', 'CHERRY ON TOP', '0'),
(1267, 1208, 'TAO 9 (URD)', 'TAO 9 (URD)', '0'),
(1268, 2124, 'BURGER FRIES FACTORY', 'BURGER FRIES FACTORY', '0'),
(1269, 3209, 'OCCASION CAKE SHOP (BORIVALI)', 'OCCASION CAKE SHOP (BORIVALI)', '0'),
(1270, 3210, 'SARAF  CORPORATION INDIAN PVT LTD', 'SARAF  CORPORATION INDIAN PVT LTD', '0'),
(1271, 855, 'SEVEN ELEVEN', 'SEVEN ELEVEN', '0'),
(1272, 2530, 'THE CAKE FARM', 'THE CAKE FARM', '0'),
(1273, 719, 'HOTEL SAHIL PVT LTD', 'HOTEL SAHIL PVT LTD', '0'),
(1274, 1289, 'PREM SAGAR DOSA PLAZA PVT LTD', 'PREM SAGAR DOSA PLAZA PVT LTD', '0'),
(1275, 3211, 'SWEET TOOTH (LONDON BUBBLE)', 'SWEET TOOTH (LONDON BUBBLE)', '0'),
(1276, 3212, 'STRATIX HOSPITALITY PRIVATE LIMITED', 'STRATIX HOSPITALITY PRIVATE LIMITED', '0'),
(1277, 1744, 'CERES HOSPITALITY PVT LTD', 'CERES HOSPITALITY PVT LTD', '0'),
(1278, 3213, 'RANG SHARDA HOTELS PRIVATE LIMITED', 'RANG SHARDA HOTELS PRIVATE LIMITED', '0'),
(1279, 3214, 'SUBHRA VICTUS SOLUTIONS', 'SUBHRA VICTUS SOLUTIONS', '0'),
(1280, 3215, 'LOVE SUGAR DOUGH PVT LTD', 'LOVE SUGAR DOUGH PVT LTD', '0'),
(1281, 3216, 'STRATIX HOSPITALITY PRIVATE LIMITED( ISHARA RESTAURANT )', 'STRATIX HOSPITALITY PRIVATE LIMITED( ISHARA RESTAURANT )', '0'),
(1282, 1951, 'JYOTI STORE--ULHASNAGAR', 'JYOTI STORE--ULHASNAGAR', '0'),
(1283, 3217, 'STAR ENTERPRISES', 'STAR ENTERPRISES', '0'),
(1284, 2666, 'SWEET SECRET', 'SWEET SECRET', '0'),
(1285, 320, 'HOTEL GRAND CENTRAL', 'HOTEL GRAND CENTRAL', '0'),
(1286, 1265, 'CASH SALE(T.A)                    RW', 'CASH SALE(T.A)                    RW', '0'),
(1287, 784, 'ABHINEHA ENTERPRISES', 'ABHINEHA ENTERPRISES', '0'),
(1288, 3218, 'MRS ANU GOYAL', 'MRS ANU GOYAL', '0'),
(1289, 3219, 'FLAVOURITO', 'FLAVOURITO', '0'),
(1290, 519, 'JYOTI REFRESHMENT', 'JYOTI REFRESHMENT', '0'),
(1291, 3220, 'M/S GODREJ INDUSTRIES LTD.', 'M/S GODREJ INDUSTRIES LTD.', '0'),
(1292, 1073, 'HOTEL TUNGA INTERNATIONAL', 'HOTEL TUNGA INTERNATIONAL', '0'),
(1293, 3221, 'JEWEL OF CHEMBUR ( CHEMBUR GYMKHANA)', 'JEWEL OF CHEMBUR ( CHEMBUR GYMKHANA)', '0'),
(1294, 2306, 'NALIN ', 'NALIN ', '0'),
(1295, 3222, 'HILTON MUMBAI INTERNATIONAL AIRPORT', 'HILTON MUMBAI INTERNATIONAL AIRPORT', '0'),
(1296, 3223, 'NATASHA KAPADIA', 'NATASHA KAPADIA', '0'),
(1297, 3224, 'MERMAID ENTERPRISE', 'MERMAID ENTERPRISE', '0'),
(1298, 3225, 'AUSH ENTERPRISES', 'AUSH ENTERPRISES', '0'),
(1299, 3226, 'SIDDH ENTERPRISE', 'SIDDH ENTERPRISE', '0'),
(1300, 3227, 'MAGIC CUISINES HOSPITALITY PVT LTD', 'MAGIC CUISINES HOSPITALITY PVT LTD', '0'),
(1301, 3228, 'CHAI SUTTA BAR', 'CHAI SUTTA BAR', '0'),
(1302, 3229, 'CRISP SERVICES', 'CRISP SERVICES', '0'),
(1303, 3230, 'VENTURE PROFESSIONAL', 'VENTURE PROFESSIONAL', '0'),
(1304, 1323, 'AUGUST FOOD COMPANY', 'AUGUST FOOD COMPANY', '0'),
(1305, 3231, 'DUA HOSPITALITY', 'DUA HOSPITALITY', '0'),
(1306, 3232, 'FUN (N) FOOD RESTAURANT', 'FUN (N) FOOD RESTAURANT', '0'),
(1307, 1898, 'OM GANESHA CATERERS', 'OM GANESHA CATERERS', '0'),
(1308, 1310, 'TEAFLECTIONS PVT LTD', 'TEAFLECTIONS PVT LTD', '0'),
(1309, 3233, 'URBAN JALSA', 'URBAN JALSA', '0'),
(1310, 3234, 'MR KEDIA JI', 'MR KEDIA JI', '0'),
(1311, 2823, 'FELISITAZ ENTERPRISES', 'FELISITAZ ENTERPRISES', '0'),
(1312, 3235, 'SUSHIL CATERERS', 'SUSHIL CATERERS', '0'),
(1313, 2481, 'SHARANAM HOTELS AND RESORT PVT LTD', 'SHARANAM HOTELS AND RESORT PVT LTD', '0'),
(1314, 3236, 'KGN CORPORATION', 'KGN CORPORATION', '0'),
(1315, 1404, 'NOTEBOOK EXPRESS- CUSTOMER', 'NOTEBOOK EXPRESS- CUSTOMER', '0'),
(1316, 3237, 'MARS HOTELS AND RESORTS PVT LTD', 'MARS HOTELS AND RESORTS PVT LTD', '0'),
(1317, 3238, 'BAKERS CRAFT', 'BAKERS CRAFT', '0'),
(1318, 3239, 'BRICKS N SANDS', 'BRICKS N SANDS', '0'),
(1319, 3240, 'YUMMY DIP', 'YUMMY DIP', '0'),
(1320, 2349, 'REDEL FOOD AND BEVERAGES PVT LTD', 'REDEL FOOD AND BEVERAGES PVT LTD', '0'),
(1321, 3241, 'MR. ANAND MAHINDRA', 'MR. ANAND MAHINDRA', '0'),
(1322, 3242, 'MRS. MALA WADWANI', 'MRS. MALA WADWANI', '0'),
(1323, 1839, 'SHIVANI BAKERS â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', 'SHIVANI BAKERS â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹â‚¹', '0'),
(1324, 3243, 'LOTUS POND HOTEL PRIVATE LIMITED', 'LOTUS POND HOTEL PRIVATE LIMITED', '0'),
(1325, 3244, 'MS RASHMI', 'MS RASHMI', '0'),
(1326, 3245, 'MRS PANTHAKI', 'MRS PANTHAKI', '0'),
(1327, 3246, 'MR JACAB', 'MR JACAB', '0'),
(1328, 3247, 'MRS. ISHA AMBANI', 'MRS. ISHA AMBANI', '0'),
(1329, 1732, 'SHIVA FAST FOOD', 'SHIVA FAST FOOD', '0'),
(1330, 3248, 'BUNDL TECHNOLOGIES PRIVATE LTD', 'BUNDL TECHNOLOGIES PRIVATE LTD', '0'),
(1331, 1584, 'SAIFEE HOSPITAL', 'SAIFEE HOSPITAL', '0'),
(1332, 1478, 'SHREE NAKODA --GOREGAON', 'SHREE NAKODA --GOREGAON', '0'),
(1333, 3249, 'BLUE MARINE SEA FOOD', 'BLUE MARINE SEA FOOD', '0'),
(1334, 3250, 'FRESH MART', 'FRESH MART', '0'),
(1335, 3251, 'GATHERING GROUND (CAFE ', 'GATHERING GROUND (CAFE ', '0'),
(1336, 3252, 'LAMBENT ENTERPRISES', 'LAMBENT ENTERPRISES', '0'),
(1337, 3253, 'MICKY MOUSE CAKES AND MORE', 'MICKY MOUSE CAKES AND MORE', '0'),
(1338, 3254, 'SOUL FOODS ( PIZZA BOX )', 'SOUL FOODS ( PIZZA BOX )', '0'),
(1339, 3255, 'THE FOOD BLOG', 'THE FOOD BLOG', '0'),
(1340, 3256, 'TWELVE TABLE', 'TWELVE TABLE', '0'),
(1341, 2044, 'BIKS HOSPITALITY ', 'BIKS HOSPITALITY ', '0'),
(1342, 2725, 'BOMBAY HOSPITAL', 'BOMBAY HOSPITAL', '0'),
(1343, 2415, 'PROP. SUBODH THAKKAR (WOW)', 'PROP. SUBODH THAKKAR (WOW)', '0'),
(1344, 702, 'PALLAZZIO HOTELS ', 'PALLAZZIO HOTELS ', '0'),
(1345, 3257, 'MR NAVEEN KAPOOR', 'MR NAVEEN KAPOOR', '0'),
(1346, 3258, 'MRS ANURADHA MAHINDRA', 'MRS ANURADHA MAHINDRA', '0'),
(1347, 2670, 'SAMPLING ACCOUNT --RICH\'S', 'SAMPLING ACCOUNT --RICH\'S', '0'),
(1348, 3259, 'JASON KOTHARI', 'JASON KOTHARI', '0'),
(1349, 3260, 'BALAJI AGENCIES (NAGPUR)', 'BALAJI AGENCIES (NAGPUR)', '0'),
(1350, 3261, 'ICESTASY PROJECTS PVT LTD', 'ICESTASY PROJECTS PVT LTD', '0'),
(1351, 2945, 'MRS. SHWETA MUNDEKAR', 'MRS. SHWETA MUNDEKAR', '0'),
(1352, 3263, 'KOSMIC SEA LOUNGE', 'KOSMIC SEA LOUNGE', '0'),
(1353, 3264, 'MUNCHESTER', 'MUNCHESTER', '0'),
(1354, 3265, 'AAMANTARAN FINE DINE', 'AAMANTARAN FINE DINE', '0'),
(1355, 3266, 'SS FOODS', 'SS FOODS', '0'),
(1356, 3267, 'ASSOCIATED ALCOHOLS AND BREWERIES LIMITED', 'ASSOCIATED ALCOHOLS AND BREWERIES LIMITED', '0'),
(1357, 3268, 'HOTEL HARBOUR VIEW', 'HOTEL HARBOUR VIEW', '0'),
(1358, 2413, 'UNITED COLD STORAGE', 'UNITED COLD STORAGE', '0'),
(1359, 3269, 'BOSCH LIMITED', 'BOSCH LIMITED', '0'),
(1360, 3270, 'LAXMI CHHAYA', 'LAXMI CHHAYA', '0'),
(1361, 3271, 'OFFICE PULSE TECHNOLOGY PVT LTD', 'OFFICE PULSE TECHNOLOGY PVT LTD', '0'),
(1362, 3272, 'MAHARASHTRA SEAMLESS LIMITED', 'MAHARASHTRA SEAMLESS LIMITED', '0'),
(1363, 418, 'SHIV DURGA CATERERS PVT LTD', 'SHIV DURGA CATERERS PVT LTD', '0'),
(1364, 3273, 'AL BAIK FAST FOOD', 'AL BAIK FAST FOOD', '0'),
(1365, 3274, 'BANGLORE IYENGER BAKERY ( KALACHOWKI )', 'BANGLORE IYENGER BAKERY ( KALACHOWKI )', '0'),
(1366, 3275, 'SHAKES ', 'SHAKES ', '0'),
(1367, 1720, 'SHREE MORYA TRADING', 'SHREE MORYA TRADING', '0'),
(1368, 3276, 'THE BOGETO CAFE', 'THE BOGETO CAFE', '0'),
(1369, 2518, 'JANTA BAKERS', 'JANTA BAKERS', '0'),
(1370, 2283, 'RUCHOKS', 'RUCHOKS', '0'),
(1371, 2346, 'THE CAKE WORLD', 'THE CAKE WORLD', '0'),
(1372, 2379, 'CONSTROCHEM', 'CONSTROCHEM', '0'),
(1373, 3277, 'MR.ANAND SAXENA', 'MR.ANAND SAXENA', '0'),
(1374, 3278, 'CASH SALE (MT)', 'CASH SALE (MT)', '0'),
(1375, 3279, 'CHEZ SHARON PATISSERIE', 'CHEZ SHARON PATISSERIE', '0'),
(1376, 732, 'SADGURU PURE VEG RESTAURENT', 'SADGURU PURE VEG RESTAURENT', '0'),
(1377, 3280, 'HAKKAS KAFE', 'HAKKAS KAFE', '0'),
(1378, 3281, 'MAGIC TOUCH DELIGHT', 'MAGIC TOUCH DELIGHT', '0'),
(1379, 3282, 'OWLBLACK FOODS PRODUCTS PVT LTD', 'OWLBLACK FOODS PRODUCTS PVT LTD', '0'),
(1380, 3283, 'PLENTY BRIGHT LLP', 'PLENTY BRIGHT LLP', '0'),
(1381, 3284, 'AUMI GRANDERA', 'AUMI GRANDERA', '0'),
(1382, 3285, 'HOWRA BURGER (BANDRA)', 'HOWRA BURGER (BANDRA)', '0'),
(1383, 3286, 'KANCHAN BHAGOTRA', 'KANCHAN BHAGOTRA', '0'),
(1384, 3287, 'VR ENTERPRISES', 'VR ENTERPRISES', '0'),
(1385, 3288, 'MS SHRADDHA KAPOOR', 'MS SHRADDHA KAPOOR', '0'),
(1386, 535, 'THE LAUGHTER CHAPTER', 'THE LAUGHTER CHAPTER', '0'),
(1387, 3289, 'SUNNY SOUND PVT LTD', 'SUNNY SOUND PVT LTD', '0'),
(1388, 3290, 'CUPS N CONES (CUST)', 'CUPS N CONES (CUST)', '0'),
(1389, 1904, 'BRAINFREEZE', 'BRAINFREEZE', '0'),
(1390, 3291, 'ELIXIR FOOD\'S ( LONDON BUBBLE CO. FRANCHISE OUTLET )', 'ELIXIR FOOD\'S ( LONDON BUBBLE CO. FRANCHISE OUTLET )', '0'),
(1391, 3292, 'YELLOW ORANGE', 'YELLOW ORANGE', '0'),
(1392, 2094, 'RAMA FAST FOOD', 'RAMA FAST FOOD', '0'),
(1393, 1446, 'SAFFRON THE CAKE SHOP', 'SAFFRON THE CAKE SHOP', '0'),
(1394, 873, 'THE LALIT MUMBAI', 'THE LALIT MUMBAI', '0'),
(1395, 1806, 'CFB FRESH DELIGHT', 'CFB FRESH DELIGHT', '0'),
(1396, 772, 'GAUTAMRESTAURANT', 'GAUTAMRESTAURANT', '0'),
(1397, 323, 'HOTEL SEALORD', 'HOTEL SEALORD', '0'),
(1398, 176, 'LEVEL 5, THE DESTINATION', 'LEVEL 5, THE DESTINATION', '0'),
(1399, 1769, 'OCCASION CAKE SHOP PVT LTD', 'OCCASION CAKE SHOP PVT LTD', '0'),
(1400, 3293, 'CHOICE BAKERS OLD', 'CHOICE BAKERS OLD', '0'),
(1401, 3262, 'INNOVATIVE GASTRONOMY', 'INNOVATIVE GASTRONOMY', '0'),
(1402, 358, 'BAKES ', 'BAKES ', '0'),
(1403, 453, 'JKR FOODS', 'JKR FOODS', '0'),
(1404, 3294, 'ALAN TIMS', 'ALAN TIMS', '0'),
(1405, 3295, 'RASHMI UDAY SINGH', 'RASHMI UDAY SINGH', '0'),
(1406, 3296, 'SHREEJI SERVICES', 'SHREEJI SERVICES', '0'),
(1407, 3297, 'MAHINDRA ', 'MAHINDRA ', '0'),
(1408, 3298, 'AROMA THE BAKE SHOP', 'AROMA THE BAKE SHOP', '0'),
(1409, 3299, 'MR. MITHUL DESAI', 'MR. MITHUL DESAI', '0'),
(1410, 3300, 'PAMMVI EXPORTS PVT LTD', 'PAMMVI EXPORTS PVT LTD', '0'),
(1411, 3301, 'CZAR BAKERY (URD)', 'CZAR BAKERY (URD)', '0'),
(1412, 3302, '6-GON ', '6-GON ', '0'),
(1413, 3303, 'BAKES ', 'BAKES ', '0'),
(1414, 3304, 'HENZ', 'HENZ', '0'),
(1415, 404, 'SAI PALACE HOTEL', 'SAI PALACE HOTEL', '0'),
(1416, 3305, 'DASTUR VENTURES LLP', 'DASTUR VENTURES LLP', '0'),
(1417, 3306, 'VIRA INTERNATIONAL PLACEMENTS PRIVATE LIMITED', 'VIRA INTERNATIONAL PLACEMENTS PRIVATE LIMITED', '0'),
(1418, 3307, 'CEAT LIMITED', 'CEAT LIMITED', '0'),
(1419, 2388, 'CAFE DLITE', 'CAFE DLITE', '0'),
(1420, 3308, 'CELEBRATION SURPRISE', 'CELEBRATION SURPRISE', '0'),
(1421, 3309, 'FRIES BEFORE GUYS 2', 'FRIES BEFORE GUYS 2', '0'),
(1422, 3310, 'MAA DURGA AGENCY', 'MAA DURGA AGENCY', '0'),
(1423, 3311, 'AARAMBH ENTERPRISES (WOW)', 'AARAMBH ENTERPRISES (WOW)', '0'),
(1424, 3312, 'EUPHORIYA HOSPITALITYPVT LTD', 'EUPHORIYA HOSPITALITYPVT LTD', '0'),
(1425, 3313, 'MR.AMIT SAWANT', 'MR.AMIT SAWANT', '0'),
(1426, 365, 'FULL HOUSE RESTAURENT PVT LTD', 'FULL HOUSE RESTAURENT PVT LTD', '0'),
(1427, 2886, 'HOGGERS ', 'HOGGERS ', '0'),
(1428, 3314, 'NICE CAKES AND SWEETS CONFECTIONERS', 'NICE CAKES AND SWEETS CONFECTIONERS', '0'),
(1429, 3315, 'SHREE OM SAI DISTRIBUTOR', 'SHREE OM SAI DISTRIBUTOR', '0'),
(1430, 3316, 'YOUNGIZINE FOODS LLP', 'YOUNGIZINE FOODS LLP', '0'),
(1431, 929, 'B AND D CORPORATION', 'B AND D CORPORATION', '0'),
(1432, 3317, 'LIGHT HOUSE MFG CO', 'LIGHT HOUSE MFG CO', '0'),
(1433, 3318, 'HOTEL HARBOUR VIEW ( PIZZO A/C)', 'HOTEL HARBOUR VIEW ( PIZZO A/C)', '0'),
(1434, 3319, '6-GON ', '6-GON ', '0'),
(1435, 909, 'SIN CITY CAKES AND BAKES', 'SIN CITY CAKES AND BAKES', '0'),
(1436, 3320, 'ABSOLUTE BARBEQUE PVT LTD', 'ABSOLUTE BARBEQUE PVT LTD', '0'),
(1437, 3321, 'EXITO FOODS', 'EXITO FOODS', '0'),
(1438, 3322, 'IRISS (YELLOW BANANA)', 'IRISS (YELLOW BANANA)', '0'),
(1439, 3323, 'SEVENSEAS HOSPITALITY GROUP (PIZZO ACC)', 'SEVENSEAS HOSPITALITY GROUP (PIZZO ACC)', '0'),
(1440, 3324, 'BOMBAY RULES', 'BOMBAY RULES', '0'),
(1441, 3325, 'LOCCO EATERY ', 'LOCCO EATERY ', '0'),
(1442, 3326, 'SHRIMAD RAJCHANDRA PRASADGRUHA', 'SHRIMAD RAJCHANDRA PRASADGRUHA', '0'),
(1443, 3327, 'TRIDENT HOSPITALITY SERVICES (LONDON BUBBLE)', 'TRIDENT HOSPITALITY SERVICES (LONDON BUBBLE)', '0'),
(1444, 1204, 'ARIF MALAD', 'ARIF MALAD', '0'),
(1445, 3328, 'EXPERT TIME INDUSTRIES PVT LTD', 'EXPERT TIME INDUSTRIES PVT LTD', '0'),
(1446, 3329, 'FRUITOZAA', 'FRUITOZAA', '0'),
(1447, 2276, 'CHINA GATE RESTAURANTS PVT. LTD', 'CHINA GATE RESTAURANTS PVT. LTD', '0'),
(1448, 3330, 'INDIAN WAFFLES', 'INDIAN WAFFLES', '0'),
(1449, 1210, 'MIHIR CHOCOLATE (URD)', 'MIHIR CHOCOLATE (URD)', '0'),
(1450, 3331, 'PILLION RIDER LLP', 'PILLION RIDER LLP', '0'),
(1451, 3332, 'FOOD ', 'FOOD ', '0'),
(1452, 3333, 'CENTRAL CATERERS', 'CENTRAL CATERERS', '0'),
(1453, 3334, 'ARIF FAZLANI', 'ARIF FAZLANI', '0'),
(1454, 3335, 'ESSCHEM PVT LTD', 'ESSCHEM PVT LTD', '0'),
(1455, 1225, 'CORUM HOSPITALITY', 'CORUM HOSPITALITY', '0'),
(1456, 1274, 'DEEPAK RESTAURANT', 'DEEPAK RESTAURANT', '0'),
(1457, 3336, 'LALCO RESIDENCY', 'LALCO RESIDENCY', '0'),
(1458, 3337, 'INDIA CAKES', 'INDIA CAKES', '0'),
(1459, 3338, 'RAMA FOODS', 'RAMA FOODS', '0'),
(1460, 3339, 'SACHHI PIZZERIA', 'SACHHI PIZZERIA', '0'),
(1461, 2814, 'CAFE ARPAN', 'CAFE ARPAN', '0'),
(1462, 3340, 'COCOATEASE', 'COCOATEASE', '0'),
(1463, 437, 'URBAN GOURMET INDIA PVT LTD', 'URBAN GOURMET INDIA PVT LTD', '0'),
(1464, 3341, 'MRS NANDITA SHAH', 'MRS NANDITA SHAH', '0'),
(1465, 3342, 'HOTEL SAHIL PVT LTD(PIZZO A/C)', 'HOTEL SAHIL PVT LTD(PIZZO A/C)', '0'),
(1466, 3343, 'N S HOSPITALITY(PIZZO A/C)', 'N S HOSPITALITY(PIZZO A/C)', '0'),
(1467, 3344, 'KAMDAR PVT LTD', 'KAMDAR PVT LTD', '0'),
(1468, 3345, 'HOTEL OM TUNGA VIHAR', 'HOTEL OM TUNGA VIHAR', '0'),
(1469, 2667, 'HOTEL TUNGA REGENCY PVT LTD', 'HOTEL TUNGA REGENCY PVT LTD', '0'),
(1470, 704, 'FORTUNE PARK LAKECITY', 'FORTUNE PARK LAKECITY', '0'),
(1471, 3346, 'IRISS', 'IRISS', '0'),
(1472, 3347, 'TEXMEX CUISINE INDIA PVT LTD', 'TEXMEX CUISINE INDIA PVT LTD', '0'),
(1473, 3348, 'SPECIALITY FOODS', 'SPECIALITY FOODS', '0'),
(1474, 1226, 'TBSE HOTELS PVT LTD', 'TBSE HOTELS PVT LTD', '0'),
(1475, 237, 'SAI GLOBAL SERVICES', 'SAI GLOBAL SERVICES', '0'),
(1476, 126, 'THE BEST CAKE \'S', 'THE BEST CAKE \'S', '0'),
(1477, 3349, 'WOW FOOD BRANDS PVT LTD', 'WOW FOOD BRANDS PVT LTD', '0'),
(1478, 2340, 'CAFE URBANA', 'CAFE URBANA', '0'),
(1479, 3350, 'D\'LICIOUS FOODS', 'D\'LICIOUS FOODS', '0'),
(1480, 685, 'PISHU (URD)', 'PISHU (URD)', '0'),
(1481, 3351, 'THE CAKE BAKERS', 'THE CAKE BAKERS', '0'),
(1482, 3352, 'XOTIK HOSPITALITY', 'XOTIK HOSPITALITY', '0'),
(1483, 3353, 'M/S THIYA BISTRO AND CAFE', 'M/S THIYA BISTRO AND CAFE', '0'),
(1484, 3354, 'DLICIOUS FOODS', 'DLICIOUS FOODS', '0'),
(1485, 3355, 'CASH SALE SB', 'CASH SALE SB', '0'),
(1486, 3356, 'THE BAKERS HUB', 'THE BAKERS HUB', '0'),
(1487, 3357, 'MR.DUSHYANT SOMANI', 'MR.DUSHYANT SOMANI', '0'),
(1488, 3358, 'MISS JULIE', 'MISS JULIE', '0'),
(1489, 2600, 'BEENA FERNANDISE', 'BEENA FERNANDISE', '0'),
(1490, 3359, 'H M LIESURE', 'H M LIESURE', '0'),
(1491, 2948, 'CROWN BURGER', 'CROWN BURGER', '0'),
(1492, 3360, 'KYTA HOSPITALITY PRIVATE LIMITED', 'KYTA HOSPITALITY PRIVATE LIMITED', '0'),
(1493, 3361, 'ROYAL VALTRANS AIRPORT SERVICES INDIA PVT LTD', 'ROYAL VALTRANS AIRPORT SERVICES INDIA PVT LTD', '0'),
(1494, 3362, 'SHRI RAGHVENDRA AGENCY', 'SHRI RAGHVENDRA AGENCY', '0'),
(1495, 3363, 'UDUPI SHRI KRISHNA', 'UDUPI SHRI KRISHNA', '0'),
(1496, 3364, 'MR.GAURAV BHATIA', 'MR.GAURAV BHATIA', '0'),
(1497, 449, 'HOTEL SEA PRINCESS', 'HOTEL SEA PRINCESS', '0'),
(1498, 2642, 'ADARSH BAKERS', 'ADARSH BAKERS', '0'),
(1499, 330, 'OOH FOODS (PRABHADEVI)', 'OOH FOODS (PRABHADEVI)', '0'),
(1500, 301, 'SWEET CRUNCH', 'SWEET CRUNCH', '0'),
(1501, 1406, 'VASANT ICE CREAM', 'VASANT ICE CREAM', '0'),
(1502, 1442, 'BUENA VIDA LEISURE PVT LTD', 'BUENA VIDA LEISURE PVT LTD', '0'),
(1503, 1712, 'DEATH BY CHOCOLATE', 'DEATH BY CHOCOLATE', '0'),
(1504, 1007, 'THE PIZZA CHAIN FACTORY PVT LTD', 'THE PIZZA CHAIN FACTORY PVT LTD', '0'),
(1505, 289, 'TRINOVA HOSPITALITY SERVICES PVT LTD', 'TRINOVA HOSPITALITY SERVICES PVT LTD', '0'),
(1506, 302, 'URBAN BURGER', 'URBAN BURGER', '0'),
(1507, 224, 'HOTEL FARYAS LONAVALA', 'HOTEL FARYAS LONAVALA', '0'),
(1508, 1447, 'METRO ENTERPRISES', 'METRO ENTERPRISES', '0'),
(1509, 318, 'SID HOSPITALITY ANDHERI WEST', 'SID HOSPITALITY ANDHERI WEST', '0'),
(1510, 782, 'S R ENTERPRISES ( HOTEL SAI PALACE )', 'S R ENTERPRISES ( HOTEL SAI PALACE )', '0'),
(1511, 266, 'BEN\'S CAFE', 'BEN\'S CAFE', '0'),
(1512, 2091, 'CHOCODAY (WADALA)', 'CHOCODAY (WADALA)', '0'),
(1513, 324, 'ZIKRAH\'Z KOKO KRAFT (URD)', 'ZIKRAH\'Z KOKO KRAFT (URD)', '0'),
(1514, 1754, 'AZURE HOSPITALITY SERVICES PVT LTD(MUMBAIWAREHOUSE)', 'AZURE HOSPITALITY SERVICES PVT LTD(MUMBAIWAREHOUSE)', '0'),
(1515, 175, 'VIJAY DEEP HOTEL PVT. LTD', 'VIJAY DEEP HOTEL PVT. LTD', '0'),
(1516, 1823, 'A-ONE CAFE PRIVATE LIMITED', 'A-ONE CAFE PRIVATE LIMITED', '0'),
(1517, 1445, 'BLACK ORCHIDS PVT LTD', 'BLACK ORCHIDS PVT LTD', '0'),
(1518, 2119, 'RAMANI HOTELS LTD', 'RAMANI HOTELS LTD', '0'),
(1519, 1689, 'CHOCLATO (UNREGISTER DEALER-NO VAT TIN)', 'CHOCLATO (UNREGISTER DEALER-NO VAT TIN)', '0'),
(1520, 789, 'CHEFTOON FOOD SOLUTIONS', 'CHEFTOON FOOD SOLUTIONS', '0'),
(1521, 202, 'CHOCOLATE FOUNTAIN', 'CHOCOLATE FOUNTAIN', '0'),
(1522, 206, 'F J ENTERPRISE', 'F J ENTERPRISE', '0'),
(1523, 2034, 'K.A.F.E', 'K.A.F.E', '0'),
(1524, 322, 'TWENTY NINE RESTAURANTS (URD)', 'TWENTY NINE RESTAURANTS (URD)', '0'),
(1525, 3365, 'NIRAJ SARAF', 'NIRAJ SARAF', '0'),
(1526, 3366, 'THE NEW INDIA ASSURANCE COMPANY LIMITED', 'THE NEW INDIA ASSURANCE COMPANY LIMITED', '0'),
(1527, 3367, 'TINA RAZZAQ', 'TINA RAZZAQ', '0'),
(1528, 2515, 'THE BLUE PLATE', 'THE BLUE PLATE', '0'),
(1529, 3368, 'GREEN STAR CONCEPTS PVT LTD', 'GREEN STAR CONCEPTS PVT LTD', '0');
INSERT INTO `UNIFOOD_GROUP_PER` (`ID`, `GROUPID`, `GROUP_CODE`, `GROUP_NAME`, `MOBILE_NO`) VALUES
(1530, 3369, 'AUM FOOD INGREDIENTS', 'AUM FOOD INGREDIENTS', '0'),
(1531, 1544, 'CHALET HOTELS PVT LTD - FOUR POINTS BY SHERTON', 'CHALET HOTELS PVT LTD - FOUR POINTS BY SHERTON', '0'),
(1532, 3370, 'FOODLINK SERVICES I PVT LTD ( BANQUET DIV )', 'FOODLINK SERVICES I PVT LTD ( BANQUET DIV )', '0'),
(1533, 3371, 'KATYAYINI HOSPITALITY', 'KATYAYINI HOSPITALITY', '0'),
(1534, 1782, 'SADGURU HOTEL', 'SADGURU HOTEL', '0'),
(1535, 891, 'NEIGHBOURHOOD HOSPITALITY', 'NEIGHBOURHOOD HOSPITALITY', '0'),
(1536, 2502, 'BLISS OF CHOCOLATE PVT LTD', 'BLISS OF CHOCOLATE PVT LTD', '0');

-- --------------------------------------------------------

--
-- Table structure for table `UNIT_MST`
--

CREATE TABLE `UNIT_MST` (
  `UNIT_ID` int(11) NOT NULL,
  `UNIT_NAME` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UNIT_MST`
--

INSERT INTO `UNIT_MST` (`UNIT_ID`, `UNIT_NAME`) VALUES
(1, 'UNIT_TEST'),
(2, 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `com_code` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'INACTIVE',
  `forgot` varchar(255) DEFAULT NULL,
  `logintype` varchar(255) NOT NULL DEFAULT 'email',
  `uid` varchar(255) NOT NULL,
  `cart_id` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `com_code`, `status`, `forgot`, `logintype`, `uid`, `cart_id`) VALUES
(4, 'ansari0551', 'ansari0551@gmail.com', '1234567', '', 'ACTIVE', '1d1b28dda2d6a670dc4f6bc40392ddbf', 'email', '1b63ce0b94d1e6c9208dfc2929ab3595', '407cd67acab6d6a2a2fa61757c87603a'),
(3, 'Naresh Gwalani', 'nareshgwalani.g@gmail.com', 'vNG230113v', '', 'ACTIVE', '2eec1bbf17233eb9cad92db789a567ee', 'email', '6c02af17de7e1639bf7a311638f63d94', '1bd8e9854ab40c8cbf93464282d797e9'),
(5, 'kamlesh', 'kamleshbairagi7@gmail.com', '16021989', '', 'ACTIVE', 'bc4043579b9d83af10934eb4c579ef2e', 'email', '04b87736e1a0abda20d09f0c3a6e40b7', '31acd933bcc0143957c885aef733750c'),
(6, 'sanket', 'sanketthakkar36@gmail.com', 'sanket', '', 'ACTIVE', 'e3b4b3508fe0337cb8510ba43c61478f', 'email', '59b08537addf24044e342c21459f0153', '06308cf248674d2dabe4857f6a31815d'),
(7, 'kumar sathe', 'kumarsathe@enticeengineering.com', 'kumar123', '', 'ACTIVE', '3b0620f150d2b08732fcae2ea319d9ec', 'email', '7dbbef1e01e4d2bd0d79a2eb27c68db7', '6988e3c5d6a75b5ef14b0e88d433c58b'),
(8, 'pankaj', 'pankaj.khandagle@gmail.com', 'abcd1234', 'dcba5de6a9fbea5f53c682ce48b692e4', 'INACTIVE', '9d652b122a5be361cffbc612c3ccf31e', 'email', '80a4a7122963ec9a074e20796f441d2a', '49971b51d8e632731a2dcc05df54f0fa'),
(9, 'Naresh G Gwalani', 'jmdinfotech.2000@gmail.com', 'vNG230113v', '928c9f933d9e79b1047b29660e9a9eb0', 'INACTIVE', 'a965fda4d79271139581b6ed4310f22a', 'email', '47c5e2e076835a9d441e79809b4c8a72', 'ee2756fb74bcf4181a46641b189a9b68');

-- --------------------------------------------------------

--
-- Table structure for table `users_cart`
--

CREATE TABLE `users_cart` (
  `id` int(11) NOT NULL,
  `cart_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_cart`
--

INSERT INTO `users_cart` (`id`, `cart_id`, `uid`, `product_id`, `size`, `color`, `quantity`) VALUES
(3, '6506571921b39a3a8ce29beb2375b6f3', '41293564833272625a9689f46fe8bdf8', 8674, 'kg pouch', 'white', '1'),
(9, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 6434, 'M', 'BLACK', '1'),
(10, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 5285, 'S', 'PINK', '1'),
(12, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 5979, 'kg', 'white', '1'),
(15, '31acd933bcc0143957c885aef733750c', '04b87736e1a0abda20d09f0c3a6e40b7', 8053, 'nos Pack of 4', 'white', '1'),
(16, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 9370, 'XL', 'RED', '1'),
(17, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 6434, 'M', 'PINK', '1'),
(18, '1bd8e9854ab40c8cbf93464282d797e9', '6c02af17de7e1639bf7a311638f63d94', 3187, 'kg', 'white', '1'),
(20, '06308cf248674d2dabe4857f6a31815d', '59b08537addf24044e342c21459f0153', 3187, 'kg', 'white', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `paymentref` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `paymentmode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Pending',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'In-Processing',
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_orders`
--

INSERT INTO `users_orders` (`id`, `order_id`, `paymentref`, `paymentmode`, `payment_status`, `address`, `order_date`, `order_status`, `phone`, `total`, `uid`) VALUES
(1, 'OD2786019081970', 'Txn_7130067485cef94eb633a99.12555152', 'COD', 'succeeded', 'earfil, 452, Mahrasta, ukhasnagar, Mahrasta, Mahrasta, 274203\n8423073490', '22/02/2019 08:08:32', 'Complete', '8423073490', '340.90', '1b63ce0b94d1e6c9208dfc2929ab3595'),
(3, 'OD5510149649792', 'COD', 'COD', 'succeeded', 'Naresh Gwalani, vishal, 505, ULHASNAGAR, Maharashtra, 421005\n9890322940', '22/02/2019 12:36:08', 'Complete', '9890322940', '720.40', '6c02af17de7e1639bf7a311638f63d94'),
(4, 'OD357413460532', 'COD', 'COD', 'succeeded', 'ansari0551, ansari, 28, hata, Hata, Uttar Pradesh, 274203\n8707598547', '30/05/2019 08:18:21', 'Complete', '8707598547', '969.00', '1b63ce0b94d1e6c9208dfc2929ab3595');

-- --------------------------------------------------------

--
-- Table structure for table `users_profile`
--

CREATE TABLE `users_profile` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `local` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `flat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `landmark` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_profile`
--

INSERT INTO `users_profile` (`id`, `uid`, `name`, `phone`, `email`, `gender`, `city`, `local`, `flat`, `pincode`, `state`, `landmark`) VALUES
(1, 'c7eadf90f6848eaf3b70bff8319c0fa3', 'Esrafil Ansari', '', 'ansari0551@gmail.com', '', '', '', '', '', '', ''),
(2, '41293564833272625a9689f46fe8bdf8', 'ESRAFIl', '', 'ansari0551@gmail.com', '', '', '', '', '', '', ''),
(3, '6c02af17de7e1639bf7a311638f63d94', 'Naresh Gwalani', '9890322940', 'nareshgwalani.g@gmail.com', 'male', 'ULHASNAGAR', '505', 'vishal', '421005', 'Maharashtra', ''),
(4, '1b63ce0b94d1e6c9208dfc2929ab3595', 'ansari0551', '8707598547', 'ansari0551@gmail.com', 'male', 'Hata', 'hata', 'ansari', '274203', 'Uttar Pradesh', '28'),
(5, '04b87736e1a0abda20d09f0c3a6e40b7', 'kamlesh', '', 'kamleshbairagi7@gmail.com', '', '', '', '', '', '', ''),
(6, '59b08537addf24044e342c21459f0153', 'sanket', '', 'sanketthakkar36@gmail.com', '', '', '', '', '', '', ''),
(7, '7dbbef1e01e4d2bd0d79a2eb27c68db7', 'kumar sathe', '', 'kumarsathe@enticeengineering.com', '', '', '', '', '', '', ''),
(8, '80a4a7122963ec9a074e20796f441d2a', 'pankaj', '', 'pankaj.khandagle@gmail.com', '', '', '', '', '', '', ''),
(9, '47c5e2e076835a9d441e79809b4c8a72', 'Naresh G Gwalani', '', 'jmdinfotech.2000@gmail.com', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_wishlist`
--

CREATE TABLE `users_wishlist` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_wishlist`
--

INSERT INTO `users_wishlist` (`id`, `uid`, `email`, `product_id`) VALUES
(2, '1b63ce0b94d1e6c9208dfc2929ab3595', 'ansari0551@gmail.com', '8674'),
(3, '1b63ce0b94d1e6c9208dfc2929ab3595', 'ansari0551@gmail.com', '5285'),
(4, '04b87736e1a0abda20d09f0c3a6e40b7', 'kamleshbairagi7@gmail.com', '8053'),
(5, '6c02af17de7e1639bf7a311638f63d94', 'nareshgwalani.g@gmail.com', '9370');

-- --------------------------------------------------------

--
-- Table structure for table `USER_LOG`
--

CREATE TABLE `USER_LOG` (
  `ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `LOGIN_T_AND_d` datetime NOT NULL,
  `TAG` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `USER_LOG`
--

INSERT INTO `USER_LOG` (`ID`, `USER_ID`, `LOGIN_T_AND_d`, `TAG`) VALUES
(1, 1, '2018-12-27 12:29:01', 'login'),
(2, 1, '2018-12-27 13:23:20', 'login'),
(3, 1, '2018-12-27 13:25:59', 'login'),
(4, 1, '2018-12-27 13:26:06', 'logout'),
(5, 1, '2018-12-27 13:26:41', 'login'),
(6, 1, '2018-12-27 14:00:33', 'login'),
(7, 1, '2018-12-27 14:45:32', 'login'),
(8, 1, '2018-12-27 17:44:13', 'login'),
(9, 1, '2018-12-27 18:07:37', 'login'),
(10, 1, '2018-12-27 19:18:46', 'login'),
(11, 1, '2018-12-27 19:36:42', 'login'),
(12, 1, '2018-12-27 19:38:36', 'login'),
(13, 1, '2018-12-29 17:06:40', 'login'),
(14, 1, '2019-01-02 13:53:31', 'login'),
(15, 1, '2019-01-02 19:06:06', 'login'),
(16, 1, '2019-01-23 18:25:21', 'login'),
(17, 1, '2019-03-02 12:59:11', 'login'),
(18, 1, '2019-03-02 13:14:43', 'logout'),
(19, 1, '2019-03-02 13:14:53', 'login'),
(20, 1, '2019-03-30 14:51:06', 'login'),
(21, 1, '2019-04-02 13:37:54', 'login'),
(22, 1, '2019-04-02 13:38:47', 'logout'),
(23, 1, '2019-04-02 13:38:49', 'login'),
(24, 1, '2019-04-02 14:46:13', 'login'),
(25, 1, '2019-04-08 15:02:01', 'login'),
(26, 0, '2019-04-13 14:15:35', 'logout'),
(27, 0, '2019-04-13 14:15:40', 'logout'),
(28, 0, '2019-04-17 05:46:21', 'logout'),
(29, 1, '2019-04-17 12:12:10', 'login'),
(30, 1, '2019-04-28 12:23:06', 'login'),
(31, 1, '2019-05-03 21:21:34', 'login'),
(32, 1, '2019-05-03 21:23:02', 'logout'),
(33, 0, '2019-05-29 03:55:37', 'logout'),
(34, 0, '2019-05-29 03:55:41', 'logout'),
(35, 0, '2019-07-14 21:16:39', 'logout'),
(36, 0, '2019-07-14 21:16:42', 'logout'),
(37, 1, '2019-07-29 12:33:46', 'login'),
(38, 0, '2019-08-11 13:01:09', 'logout'),
(39, 0, '2019-08-14 02:23:46', 'logout'),
(40, 0, '2019-08-14 10:27:14', 'logout'),
(41, 0, '2019-08-29 10:06:41', 'logout'),
(42, 0, '2019-08-29 10:06:45', 'logout'),
(43, 1, '2019-09-03 15:06:18', 'login'),
(44, 1, '2019-09-14 21:38:39', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_01` varchar(10) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `user_email` varchar(25) NOT NULL,
  `license` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL,
  `mac_address` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `password`, `address`, `contact_01`, `user_type`, `user_email`, `license`, `status`, `mac_address`) VALUES
(33, 'user-four', '123', 'gsv', '84881', 'operator', 'a@gmail.com', 'M560300114', '', ''),
(34, 'SaiPrinters', '1234', 'press bazaar ulhasnagar 3', '9168820272', 'admin', 'saiprinterssantosh@gmail.', 'S908067229', '', ''),
(35, 'Kamlesh', '1989', 'Murbad', '9890700809', 'admin', 'kamleshbairagi7@gmail.com', 'M560300114', '', ''),
(32, 'user-three', '123', 'a', '123456789', 'operator', 'a@gmail.com', 'M560300114', '', ''),
(31, 'user-two', '123', 'a', '8468845188', 'operator', 'a@gmail.com', 'M560300114', '', ''),
(30, 'user-one', '123', 'ab', '8423073490', 'admin', 'a@gmail.com', 'M560300114', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `USER_TB`
--

CREATE TABLE `USER_TB` (
  `USER_ID` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `USER_TB`
--

INSERT INTO `USER_TB` (`USER_ID`, `username`, `password`, `mobile`) VALUES
(1, 'admin', 'admin', '8423073490');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_admin`
--
ALTER TABLE `app_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `app_category`
--
ALTER TABLE `app_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `app_products`
--
ALTER TABLE `app_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `app_productsmain`
--
ALTER TABLE `app_productsmain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_slider`
--
ALTER TABLE `app_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `AREA_MST`
--
ALTER TABLE `AREA_MST`
  ADD PRIMARY KEY (`AREAID`);

--
-- Indexes for table `CATEGORYMASTER`
--
ALTER TABLE `CATEGORYMASTER`
  ADD PRIMARY KEY (`CATEGORYID`);

--
-- Indexes for table `company_table`
--
ALTER TABLE `company_table`
  ADD PRIMARY KEY (`cmp_id`);

--
-- Indexes for table `customer_table`
--
ALTER TABLE `customer_table`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `GROUPS_PER`
--
ALTER TABLE `GROUPS_PER`
  ADD UNIQUE KEY `GROUPID` (`GROUPID`);

--
-- Indexes for table `jmd_user`
--
ALTER TABLE `jmd_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `ks_fcm`
--
ALTER TABLE `ks_fcm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `M_USER`
--
ALTER TABLE `M_USER`
  ADD PRIMARY KEY (`USER_ID`);

--
-- Indexes for table `M_USER_DET`
--
ALTER TABLE `M_USER_DET`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ordered_product`
--
ALTER TABLE `ordered_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_head`
--
ALTER TABLE `order_head`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `PGMST`
--
ALTER TABLE `PGMST`
  ADD PRIMARY KEY (`PGMSTID`);

--
-- Indexes for table `PMST`
--
ALTER TABLE `PMST`
  ADD PRIMARY KEY (`PRODID`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `PROD_BAL`
--
ALTER TABLE `PROD_BAL`
  ADD PRIMARY KEY (`TRUID`);

--
-- Indexes for table `PURDET`
--
ALTER TABLE `PURDET`
  ADD PRIMARY KEY (`DTRUID`);

--
-- Indexes for table `PURHEAD`
--
ALTER TABLE `PURHEAD`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `SALDET`
--
ALTER TABLE `SALDET`
  ADD PRIMARY KEY (`TRUID`);

--
-- Indexes for table `SALHEAD`
--
ALTER TABLE `SALHEAD`
  ADD PRIMARY KEY (`TRUID`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `UNIFOOD_EMAIL`
--
ALTER TABLE `UNIFOOD_EMAIL`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `UNIFOOD_GROUP_PER`
--
ALTER TABLE `UNIFOOD_GROUP_PER`
  ADD PRIMARY KEY (`GROUPID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `UNIT_MST`
--
ALTER TABLE `UNIT_MST`
  ADD PRIMARY KEY (`UNIT_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_cart`
--
ALTER TABLE `users_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_profile`
--
ALTER TABLE `users_profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `users_wishlist`
--
ALTER TABLE `users_wishlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `USER_LOG`
--
ALTER TABLE `USER_LOG`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `USER_TB`
--
ALTER TABLE `USER_TB`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_admin`
--
ALTER TABLE `app_admin`
  MODIFY `admin_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `app_category`
--
ALTER TABLE `app_category`
  MODIFY `cat_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `app_products`
--
ALTER TABLE `app_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `app_productsmain`
--
ALTER TABLE `app_productsmain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `app_slider`
--
ALTER TABLE `app_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `AREA_MST`
--
ALTER TABLE `AREA_MST`
  MODIFY `AREAID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `CATEGORYMASTER`
--
ALTER TABLE `CATEGORYMASTER`
  MODIFY `CATEGORYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_table`
--
ALTER TABLE `company_table`
  MODIFY `cmp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customer_table`
--
ALTER TABLE `customer_table`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `GROUPS_PER`
--
ALTER TABLE `GROUPS_PER`
  MODIFY `GROUPID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `jmd_user`
--
ALTER TABLE `jmd_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ks_fcm`
--
ALTER TABLE `ks_fcm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `M_USER`
--
ALTER TABLE `M_USER`
  MODIFY `USER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `M_USER_DET`
--
ALTER TABLE `M_USER_DET`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `ordered_product`
--
ALTER TABLE `ordered_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_head`
--
ALTER TABLE `order_head`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `PGMST`
--
ALTER TABLE `PGMST`
  MODIFY `PGMSTID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `PMST`
--
ALTER TABLE `PMST`
  MODIFY `PRODID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `product_table`
--
ALTER TABLE `product_table`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `PROD_BAL`
--
ALTER TABLE `PROD_BAL`
  MODIFY `TRUID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `PURDET`
--
ALTER TABLE `PURDET`
  MODIFY `DTRUID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `PURHEAD`
--
ALTER TABLE `PURHEAD`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `SALDET`
--
ALTER TABLE `SALDET`
  MODIFY `TRUID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `SALHEAD`
--
ALTER TABLE `SALHEAD`
  MODIFY `TRUID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `UNIFOOD_EMAIL`
--
ALTER TABLE `UNIFOOD_EMAIL`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `UNIFOOD_GROUP_PER`
--
ALTER TABLE `UNIFOOD_GROUP_PER`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1537;

--
-- AUTO_INCREMENT for table `UNIT_MST`
--
ALTER TABLE `UNIT_MST`
  MODIFY `UNIT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users_cart`
--
ALTER TABLE `users_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_profile`
--
ALTER TABLE `users_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users_wishlist`
--
ALTER TABLE `users_wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `USER_LOG`
--
ALTER TABLE `USER_LOG`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `USER_TB`
--
ALTER TABLE `USER_TB`
  MODIFY `USER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
